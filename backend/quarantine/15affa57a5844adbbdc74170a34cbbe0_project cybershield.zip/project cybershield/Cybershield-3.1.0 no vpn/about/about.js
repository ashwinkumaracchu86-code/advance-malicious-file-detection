const versionEl = document.getElementById("version");

try {
  const manifest = chrome.runtime.getManifest();
  versionEl.textContent = manifest.version || "1.0.0";
} catch (e) {
  versionEl.textContent = "3.8.0";
}

document.querySelectorAll(".btn-credits").forEach((btn) => {
  btn.addEventListener("click", () => {
    const menuId = btn.getAttribute("data-credits");
    const menu = document.getElementById(menuId);
    if (!menu) return;

    const isOpen = menu.classList.contains("open");

    document.querySelectorAll(".credits-menu.open").forEach((m) => m.classList.remove("open"));
    document.querySelectorAll(".btn-credits.open").forEach((b) => b.classList.remove("open"));

    if (!isOpen) {
      menu.classList.add("open");
      btn.classList.add("open");
    }
  });
});
