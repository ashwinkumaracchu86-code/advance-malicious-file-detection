"use strict";

const FILE_INFO = {
  "manifest.json": {
    icon: "\u2699\ufe0f",
    accent: "#58a6ff",
    role: "The declaration that defines the whole extension for Chrome.",
    how: "Every Chrome extension starts with this Manifest V3 file. It declares the product name and version, the stable extension key (which pins the extension ID), every permission CyberShield needs (storage, tabs, scripting, management, notifications, declarativeNetRequest and more), and the host permissions for Google search, RDAP lookups and all URLs.",
    points: [
      "Declares the background service worker (background/background.js) as the single entry point of all background logic",
      "Registers four content scripts: ad blocking on all pages, search-safety badges on Google, YouTube ad removal, and MailGuard on Gmail",
      "Declares the toolbar popup, the icon set and web-accessible resources (warning + analyzer pages)",
      "The pinned key keeps the extension ID stable across installs and updates"
    ]
  },
  "background/background.js": {
    icon: "\u2699\ufe0f",
    accent: "#58a6ff",
    role: "The brain of CyberShield \u2014 a service worker that runs every core feature.",
    how: "This service worker is loaded automatically by Chrome and stays awake as long as there is work to do. It hosts the central message hub: the popup, content scripts and other pages talk to it via chrome.runtime.sendMessage. It computes safety scores with analyzeUrl, manages dynamic blocking rules through declarativeNetRequest, fetches live domain info (age, HTTPS, RDAP), and shows notifications when a threat is blocked.",
    points: [
      "Message hub: ANALYZE_URL, GET_DOMAIN_INFO, FETCH_URL, MAILGUARD_ANALYZE_EMAIL and more",
      "Scores every URL 0\u2013100 and decides whether to block, warn, or allow \u2014 with a notification and warning-page redirect for dangerous sites",
      "Maintains DNR rule sets: user blocklists, safelists, and the ad/tracker filter",
      "Watches navigation events (webNavigation) so it can intercept threats before the page loads"
    ]
  },
  "background/phishing-detector.js": {
    icon: "\u{0001f9ea}",
    accent: "#f85149",
    role: "The heuristic engine that catches phishing before you click.",
    how: "Loaded into the service worker with importScripts, this file is a pure analysis library with no UI. It examines a URL and page content and scores many signals: brand impersonation in the domain, homoglyph and confusable characters, unusual TLDs, URL shorteners and redirect chains, suspicious login keywords, and page text that mimics well-known sites like PayPal, Microsoft or Google. Every signal contributes to the final 0\u2013100 safety score.",
    points: [
      "Brand-impersonation detection tuned to avoid false positives on legitimate domains",
      "Homoglyph matcher catches look-alike letters used in typosquatting",
      "Analyzes both the URL itself and page content/text for fake login patterns",
      "Pure functions with no chrome API calls \u2014 easy to unit-test",
      "Also powers MailGuard when it analyzes email payloads"
    ]
  },
  "popup/popup.html": {
    icon: "\u{0001f5f3}\ufe0f",
    accent: "#3fb950",
    role: "The toolbar popup \u2014 the main control center users see first.",
    how: "Opens when the user clicks the CyberShield icon in the toolbar. It shows the safety score ring for the current tab, a breakdown of why the score was given, domain info, and every toggle: phishing protection, blocking, notifications, ad blocking and MailGuard. Settings changes are saved to chrome.storage.local and instantly picked up by the background worker.",
    points: [
      "Score ring + reasons for the current tab's rating",
      "All feature toggles persist via chrome.storage.local",
      "Custom blocklist / safelist quick-add for the current site",
      "Links to the analyzer, warning page and About"
    ]
  },
  "popup/popup.css": {
    icon: "\u{0001f3a8}",
    accent: "#3fb950",
    role: "The dark, shield-themed styling of the popup.",
    how: "Styles the popup with the CyberShield dark theme: glass cards, gradient accents, toggle switches, and the score ring. Keeps the popup compact and readable inside the small toolbar window.",
    points: [
      "CSS variables shared with the other pages (colors, borders, gradients)",
      "Custom toggle-switch styling",
      "Responsive layout for narrow popup widths",
      "Reduced-motion support"
    ]
  },
  "popup/popup.js": {
    icon: "\u{0001f4cb}",
    accent: "#3fb950",
    role: "Wires every button, toggle and panel in the popup to the background.",
    how: "On load it asks the background worker for the active tab's safety score and domain info, then renders them. Each toggle sends a message (ANALYZE_URL, GET_SETTINGS, SAVE_SETTINGS, ...) to the service worker and reflects the result.",
    points: [
      "Sends/receives messages via chrome.runtime.sendMessage",
      "Renders score ring and risk reasons for the current tab",
      "Persists feature toggles and custom blocklist / safelist changes",
      "Updates the badge/tab color after decisions",
      "Fallbacks and try/catch keep the popup usable if the worker is briefly unavailable"
    ]
  },
  "content/content.js": {
    icon: "\u{0001f50d}",
    accent: "#58a6ff",
    role: "Puts safety badges directly on Google search results.",
    how: "Injected only on Google search pages (see the manifest match patterns). It reads every search result link, sends them to the background worker for analysis, and injects a small score chip and label ('Safe', 'Caution', 'Risk') next to each result \u2014 so users can tell dangerous sites apart before clicking. Re-runs when results change or the page scrolls into view.",
    points: [
      "Scans organic result links and shows a per-result safety chip",
      "Chips are color-coded by risk level",
      "Debounced re-scan handles infinite-scroll result loading",
      "Stays out of the way of paid ads and other result types"
    ]
  },
  "content/content.css": {
    icon: "\u{0001f3a8}",
    accent: "#58a6ff",
    role: "Styles the search-result safety chips.",
    how: "Defines the chip look (rounded badge with score + label), the color states for Safe/Caution/Risk, and positioning so chips fit neatly into Google's result rows without breaking the page layout.",
    points: [
      "Tiny, non-intrusive badges",
      "Green / amber / red states matching the app theme",
      "Safe to load on Google pages without conflicting with Google's own styles"
    ]
  },
  "content/adblock.js": {
    icon: "\u{0001f6ab}",
    accent: "#a371f7",
    role: "In-page ad hiding on every site (network + DOM layer).",
    how: "Injected on all pages except Gmail (see manifest). It combines two layers: the background worker's declarativeNetRequest rules block ad/tracker network requests, while this script hides ads that are already baked into the page (banners, in-content placements, iframes) by applying a curated list of element selectors. A MutationObserver keeps newly injected ads hidden as the page changes.",
    points: [
      "Selector-based hiding that catches ads not blocked at the network level",
      "MutationObserver hides ads added dynamically after page load",
      "Respects the user's adblock toggle from popup settings",
      "Careful selector list to avoid breaking page layouts"
    ]
  },
  "content/youtube-adblock.js": {
    icon: "\u25b6\ufe0f",
    accent: "#f85149",
    role: "Removes ads on YouTube specifically.",
    how: "Runs on youtube.com and targets YouTube's ad containers: preroll/video ads, banner ads above the video, and in-feed promoted entries. It hides elements by their ad-specific markers and watches the DOM with a MutationObserver, since YouTube constantly re-creates ad nodes while you watch.",
    points: [
      "Hides video ads, overlay banners and promoted feed entries",
      "MutationObserver handles YouTube's dynamic re-insertion of ads",
      "Guard logic keeps it from hiding real video controls",
      "Tied to the same adblock toggle as the rest of CyberShield"
    ]
  },
  "content/mailguard.js": {
    icon: "\u{0001f4e7}",
    accent: "#3fb950",
    role: "Phishing protection inside Gmail.",
    how: "Injected only into mail.google.com. It inspects the email list and message content, and ranks each email's safety: legitimate senders get a green grade, suspicious external senders and phishing patterns get amber or red flags. It uses the same phishing analyzer as the background worker and renders small grade badges next to emails plus inline warnings inside suspicious messages.",
    points: [
      "Color-grades emails in the inbox list",
      "Detects brand impersonation, spoofed senders and suspicious links",
      "Shows inline warnings inside risky messages",
      "Respects the MailGuard toggle; can be switched off entirely"
    ]
  },
  "content/mailguard.css": {
    icon: "\u{0001f3a8}",
    accent: "#3fb950",
    role: "Styles MailGuard's grades and warnings in Gmail.",
    how: "Defines the grade chips, warning banners and highlight styles used by mailguard.js, tuned so they look native inside Gmail's interface and never cover the compose or reading actions.",
    points: [
      "Grade badge styles: green / amber / red",
      "Inline warning banner styling",
      "Scoped selectors avoid breaking Gmail's own layout"
    ]
  },
  "analyzer/analyzer.html": {
    icon: "\u{0001f50e}",
    accent: "#a371f7",
    role: "The deep-dive page: permissions + content analysis for any site.",
    how: "A full tab page (web-accessible resource) opened from the popup or warning page. It shows a detailed report for a site: every permission the site requests (cookies, storage, location, notifications, camera & mic, geolocation ...), each graded by risk, plus a content analysis of what the page actually loads and tracks.",
    points: [
      "Permission-by-permission risk report with severity colors",
      "Content analysis of scripts, trackers and third-party calls",
      "Grade summary at the top for quick scanning",
      "Opened with the site's URL so analysis runs live"
    ]
  },
  "analyzer/analyzer.css": {
    icon: "\u{0001f3a8}",
    accent: "#a371f7",
    role: "Styling for the analyzer report page.",
    how: "Provides the report layout: header summary, permission cards, severity chips and the content-analysis sections, all matching the CyberShield dark theme.",
    points: [
      "Severity chip styles (low / medium / high / critical)",
      "Card grid for permissions",
      "Responsive for tab-sized windows"
    ]
  },
  "analyzer/analyzer.js": {
    icon: "\u{0001f4cb}",
    accent: "#a371f7",
    role: "Boots the analyzer page and computes the report.",
    how: "Reads the target URL from the query string, asks the background worker to analyze it (ANALYZE_URL + FETCH_URL + GET_DOMAIN_INFO), and feeds the results into the UI renderer. It also loads the permissions database to grade each requested permission.",
    points: [
      "Parses the ?url= parameter passed from popup/warning",
      "Collects analysis data from the background worker",
      "Pipes results into analyzer-ui.js for rendering",
      "Graceful error states when a site can't be analyzed"
    ]
  },
  "analyzer/analyzer-ui.js": {
    icon: "\u{0001f5c2}\ufe0f",
    accent: "#a371f7",
    role: "Renders the analyzer report into the page.",
    how: "Pure DOM-building code: given the analysis result and the permission database, it creates the summary header, the permission cards with risk grades, and the content-analysis sections. Keeping rendering separate from logic makes it easy to update the UI.",
    points: [
      "Builds the report DOM from analysis data",
      "Maps permission names to risk levels via permissions-db.js",
      "Handles empty/error reports gracefully",
      "No chrome APIs \u2014 pure rendering"
    ]
  },
  "analyzer/permissions-db.js": {
    icon: "\u{0001f5c4}\ufe0f",
    accent: "#e3b341",
    role: "The knowledge base of website permissions and their risk.",
    how: "A lookup table that describes every permission a website can request: what it does, why sites want it, and how risky it is (low/medium/high/critical). The analyzer grades a site's requests against this database, so users see plain-language explanations instead of jargon.",
    points: [
      "Covers cookies, storage, location, notifications, camera, mic and more",
      "Each entry: description, risk level and severity color",
      "Loaded by analyzer.js to grade the report",
      "Shared vocabulary between the analyzer and warning pages"
    ]
  },
  "warning/warning.html": {
    icon: "\u26a0\ufe0f",
    accent: "#f85149",
    role: "The danger page \u2014 what you see instead of a dangerous site.",
    how: "When the background worker decides a site is High Risk or Blocked, the user is redirected to this page. It shows the site's score, the full list of reasons (impersonation, typosquat, unsafe HTTPS, tracked permissions ...) and a clear 'Back to safety' action, with a careful proceed-anyway option for advanced users.",
    points: [
      "Full risk breakdown with the score ring",
      "Every detection reason listed in plain language",
      "Back-to-safety button plus guarded continue option",
      "Loaded as a web-accessible resource so any site can redirect to it"
    ]
  },
  "warning/warning.css": {
    icon: "\u{0001f3a8}",
    accent: "#f85149",
    role: "Styling for the warning page.",
    how: "Makes the danger page clear and slightly alarming: red accents, the score ring, reason list and action buttons \u2014 consistent with the rest of the product but unmistakably a warning.",
    points: [
      "Red danger theme",
      "Reason list with severity icons",
      "Prominent back-to-safety button"
    ]
  },
  "warning/warning.js": {
    icon: "\u{0001f4cb}",
    accent: "#f85149",
    role: "Fills the warning page with the blocked site's details.",
    how: "Reads the analysis result passed in the URL query string, renders the score and reasons, and wires the action buttons: back to safety, proceed anyway (with a checkbox confirmation), and open the full analyzer for a deeper look.",
    points: [
      "Parses the analysis data from the query string",
      "Renders score ring + reason list",
      "Guarded 'proceed anyway' flow",
      "Links to the analyzer report for the same URL"
    ]
  },
  "about/about.html": {
    icon: "\u2139\ufe0f",
    accent: "#3fb950",
    role: "The About page \u2014 product story, features and tools.",
    how: "Opened from the popup footer. Introduces CyberShield's features, the external security tools it recommends (VirusTotal, URLScan, Google Safe Browsing, Quttera) with credits, and the product vision. The top-right button leads here to this project-structure explorer.",
    points: [
      "Feature grid explaining every capability",
      "Tool cards for recommended external services",
      "Credits menus for each external tool",
      "Vision section describing the product's mission"
    ]
  },
  "about/about.css": {
    icon: "\u{0001f3a8}",
    accent: "#3fb950",
    role: "Styling for the About page.",
    how: "The showcase dark theme used by the About page: hero header, feature grid, tool cards, credits accordions, vision card and the fixed Project Structure button in the top-right corner.",
    points: [
      "Hero with gradient title and version chip",
      "Feature/tool card grid",
      "Accordion credits menus",
      "Top-right Project Structure button"
    ]
  },
  "about/about.js": {
    icon: "\u{0001f4cb}",
    accent: "#3fb950",
    role: "Makes the About page interactive.",
    how: "Loads the extension version from the manifest and toggles the credits accordions for each recommended tool card.",
    points: [
      "Fills in the version chip from chrome.runtime.getManifest()",
      "Credits menu open/close handling"
    ]
  },
  "icons/": {
    icon: "\u{0001f5a8}\ufe0f",
    accent: "#58a6ff",
    role: "The CyberShield logo in every required size.",
    how: "Four PNG icons (16, 32, 48, 128 px) used by the toolbar, the extension manager and the store listing. Both the action and the manifest icons map to these files.",
    points: [
      "16/32 px for the toolbar and context menus",
      "48 px for the extension management page",
      "128 px for the Chrome Web Store",
      "Referenced in manifest.json 'action' and 'icons'"
    ]
  },
  "about/project-structure.html": {
    icon: "\u{0001f4c1}",
    accent: "#a371f7",
    role: "This very page \u2014 the interactive project explorer.",
    how: "Opened from the Project Structure button on the About page. It renders the file tree, hosts the slide panel that explains each file, and provides the prev/next navigation to browse through every file in the project as a slide deck.",
    points: [
      "Tree panel built from an in-page data structure",
      "Click any file to pop open its explanation slide",
      "Prev/next slide navigation + arrow keys + back to tree",
      "Also reachable from the About page's top-right button"
    ]
  },
  "about/project-structure.css": {
    icon: "\u{0001f3a8}",
    accent: "#a371f7",
    role: "Styling for this project-explorer page.",
    how: "Provides the file-tree styling with folder indentation and tag pills, plus the right-hand slide panel that animates in from the side when a file is opened. Shares the same dark theme variables as the About page.",
    points: [
      "Tree rows with folder/child indentation",
      "Color-coded tag pills (core, engine, ui, content, data, config, assets)",
      "Slide panel with slide-in animation and its own body scrolling",
      "Keyboard focus styles and reduced-motion support"
    ]
  },
  "about/project-structure.js": {
    icon: "\u{0001f4cb}",
    accent: "#a371f7",
    role: "The data + logic behind the project explorer.",
    how: "Contains two data tables: FILE_INFO (the explanation for every file) and TREE (the folder structure). It renders the tree, keeps the flat list of files in tree order for slide navigation, opens/closes the slide when files are clicked, and moves between slides with prev/next or the arrow keys.",
    points: [
      "FILE_INFO: per-file icon, accent, role, how-it-works and key points",
      "TREE: nested folder structure rendered into the DOM",
      "Slide carousel state: current index, counter, prev/next",
      "Escape closes the slide; ArrowLeft/Right navigate; clicking the backdrop closes too"
    ]
  }
};

const TREE = [
  { name: "manifest.json", type: "file" },
  {
    name: "background", type: "folder",
    children: [
      { name: "background.js", type: "file" },
      { name: "phishing-detector.js", type: "file" }
    ]
  },
  {
    name: "popup", type: "folder",
    children: [
      { name: "popup.html", type: "file" },
      { name: "popup.css", type: "file" },
      { name: "popup.js", type: "file" }
    ]
  },
  {
    name: "content", type: "folder",
    children: [
      { name: "content.js", type: "file" },
      { name: "content.css", type: "file" },
      { name: "adblock.js", type: "file" },
      { name: "youtube-adblock.js", type: "file" },
      { name: "mailguard.js", type: "file" },
      { name: "mailguard.css", type: "file" }
    ]
  },
  {
    name: "analyzer", type: "folder",
    children: [
      { name: "analyzer.html", type: "file" },
      { name: "analyzer.css", type: "file" },
      { name: "analyzer.js", type: "file" },
      { name: "analyzer-ui.js", type: "file" },
      { name: "permissions-db.js", type: "file" }
    ]
  },
  {
    name: "warning", type: "folder",
    children: [
      { name: "warning.html", type: "file" },
      { name: "warning.css", type: "file" },
      { name: "warning.js", type: "file" }
    ]
  },
  {
    name: "about", type: "folder",
    children: [
      { name: "about.html", type: "file" },
      { name: "about.css", type: "file" },
      { name: "about.js", type: "file" },
      { name: "project-structure.html", type: "file" },
      { name: "project-structure.css", type: "file" },
      { name: "project-structure.js", type: "file" }
    ]
  },
  { name: "icons/", type: "file" }
];

const FILE_ICONS = {
  "background.js": "\u2699\ufe0f",
  "phishing-detector.js": "\u{0001f9ea}",
  "manifest.json": "\u2699\ufe0f",
  "popup.html": "\u{0001f5f3}\ufe0f",
  "popup.css": "\u{0001f3a8}",
  "popup.js": "\u{0001f4cb}",
  "content.js": "\u{0001f50d}",
  "content.css": "\u{0001f3a8}",
  "adblock.js": "\u{0001f6ab}",
  "youtube-adblock.js": "\u25b6\ufe0f",
  "mailguard.js": "\u{0001f4e7}",
  "mailguard.css": "\u{0001f3a8}",
  "analyzer.html": "\u{0001f50e}",
  "analyzer.css": "\u{0001f3a8}",
  "analyzer.js": "\u{0001f4cb}",
  "analyzer-ui.js": "\u{0001f5c2}\ufe0f",
  "permissions-db.js": "\u{0001f5c4}\ufe0f",
  "warning.html": "\u26a0\ufe0f",
  "warning.css": "\u{0001f3a8}",
  "warning.js": "\u{0001f4cb}",
  "about.html": "\u2139\ufe0f",
  "about.css": "\u{0001f3a8}",
  "about.js": "\u{0001f4cb}",
  "project-structure.html": "\u{0001f4c1}",
  "project-structure.css": "\u{0001f3a8}",
  "project-structure.js": "\u{0001f4cb}",
  "icons/": "\u{0001f5a8}\ufe0f"
};

const FOLDER_ICON = "\u{0001f4c1}";
const FOLDER_OPEN_ICON = "\u{0001f5c0}\ufe0f";

const TAG_TYPES = {
  "manifest.json": "config",
  "background.js": "core",
  "phishing-detector.js": "engine",
  "popup.html": "ui",
  "popup.css": "ui",
  "popup.js": "ui",
  "content.js": "content",
  "content.css": "ui",
  "adblock.js": "content",
  "youtube-adblock.js": "content",
  "mailguard.js": "content",
  "mailguard.css": "ui",
  "analyzer.html": "ui",
  "analyzer.css": "ui",
  "analyzer.js": "ui",
  "analyzer-ui.js": "ui",
  "permissions-db.js": "data",
  "warning.html": "ui",
  "warning.css": "ui",
  "warning.js": "ui",
  "about.html": "ui",
  "about.css": "ui",
  "about.js": "ui",
  "project-structure.html": "ui",
  "project-structure.css": "ui",
  "project-structure.js": "ui",
  "icons/": "assets"
};

const TAG_STYLES = {
  core: { label: "Core", color: "#58a6ff", bg: "rgba(88,166,255,0.12)", border: "rgba(88,166,255,0.4)" },
  engine: { label: "Engine", color: "#f85149", bg: "rgba(248,81,73,0.12)", border: "rgba(248,81,73,0.4)" },
  ui: { label: "UI", color: "#3fb950", bg: "rgba(63,185,80,0.12)", border: "rgba(63,185,80,0.4)" },
  content: { label: "Content", color: "#a371f7", bg: "rgba(163,113,247,0.12)", border: "rgba(163,113,247,0.4)" },
  data: { label: "Data", color: "#e3b341", bg: "rgba(227,179,65,0.12)", border: "rgba(227,179,65,0.4)" },
  config: { label: "Config", color: "#8b96a8", bg: "rgba(139,150,168,0.12)", border: "rgba(139,150,168,0.4)" },
  assets: { label: "Assets", color: "#58a6ff", bg: "rgba(88,166,255,0.12)", border: "rgba(88,166,255,0.4)" }
};

const treeRoot = document.getElementById("treeRoot");
const fileCountEl = document.getElementById("fileCount");
const hintPanel = document.getElementById("hintPanel");
const overlay = document.getElementById("slideOverlay");
const slidePanel = document.getElementById("slidePanel");
const slideTitle = document.getElementById("slideTitle");
const slidePath = document.getElementById("slidePath");
const slideIcon = document.getElementById("slideIcon");
const slideRole = document.getElementById("slideRole");
const slideBody = document.getElementById("slideBody");
const slideCounter = document.getElementById("slideCounter");
const slidePrev = document.getElementById("slidePrev");
const slideNext = document.getElementById("slideNext");
const slideClose = document.getElementById("slideClose");

const flatFiles = [];

function buildTree(container, children, depth, prefix) {
  prefix = prefix || "";
  for (const child of children) {
    if (child.type === "folder") {
      const folder = document.createElement("div");
      folder.className = "tree-folder";

      const head = document.createElement("div");
      head.className = "tree-folder-head";
      head.style.paddingLeft = `${10 + depth * 14}px`;
      head.setAttribute("aria-expanded", "true");

      const icon = document.createElement("span");
      icon.className = "tree-folder-icon";
      icon.textContent = FOLDER_OPEN_ICON;

      const label = document.createElement("span");
      label.textContent = child.name + "/";

      head.appendChild(icon);
      head.appendChild(label);
      folder.appendChild(head);

      const childrenWrap = document.createElement("div");
      childrenWrap.className = "tree-folder-children";
      buildTree(childrenWrap, child.children, depth + 1, prefix + child.name + "/");
      folder.appendChild(childrenWrap);

      container.appendChild(folder);
    } else {
      const path = prefix + child.name;
      const fileBtn = document.createElement("button");
      fileBtn.type = "button";
      fileBtn.className = "tree-file";
      fileBtn.style.paddingLeft = `${10 + depth * 14}px`;
      fileBtn.dataset.path = path;

      const icon = document.createElement("span");
      icon.className = "tree-file-icon";
      icon.textContent = FILE_ICONS[child.name] || "\u{0001f4c4}";

      const name = document.createElement("span");
      name.className = "tree-file-name";
      name.textContent = child.name;

      const tag = document.createElement("span");
      tag.className = "tree-file-tag";
      const tagType = TAG_TYPES[child.name];
      if (tagType) {
        const style = TAG_STYLES[tagType];
        tag.textContent = style.label;
        tag.style.color = style.color;
        tag.style.background = style.bg;
        tag.style.borderColor = style.border;
      } else {
        tag.classList.add("hidden-tag");
      }

      fileBtn.appendChild(icon);
      fileBtn.appendChild(name);
      fileBtn.appendChild(tag);

      fileBtn.addEventListener("click", () => {
        openSlide(path);
        document.querySelectorAll(".tree-file.active").forEach((el) => el.classList.remove("active"));
        fileBtn.classList.add("active");
      });

      flatFiles.push(path);
      container.appendChild(fileBtn);
    }
  }
}

buildTree(treeRoot, TREE, 0, "");
fileCountEl.textContent = flatFiles.length + " files";

function getFileInfo(path) {
  return FILE_INFO[path] || {
    icon: "\u{0001f4c4}",
    accent: "#58a6ff",
    role: "A file in the CyberShield project.",
    how: "This file is part of the extension bundle. Click through the tree to explore the rest of the project.",
    points: ["Part of the CyberShield extension bundle", "Loadable from the project folder"]
  };
}

function openSlide(path) {
  const info = getFileInfo(path);
  const tagType = TAG_TYPES[path];
  const tagStyle = tagType ? TAG_STYLES[tagType] : null;

  slideTitle.textContent = path;
  slidePath.textContent = "CyberShield/" + path;
  slideIcon.textContent = info.icon;
  slideIcon.style.background = `linear-gradient(135deg, ${info.accent}33, ${info.accent}1a)`;
  slideIcon.style.borderColor = `${info.accent}66`;
  slideRole.textContent = info.role;
  slideRole.style.color = info.accent;
  slideRole.style.background = `${info.accent}14`;
  slideRole.style.borderColor = `${info.accent}40`;

  slideBody.innerHTML = "";

  const howSec = document.createElement("div");
  howSec.className = "slide-sec";
  const howTitle = document.createElement("div");
  howTitle.className = "slide-sec-title";
  howTitle.textContent = "How it works";
  const howPara = document.createElement("p");
  howPara.textContent = info.how;
  howSec.appendChild(howTitle);
  howSec.appendChild(howPara);
  slideBody.appendChild(howSec);

  const pointsSec = document.createElement("div");
  pointsSec.className = "slide-sec";
  const pointsTitle = document.createElement("div");
  pointsTitle.className = "slide-sec-title";
  pointsTitle.textContent = "Key points";
  const list = document.createElement("ul");
  list.className = "slide-points";
  for (const point of info.points) {
    const li = document.createElement("li");
    const dot = document.createElement("span");
    dot.className = "slide-point";
    dot.style.background = info.accent;
    dot.style.color = info.accent;
    li.appendChild(dot);
    li.appendChild(document.createTextNode(point));
    list.appendChild(li);
  }
  pointsSec.appendChild(pointsTitle);
  pointsSec.appendChild(list);
  slideBody.appendChild(pointsSec);

  if (tagStyle) {
    const tagSec = document.createElement("div");
    tagSec.className = "slide-sec";
    const tagTitle = document.createElement("div");
    tagTitle.className = "slide-sec-title";
    tagTitle.textContent = "Role in the project";
    const tagChip = document.createElement("span");
    tagChip.className = "tree-file-tag";
    tagChip.textContent = tagStyle.label;
    tagChip.style.color = tagStyle.color;
    tagChip.style.background = tagStyle.bg;
    tagChip.style.borderColor = tagStyle.border;
    tagChip.style.fontSize = "12px";
    tagSec.appendChild(tagTitle);
    tagSec.appendChild(tagChip);
    slideBody.appendChild(tagSec);
  }

  updateCounter();
  overlay.hidden = false;
  hintPanel.hidden = true;
  document.body.style.overflow = "hidden";
  slidePanel.querySelector(".slide-head h2").focus();
}

function closeSlide() {
  overlay.hidden = true;
  hintPanel.hidden = false;
  document.body.style.overflow = "";
}

function updateCounter() {
  const idx = flatFiles.indexOf(slideTitle.textContent);
  slideCounter.textContent = `${idx + 1} / ${flatFiles.length}`;
  slidePrev.disabled = idx <= 0;
  slideNext.disabled = idx >= flatFiles.length - 1;
}

function stepSlide(delta) {
  const idx = flatFiles.indexOf(slideTitle.textContent);
  const nextIdx = Math.min(flatFiles.length - 1, Math.max(0, idx + delta));
  const nextPath = flatFiles[nextIdx];
  document.querySelectorAll(".tree-file").forEach((el) => {
    el.classList.toggle("active", el.dataset.path === nextPath);
  });
  openSlide(nextPath);
  slidePanel.scrollTop = 0;
  slideBody.scrollTop = 0;
}

slideClose.addEventListener("click", closeSlide);
overlay.addEventListener("click", (e) => {
  if (e.target === overlay) closeSlide();
});
slidePrev.addEventListener("click", () => stepSlide(-1));
slideNext.addEventListener("click", () => stepSlide(1));
document.addEventListener("keydown", (e) => {
  if (overlay.hidden) return;
  if (e.key === "Escape") closeSlide();
  if (e.key === "ArrowLeft") stepSlide(-1);
  if (e.key === "ArrowRight") stepSlide(1);
});
