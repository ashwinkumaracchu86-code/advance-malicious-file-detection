const backBtn = document.getElementById("backBtn");
const tabBtns = document.querySelectorAll(".tab-btn");
const urlTab = document.getElementById("urlTab");
const termsTab = document.getElementById("termsTab");
const urlInput = document.getElementById("urlInput");
const termsInput = document.getElementById("termsInput");
const analyzeUrlBtn = document.getElementById("analyzeUrlBtn");
const analyzeTermsBtn = document.getElementById("analyzeTermsBtn");
const inputSection = document.getElementById("inputSection");
const results = document.getElementById("results");
const loading = document.getElementById("loading");
const loadingText = document.getElementById("loadingText");
const errorEl = document.getElementById("error");
const riskHeader = document.getElementById("riskHeader");
const riskScoreCircle = document.getElementById("riskScoreCircle");
const riskScoreValue = document.getElementById("riskScoreValue");
const resultTitle = document.getElementById("resultTitle");
const resultSubtitle = document.getElementById("resultSubtitle");
const riskBadge = document.getElementById("riskBadge");
const statConcerns = document.getElementById("statConcerns");
const statDataTypes = document.getElementById("statDataTypes");
const statRisks = document.getElementById("statRisks");
const statGood = document.getElementById("statGood");
const summaryBox = document.getElementById("summaryBox");
const findingsList = document.getElementById("findingsList");
const dataTypesSection = document.getElementById("dataTypesSection");
const dataTypesList = document.getElementById("dataTypesList");
const newAnalysisBtn = document.getElementById("newAnalysisBtn");

let currentResult = null;

const RISK_LEVELS = {
  safe: { label: "Permission Friendly", color: "#3fb950", bg: "rgba(63, 185, 80, 0.15)", border: "rgba(63, 185, 80, 0.3)" },
  low: { label: "Low Risk", color: "#3fb950", bg: "rgba(63, 185, 80, 0.15)", border: "rgba(63, 185, 80, 0.3)" },
  medium: { label: "Moderate Risk", color: "#d29922", bg: "rgba(210, 153, 34, 0.15)", border: "rgba(210, 153, 34, 0.3)" },
  high: { label: "Elevated Risk", color: "#f85149", bg: "rgba(248, 81, 73, 0.15)", border: "rgba(248, 81, 73, 0.3)" },
  critical: { label: "High Risk", color: "#ff4444", bg: "rgba(255, 68, 68, 0.15)", border: "rgba(255, 68, 68, 0.3)" }
};

tabBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    tabBtns.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    urlTab.classList.toggle("hidden", tab !== "url");
    termsTab.classList.toggle("hidden", tab !== "terms");
    urlTab.classList.toggle("active", tab === "url");
    termsTab.classList.toggle("active", tab === "terms");
  });
});

analyzeUrlBtn.addEventListener("click", async () => {
  const url = urlInput.value.trim();
  if (!url) {
    showError("Please enter a website URL");
    return;
  }

  showLoading("Fetching website...");
  hideError();

  try {
    let fullUrl = url;
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      fullUrl = "https://" + url;
    }

    const html = await fetchWebsite(fullUrl);
    const result = analyzeWebsite(html, fullUrl);
    displayResults(result);
  } catch (e) {
    showError(e.message || "Failed to analyze website");
  } finally {
    hideLoading();
  }
});

urlInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") analyzeUrlBtn.click();
});

analyzeTermsBtn.addEventListener("click", () => {
  const text = termsInput.value.trim();
  if (!text) {
    showError("Please paste terms & conditions or privacy policy text");
    return;
  }

  showLoading("Analyzing text...");
  hideError();

  setTimeout(() => {
    try {
      const result = analyzeTerms(text);
      displayResults(result);
    } catch (e) {
      showError(e.message || "Failed to analyze text");
    } finally {
      hideLoading();
    }
  }, 100);
});

newAnalysisBtn.addEventListener("click", () => {
  inputSection.classList.remove("hidden");
  results.classList.add("hidden");
  errorEl.classList.add("hidden");
  urlInput.value = "";
  termsInput.value = "";
  currentResult = null;
});

backBtn.addEventListener("click", () => {
  if (window.history.length > 1) {
    window.history.back();
  } else {
    window.close();
  }
});

function displayResults(result) {
  currentResult = result;
  inputSection.classList.add("hidden");
  results.classList.remove("hidden");
  hideError();

  const risk = RISK_LEVELS[result.badgeClass] || RISK_LEVELS.medium;

  animateValue(riskScoreValue, result.score);
  riskScoreCircle.style.borderColor = risk.color;
  riskScoreCircle.style.background = risk.bg;
  riskScoreValue.style.color = risk.color;
  riskScoreCircle.style.boxShadow = `0 0 36px ${risk.color}44, inset 0 0 18px ${risk.color}1a`;

  resultTitle.textContent = result.title;
  resultSubtitle.textContent = result.subtitle || "";

  riskBadge.textContent = result.level;
  riskBadge.style.background = risk.bg;
  riskBadge.style.color = risk.color;
  riskBadge.style.borderColor = risk.border;

  riskHeader.style.borderLeft = `4px solid ${risk.color}`;

  const highCount = result.concerns.filter(c => c.severity === "high").length;
  statConcerns.textContent = result.concerns.length;
  statDataTypes.textContent = result.dataTypes.length;
  statRisks.textContent = highCount;
  statGood.textContent = result.goodSigns.length;

  summaryBox.innerHTML = `
    <div class="summary-icon">${result.score >= 50 ? "&#9888;" : "&#9989;"}</div>
    <div class="summary-text">${result.summary}</div>
  `;
  summaryBox.style.borderColor = risk.color;

  findingsList.innerHTML = "";
  if (result.details.length === 0) {
    findingsList.innerHTML = '<div class="no-findings">No findings detected.</div>';
  } else {
    const sorted = [...result.details].sort((a, b) => {
      const order = { high: 0, medium: 1, low: 2 };
      return (order[a.severity] || 3) - (order[b.severity] || 3);
    });

    sorted.forEach(finding => {
      const riskInfo = RISK_LEVELS[finding.severity === "high" ? "high" : finding.severity === "medium" ? "medium" : "low"];
      const item = document.createElement("div");
      item.className = `finding-item ${finding.passed ? "passed" : "failed"}`;
      item.style.borderLeftColor = finding.passed ? "#3fb950" : riskInfo.color;
      item.innerHTML = `
        <span class="finding-icon">${finding.passed ? "&#10003;" : "&#10007;"}</span>
        <span class="finding-text">${finding.text}</span>
        <span class="finding-badge" style="color:${finding.passed ? "#3fb950" : riskInfo.color};background:${finding.passed ? "rgba(63,185,80,0.15)" : riskInfo.bg};border:1px solid ${finding.passed ? "rgba(63,185,80,0.3)" : riskInfo.border};">${finding.passed ? "Good" : finding.severity}</span>
      `;
      findingsList.appendChild(item);
    });
  }

  if (result.dataTypes.length > 0) {
    dataTypesSection.classList.remove("hidden");
    dataTypesList.innerHTML = "";
    result.dataTypes.sort((a, b) => b.count - a.count).forEach(dt => {
      const item = document.createElement("div");
      item.className = "data-type-item";
      item.innerHTML = `
        <span class="data-type-name">${dt.type}</span>
        <span class="data-type-count">${dt.count} mention(s)</span>
      `;
      dataTypesList.appendChild(item);
    });
  } else {
    dataTypesSection.classList.add("hidden");
  }
}

function showLoading(text) {
  loadingText.textContent = text || "Analyzing...";
  loading.classList.remove("hidden");
  inputSection.classList.add("hidden");
}

function animateValue(el, target, duration = 700) {
  const startTime = performance.now();
  const tick = (now) => {
    const p = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(target * eased);
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function hideLoading() {
  loading.classList.add("hidden");
}

function showError(msg) {
  errorEl.classList.remove("hidden");
  errorEl.textContent = msg;
}

function hideError() {
  errorEl.classList.add("hidden");
}
