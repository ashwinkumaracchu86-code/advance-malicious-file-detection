const TRACKING_DOMAINS = [...new Set([
  "google-analytics.com", "googletagmanager.com", "googleadservices.com",
  "doubleclick.net", "googlesyndication.com",
  "facebook.com/tr", "facebook.net", "fbcdn.net",
  "analytics.twitter.com", "ads-twitter.com",
  "linkedin.com/insight", "snap.licdn.com",
  "hotjar.com", "mouseflow.com", "crazyegg.com",
  "mixpanel.com", "segment.com", "amplitude.com",
  "heap.io", "fullstory.com", "logrocket.com",
  "optimizely.com", "convert.com", "vwo.com",
  "chartbeat.com", "parsely.com", "newrelic.com",
  "sentry.io", "bugsnag.com", "datadoghq.com",
  "amazonaws.com/cloudfront", "cloudflare.com/cdn-cgi",
  "scorecardresearch.com", "quantserve.com",
  "moat.com", "doubleverify.com", "iasds01.com",
  "taboola.com", "outbrain.com",
  "criteo.com", "criteo.net", "adnxs.com",
  "pinterest.com/ct", "snap.com/pixel",
  "tiktok.com/pixel", "bing.com/msclkid"
])];

const DATA_TYPE_PATTERNS = {
  "Personal Identifiers": /name|email|phone|address|date.of.birth|social.security|ssn|passport|driver.?s?.?license/i,
  "Financial Data": /credit.?card|debit.?card|bank.?account|routing.?number|payment|billing|invoice|tax|income|salary/i,
  "Location Data": /location|gps|geolocation|ip.?address|zip.?code|postal|latitude|longitude|beacon|wifi/i,
  "Browsing History": /browsing.?history|search.?history|visit.?history|page.?views|click.?history|referral/i,
  "Device Information": /device.?id|browser.?fingerprint|user.?agent|screen.?resolution|operating.?system|hardware/i,
  "Cookies & Trackers": /cookie|web.?beacon|pixel.?tag|tracking.?script|analytics|fingerprint/i,
  "Social Media Data": /social.?media|facebook|twitter|instagram|linkedin|social.?profile|friend.?list/i,
  "Health Data": /health|medical|fitness|biometric|heart.?rate|step.?count|mental.?health/i,
  "Communications": /email|sms|message|chat|call.?log|voicemail|contact.?list/i,
  "Behavioral Data": /interest|preference|purchase.?history|shopping|cart|wish.?list|recommendation/i,
  "Third-Party Sharing": /third.?party|share.?with|partner|affiliate|advertiser|data.?broker/i,
  "Children.?s? Data": /child|minor|kid|under.?13|coppa|parental/i
};

const PERMISSION_PATTERNS = [
  { icon: "\uD83D\uDD14", name: "Notifications", pattern: /Notification\.requestPermission|Notification\.permission/i, severity: "medium", weight: 8 },
  { icon: "\uD83D\uDCCD", name: "Location", pattern: /navigator\.geolocation|getCurrentPosition|watchPosition/i, severity: "high", weight: 14 },
  { icon: "\uD83D\uDCF9", name: "Camera / Microphone", pattern: /getUserMedia|navigator\.mediaDevices/i, severity: "high", weight: 16 },
  { icon: "\uD83D\uDCCB", name: "Clipboard", pattern: /clipboard\.readText|navigator\.clipboard/i, severity: "medium", weight: 10 },
  { icon: "\uD83D\uDCF1", name: "Device Sensors", pattern: /devicemotion|deviceorientation|getBattery|navigator\.vibrate/i, severity: "low", weight: 4 },
  { icon: "\uD83C\uDF6A", name: "Cookies & Storage", pattern: /document\.cookie|localStorage|sessionStorage/i, severity: "medium", weight: 6 },
  { icon: "\uD83D\uDCE4", name: "Background Data Sending", pattern: /navigator\.sendBeacon|beacon\//i, severity: "medium", weight: 7 },
  { icon: "\u2699\uFE0F", name: "Service Worker", pattern: /serviceWorker\.register|navigator\.serviceWorker/i, severity: "low", weight: 4 },
  { icon: "\uD83D\uDCBE", name: "Persistent Storage", pattern: /storage\.persist|navigator\.storage/i, severity: "low", weight: 3 }
];

function detectPermissions(html) {
  const findings = [];
  for (const perm of PERMISSION_PATTERNS) {
    if (perm.pattern.test(html)) {
      findings.push({
        label: `${perm.name} permission requested`,
        icon: perm.icon,
        severity: perm.severity,
        weight: perm.weight
      });
    }
  }
  return findings;
}

const PRIVACY_CONCERN_PATTERNS = [
  { pattern: /sell(?:s|ing)?\s+(?:your|personal|user)\s+data/i, label: "Sells your data", severity: "high", weight: 25 },
  { pattern: /share(?:s|ing)?\s+(?:your|personal|user)\s+data\s+with\s+third.?parties/i, label: "Shares data with third parties", severity: "high", weight: 20 },
  { pattern: /may\s+share|might\s+share|could\s+share|reserve.*right.*share/i, label: "May share your data", severity: "medium", weight: 15 },
  { pattern: /track(?:s|ing)?\s+your\s+(?:activity|browsing|behavior|online)/i, label: "Tracks your online activity", severity: "high", weight: 20 },
  { pattern: /collect(?:s|ing)?\s+(?:your|personal|user)\s+data/i, label: "Collects personal data", severity: "medium", weight: 10 },
  { pattern: /collect(?:s|ing)?\s+information\s+about\s+you/i, label: "Collects information about you", severity: "medium", weight: 10 },
  { pattern: /non-?personal-?identifiable|anonymized|aggregated/i, label: "Uses anonymized data", severity: "low", weight: -5 },
  { pattern: /opt-?out|unsubscribe|do\s+not\s+sell/i, label: "Provides opt-out option", severity: "low", weight: -10 },
  { pattern: /delete(?:your)?\s+(?:account|data|information)/i, label: "Allows data deletion", severity: "low", weight: -10 },
  { pattern: /gdpr|ccpa|privacy\s+right|data\s+protection/i, label: "References privacy regulations", severity: "low", weight: -8 },
  { pattern: /encrypt(?:s|ed|ion)?|ssl|tls|secure/i, label: "Uses encryption", severity: "low", weight: -5 },
  { pattern: /two-?factor|2fa|mfa|multi.?factor/i, label: "Supports 2FA", severity: "low", weight: -5 },
  { pattern: /indefinite|permanent|forever|as\s+long\s+as/i, label: "Indefinite data retention", severity: "high", weight: 15 },
  { pattern: /retai?n(?:s|ing)?\s+(?:your|personal|user)?\s*(?:data|information)?\s*for\s*\d+\s*(?:year|month|day|week)/i, label: "Specific retention period", severity: "medium", weight: 5 },
  { pattern: /government|law\s+enforcement|subpoena|court\s+order|legal\s+request/i, label: "Data shared with government", severity: "medium", weight: 10 },
  { pattern: /merger|acquisition|bankruptcy|transfer/i, label: "Data may transfer on business change", severity: "medium", weight: 10 },
  { pattern: /cookie|web.?beacon|pixel|tracking\s+technolog/i, label: "Uses tracking technologies", severity: "medium", weight: 8 },
  { pattern: /interest-?based|behavioral|targeted|personalized\s+(?:ads|advertising)/i, label: "Uses targeted advertising", severity: "high", weight: 15 },
  { pattern: /no\s+(?:guarantee|warranty|liability)|not\s+responsible/i, label: "Disclaims liability", severity: "medium", weight: 8 },
  { pattern: /change.*policy|modify.*terms|update.*privacy|reserve.*right.*change/i, label: "Can change policy without notice", severity: "medium", weight: 8 },
  { pattern: /children|minor|under\s*13|coppa|parental/i, label: "Involves children's data", severity: "high", weight: 15 }
];

const GOOD_PRIVACY_PATTERNS = [
  { pattern: /we\s+do\s+not\s+sell|never\s+sell|will\s+not\s+sell/i, label: "Does not sell data", weight: -15 },
  { pattern: /we\s+do\s+not\s+share|never\s+share|will\s+not\s+share/i, label: "Does not share data", weight: -15 },
  { pattern: /minimal|least\s+privilege|only\s+what.*necessary|data\s+minimization/i, label: "Data minimization", weight: -10 },
  { pattern: /you\s+can\s+delete|right\s+to\s+delete|data\s+deletion/i, label: "Supports data deletion", weight: -10 },
  { pattern: /you\s+can\s+export|data\s+portability|download\s+your/i, label: "Supports data export", weight: -8 },
  { pattern: /regular.*audit|security.*review|penetration.*test/i, label: "Regular security audits", weight: -8 },
  { pattern: /gdpr|ccpa|hipaa|ferpa|pipeda/i, label: "Privacy regulation compliance", weight: -10 },
  { pattern: /privacy\s+by\s+design|privacy\s+first/i, label: "Privacy-first approach", weight: -10 },
  { pattern: /no\s+tracking|tracking.?free|does\s+not\s+track/i, label: "No tracking", weight: -15 },
  { pattern: /open.?source|transparent|public\s+audit/i, label: "Transparent practices", weight: -8 }
];

const TRACKING_INDICATOR_SCRIPTS = [
  /google[\-_]?analytics/i, /gtag/i, /gtm\.js/i, /analytics\.js/i,
  /facebook.*pixel/i, /fb.*pixel/i, /fbevents/i,
  /hotjar/i, /crazy.?egg/i, /mouseflow/i, /fullstory/i, /logrocket/i,
  /mixpanel/i, /segment\.io/i, /amplitude/i, /heap\.io/i,
  /optimizely/i, /vwo\.com/i, /convert\.com/i,
  /chartbeat/i, /parsely/i, /newrelic/i,
  /doubleclick/i, /googlesyndication/i, /googleadservices/i,
  /taboola/i, /outbrain/i, /criteo/i, /adnxs/i,
  /scorecardresearch/i, /quantserve/i, /moat/i,
  /bing.*msclkid/i, /pinterest.*ct/i, /snap.*pixel/i, /tiktok.*pixel/i
];

function analyzeTerms(text) {
  if (!text || text.trim().length < 50) {
    return {
      score: 0,
      level: "Insufficient Data",
      title: "Text Too Short",
      subtitle: "Please provide more text for a meaningful analysis.",
      summary: "The provided text is too short to perform a meaningful privacy analysis. Please paste the full terms and conditions or privacy policy.",
      concerns: [],
      dataTypes: [],
      goodSigns: [],
      riskFactors: 0,
      details: []
    };
  }

  let score = 50;
  const concerns = [];
  const goodSigns = [];
  const detectedDataTypes = [];

  for (const concern of PRIVACY_CONCERN_PATTERNS) {
    const match = text.match(concern.pattern);
    if (match) {
      concerns.push({ label: concern.label, severity: concern.severity, weight: concern.weight });
      score += concern.weight;
    }
  }

  for (const good of GOOD_PRIVACY_PATTERNS) {
    const match = text.match(good.pattern);
    if (match) {
      goodSigns.push({ label: good.label, weight: good.weight });
      score += good.weight;
    }
  }

  for (const [type, pattern] of Object.entries(DATA_TYPE_PATTERNS)) {
    const matches = text.match(new RegExp(pattern.source, "gi"));
    if (matches && matches.length > 0) {
      detectedDataTypes.push({ type, count: matches.length });
    }
  }

  if (detectedDataTypes.length > 5) {
    score += 10;
    concerns.push({ label: `Collects many data types (${detectedDataTypes.length})`, severity: "high", weight: 10 });
  }

  const wordCount = text.split(/\s+/).length;
  if (wordCount < 200) {
    score += 5;
    concerns.push({ label: "Very short privacy policy", severity: "medium", weight: 5 });
  }

  score = Math.max(0, Math.min(100, score));

  let level, badgeClass;
  if (score >= 80) { level = "High Risk"; badgeClass = "critical"; }
  else if (score >= 60) { level = "Elevated Risk"; badgeClass = "high"; }
  else if (score >= 40) { level = "Moderate Risk"; badgeClass = "medium"; }
  else if (score >= 20) { level = "Low Risk"; badgeClass = "low"; }
  else { level = "Permission Friendly"; badgeClass = "safe"; }

  const highConcerns = concerns.filter(c => c.severity === "high");
  const medConcerns = concerns.filter(c => c.severity === "medium");

  let summary = "";
  if (score >= 60) {
    summary = `This policy raises significant privacy concerns. ${highConcerns.length > 0 ? highConcerns.length + " high-severity issue(s) found. " : ""}Review carefully before agreeing.`;
  } else if (score >= 35) {
    summary = `This policy has some privacy concerns. ${medConcerns.length > 0 ? medConcerns.length + " moderate issue(s) found. " : ""}Consider what data you're comfortable sharing.`;
  } else {
    summary = "This policy appears relatively privacy-friendly. Few significant concerns detected.";
  }

  return {
    score,
    level,
    badgeClass,
    title: "Terms & Conditions Analysis",
    subtitle: `Analyzed ${wordCount.toLocaleString()} words of policy text`,
    summary,
    concerns,
    dataTypes: detectedDataTypes,
    goodSigns,
    riskFactors: concerns.length,
    details: concerns.map(c => ({ text: c.label, passed: false, severity: c.severity }))
      .concat(goodSigns.map(g => ({ text: g.label, passed: true, severity: "low" })))
  };
}

function analyzeWebsite(html, url) {
  if (!html) {
    return {
      score: 0,
      level: "Error",
      title: "Analysis Failed",
      subtitle: "Could not fetch website content",
      summary: "The website content could not be retrieved. The site may be blocking automated access.",
      concerns: [],
      dataTypes: [],
      goodSigns: [],
      riskFactors: 0,
      details: []
    };
  }

  let score = 30;
  const concerns = [];
  const goodSigns = [];
  const detectedDataTypes = [];
  const lowerHtml = html.toLowerCase();

  const detectedTrackers = [];
  for (const tracker of TRACKING_DOMAINS) {
    if (lowerHtml.includes(tracker.toLowerCase())) {
      detectedTrackers.push(tracker);
    }
  }

  if (detectedTrackers.length > 0) {
    const trackerPenalty = Math.min(detectedTrackers.length * 5, 25);
    score += trackerPenalty;
    concerns.push({
      label: `Tracking scripts from ${detectedTrackers.length} domain(s) detected`,
      severity: detectedTrackers.length > 5 ? "high" : "medium",
      weight: trackerPenalty
    });
  }

  const scriptMatches = html.match(/<script[^>]*src=["'][^"']*["']/gi) || [];
  const suspiciousScripts = scriptMatches.filter(s =>
    TRACKING_INDICATOR_SCRIPTS.some(p => p.test(s))
  );
  if (suspiciousScripts.length > 0) {
    score += Math.min(suspiciousScripts.length * 3, 15);
    concerns.push({
      label: `${suspiciousScripts.length} tracking script(s) found in page`,
      severity: "medium",
      weight: Math.min(suspiciousScripts.length * 3, 15)
    });
  }

  const permissionFindings = detectPermissions(html);
  for (const p of permissionFindings) {
    score += p.weight;
    concerns.push({ label: `${p.icon} ${p.label}`, severity: p.severity, weight: p.weight });
  }

  const fingerprintPatterns = [
    /canvas.*toDataURL/i, /webgl.*getParameter/i, /getAudioContext/i,
    /navigator\.hardwareConcurrency/i, /navigator\.languages/i,
    /fingerprint/i
  ];
  const fpMatches = fingerprintPatterns.filter(p => p.test(html));
  if (fpMatches.length > 0) {
    score += 15;
    concerns.push({ label: "Browser fingerprinting techniques detected", severity: "high", weight: 15 });
  }

  const formInputs = html.match(/<input[^>]*type=["'](?:text|email|tel|password|number)["'][^>]*>/gi) || [];
  if (formInputs.length > 3) {
    score += 5;
    concerns.push({ label: `Multiple form inputs detected (${formInputs.length}) — possible data collection`, severity: "medium", weight: 5 });
  }

  const socialWidgets = html.match(/(?:facebook\.com\/like|twitter\.com\/widgets|linkedin\.com\/share|plusone|sharethis|addthis)/gi);
  if (socialWidgets && socialWidgets.length > 0) {
    score += 8;
    concerns.push({ label: "Social media widgets detected (can track visitors)", severity: "medium", weight: 8 });
  }

  const iframes = html.match(/<iframe[^>]*src=["'][^"']*["'][^>]*>/gi) || [];
  const thirdPartyIframes = iframes.filter(f => {
    try {
      const srcMatch = f.match(/src=["']([^"']+)["']/);
      if (!srcMatch) return false;
      const srcUrl = new URL(srcMatch[1], url);
      return srcUrl.hostname !== new URL(url).hostname;
    } catch (e) { return false; }
  });
  if (thirdPartyIframes.length > 0) {
    score += 8;
    concerns.push({ label: `${thirdPartyIframes.length} third-party iframe(s) embedded`, severity: "medium", weight: 8 });
  }

  for (const [type, pattern] of Object.entries(DATA_TYPE_PATTERNS)) {
    const matches = html.match(new RegExp(pattern.source, "gi"));
    if (matches && matches.length > 0) {
      detectedDataTypes.push({ type, count: matches.length });
    }
  }

  if (lowerHtml.includes("privacy") && (lowerHtml.includes("policy") || lowerHtml.includes("notice"))) {
    goodSigns.push({ label: "Has a privacy policy reference", weight: -5 });
    score -= 5;
  }

  if (lowerHtml.includes("https") && !lowerHtml.includes("http://")) {
    goodSigns.push({ label: "Uses HTTPS throughout", weight: -5 });
    score -= 5;
  }

  if (lowerHtml.includes("strict-transport-security") || lowerHtml.includes("content-security-policy")) {
    goodSigns.push({ label: "Security headers detected", weight: -5 });
    score -= 5;
  }

  if (lowerHtml.includes("x-frame-options") || lowerHtml.includes("frame-ancestors")) {
    goodSigns.push({ label: "Clickjacking protection", weight: -3 });
    score -= 3;
  }

  score = Math.max(0, Math.min(100, score));

  let level, badgeClass;
  if (score >= 70) { level = "High Risk"; badgeClass = "critical"; }
  else if (score >= 50) { level = "Elevated Risk"; badgeClass = "high"; }
  else if (score >= 30) { level = "Moderate Risk"; badgeClass = "medium"; }
  else if (score >= 15) { level = "Low Risk"; badgeClass = "low"; }
  else { level = "Permission Friendly"; badgeClass = "safe"; }

  let parsedUrl;
  try {
    parsedUrl = new URL(url);
  } catch (e) {
    parsedUrl = new URL("https://unknown.invalid");
  }

  const permissionNames = permissionFindings.map(p => p.name.toLowerCase());
  const permissionList = permissionNames.length > 3
    ? permissionNames.slice(0, 3).join(", ") + " and more"
    : permissionNames.join(", ");

  let summary = "";
  if (score >= 50) {
    summary = `${parsedUrl.hostname} requests sensitive permissions (${permissionList || "extensive tracking and data collection"}). High risk of data misuse — consider whether it really needs that access.`;
  } else if (score >= 25) {
    summary = `${parsedUrl.hostname} requests some permissions (${permissionList || "moderate tracking"}). Review what you're comfortable allowing before proceeding.`;
  } else {
    summary = `${parsedUrl.hostname} requests minimal permissions. Few privacy concerns detected.`;
  }

  return {
    score,
    level,
    badgeClass,
    title: parsedUrl.hostname,
    subtitle: url,
    summary,
    concerns,
    dataTypes: detectedDataTypes,
    goodSigns,
    riskFactors: concerns.length,
    details: concerns.map(c => ({ text: c.label, passed: false, severity: c.severity }))
      .concat(goodSigns.map(g => ({ text: g.label, passed: true, severity: "low" })))
  };
}

async function fetchWebsite(url) {
  try {
    new URL(url);
  } catch (e) {
    throw new Error("Invalid URL. Please enter a valid website URL starting with http:// or https://");
  }

  const response = await new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: "FETCH_URL",
      url: url
    }, (result) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(result);
    });
  });

  if (!response || !response.success) {
    throw new Error(response?.error || "Failed to fetch website content");
  }

  return response.html;
}
