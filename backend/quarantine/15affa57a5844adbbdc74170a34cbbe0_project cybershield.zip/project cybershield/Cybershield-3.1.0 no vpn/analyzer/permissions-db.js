const PERMISSIONS_DB = {
  // === Chrome API Permissions ===
  "activeTab": {
    category: "Access",
    risk: "low",
    explanation: "Can access the currently active tab when you click the extension icon. Only active when you explicitly interact with the extension.",
    details: "This is a minimal permission. The extension can only see the current tab URL and content when you click its toolbar button.",
    examples: ["Reading the current page URL", "Injecting scripts into the active tab"]
  },
  "tabs": {
    category: "Access",
    risk: "medium",
    explanation: "Can see and interact with ALL your browser tabs, including their URLs and titles, without you clicking anything.",
    details: "The extension can enumerate all open tabs, read their URLs, titles, and favicons, and listen for tab events (created, updated, moved).",
    examples: ["Tracking which websites you visit", "Reading URLs of all open tabs", "Monitoring tab activity"]
  },
  "tabCapture": {
    category: "Capture",
    risk: "high",
    explanation: "Can capture the contents of any tab, including video and audio. This is extremely powerful and rarely needed.",
    details: "Captures visible tab content as a stream. Can record what you see and hear in any tab.",
    examples: ["Screen recording", "Capturing video calls", "Recording audio from tabs"]
  },
  "topSites": {
    category: "Data",
    risk: "medium",
    explanation: "Can read your most visited websites (new tab page data). Reveals your browsing habits.",
    details: "Accesses the list of sites that appear on Chrome's new tab page, which are your most frequently visited sites.",
    examples: ["Showing most visited sites", "Building a browsing profile"]
  },
  "browsingData": {
    category: "Data",
    risk: "high",
    explanation: "Can DELETE your browsing data (history, cookies, cache, passwords) without asking. This can permanently destroy your data.",
    details: "Can remove browsing history, download history, cookies, cached data, passwords, autofill data, and more.",
    examples: ["Clearing browser history", "Deleting all cookies", "Removing saved passwords"]
  },
  "history": {
    category: "Data",
    risk: "high",
    explanation: "Can READ your entire browsing history and ADD entries to it. Reveals every website you've ever visited.",
    details: "Full access to chrome.history API - can search, read, add, and modify your complete browsing history.",
    examples: ["Reading your browsing history", "Adding fake history entries", "Tracking all sites visited"]
  },
  "bookmarks": {
    category: "Data",
    risk: "medium",
    explanation: "Can read, create, modify, and delete all your bookmarks and bookmark folders.",
    details: "Full access to chrome.bookmarks API. Can see all saved bookmarks, add new ones, or delete existing ones.",
    examples: ["Reading your bookmarks", "Adding bookmarks without permission", "Deleting bookmarks"]
  },
  "downloads": {
    category: "Data",
    risk: "medium",
    explanation: "Can see all your downloads, start new downloads, and even open downloaded files.",
    details: "Access to chrome.downloads API - can list downloads, initiate new downloads, pause/resume, and open files.",
    examples: ["Tracking what you download", "Downloading files without consent", "Opening downloaded files"]
  },
  "management": {
    category: "System",
    risk: "high",
    explanation: "Can enable, disable, or UNINSTALL other extensions and apps. Can modify Chrome's configuration.",
    details: "Can manage all installed extensions, read their details, enable/disable them, and even uninstall them.",
    examples: ["Disabling your security extensions", "Uninstalling other extensions", "Reading extension data"]
  },
  "privacy": {
    category: "System",
    risk: "medium",
    explanation: "Can change Chrome's privacy settings, including safe browsing,Incognito mode behavior, and Do Not Track.",
    details: "Can modify privacy-related Chrome settings programmatically.",
    examples: ["Disabling safe browsing", "Changing Incognito settings", "Modifying privacy preferences"]
  },
  "sessions": {
    category: "System",
    risk: "medium",
    explanation: "Can access and modify Chrome's session data, including recently closed tabs and Windows.",
    details: "Can read and manipulate session restore data, recently closed tabs, and device sessions.",
    examples: ["Reading recently closed tabs", "Modifying session data"]
  },
  "contextMenus": {
    category: "UI",
    risk: "low",
    explanation: "Can add items to the right-click menu on web pages.",
    details: "Adds custom options to Chrome's context menu. The extension defines what appears, but you choose to click it.",
    examples: ["Adding 'Search with...' to right-click menu", "Custom context menu options"]
  },
  "desktopCapture": {
    category: "Capture",
    risk: "high",
    explanation: "Can capture your entire screen or specific windows, not just browser tabs.",
    details: "Can record your desktop, any application window, or the entire screen.",
    examples: ["Screen recording", "Capturing desktop activity", "Recording any application"]
  },
  "identity": {
    category: "Auth",
    risk: "medium",
    explanation: "Can use Chrome's identity system to authenticate with Google and other services on your behalf.",
    details: "Can get OAuth2 tokens for Google accounts and other identity providers. May access your Google profile.",
    examples: ["Signing in with Google", "Getting OAuth tokens", "Accessing Google APIs"]
  },
  "idle": {
    category: "System",
    risk: "low",
    explanation: "Can detect when your computer is idle (no keyboard/mouse activity).",
    details: "Can query whether the system is active, idle, or locked.",
    examples: ["Checking if user is away", "Running tasks when idle"]
  },
  "notifications": {
    category: "UI",
    risk: "low",
    explanation: "Can show desktop notifications (the pop-up messages in the corner of your screen).",
    details: "Can create, update, and clear desktop notifications. Cannot track if you clicked them.",
    examples: ["Showing alert messages", "Displaying status updates"]
  },
  "pageCapture": {
    category: "Capture",
    risk: "medium",
    explanation: "Can save any web page as a complete PDF, capturing exactly what you see.",
    details: "Captures the visible content of a tab as a PDF document.",
    examples: ["Saving pages as PDF", "Archiving web content"]
  },
  "power": {
    category: "System",
    risk: "low",
    explanation: "Can prevent your computer from going to sleep or screen from dimming.",
    details: "Can request that the system stay awake or allow it to sleep normally.",
    examples: ["Keeping screen on during video playback"]
  },
  "printing": {
    category: "System",
    risk: "low",
    explanation: "Can send documents to your printer.",
    details: "Can programmatically print web pages or documents.",
    examples: ["Auto-printing content", "Print-to-PDF features"]
  },
  "proxy": {
    category: "Network",
    risk: "high",
    explanation: "Can route ALL your internet traffic through a proxy server, potentially intercepting everything you do online.",
    details: "Can change Chrome's proxy settings, directing all HTTP/HTTPS traffic through specified servers. This can be used for traffic interception.",
    examples: ["Routing traffic through a proxy", "Intercepting web requests", "Man-in-the-middle potential"]
  },
  "webNavigation": {
    category: "Access",
    risk: "medium",
    explanation: "Can monitor ALL navigation events across all tabs - every page load, redirect, and history change.",
    details: "Listens for navigations, redirects, frame navigations, and history state changes across all tabs.",
    examples: ["Tracking every page you visit", "Monitoring redirects", "Logging navigation events"]
  },
  "webRequest": {
    category: "Network",
    risk: "high",
    explanation: "Can intercept and modify ALL web requests and responses. Can see everything your browser sends and receives.",
    details: "Full access to HTTP/HTTPS requests. Can read headers, cookies, form data, and modify requests in-flight. With blocking permission, can completely block requests.",
    examples: ["Reading all HTTP headers", "Modifying API requests", "Blocking websites", "Stealing cookies in transit"]
  },
  "webRequestBlocking": {
    category: "Network",
    risk: "high",
    explanation: "Can completely BLOCK any web request. The extension can prevent pages from loading entirely.",
    details: "Combined with webRequest, allows synchronous blocking of all network requests. Can prevent any page from loading.",
    examples: ["Blocking websites entirely", "Preventing ads from loading", "Intercepting all traffic"]
  },
  "declarativeNetRequest": {
    category: "Network",
    risk: "medium",
    explanation: "Can block or modify web requests using predefined rules. Less powerful than webRequest but still can control what loads.",
    details: "Uses rule-based request modification. Can block, redirect, or modify headers for matching URLs.",
    examples: ["Blocking ad domains", "Redirecting URLs", "Modifying request headers"]
  },
  "declarativeNetRequestWithHostAccess": {
    category: "Network",
    risk: "medium",
    explanation: "Like declarativeNetRequest but can also modify requests to hosts the extension has permission for.",
    details: "Extends declarativeNetRequest with ability to modify (not just block) requests to permitted hosts.",
    examples: ["Modifying API requests", "Adding headers to specific sites"]
  },
  "declarativeNetRequestFeedback": {
    category: "Network",
    risk: "low",
    explanation: "Can see logs of how declarativeNetRequest rules are being applied. Read-only diagnostic permission.",
    details: "Allows the extension to see which rules matched and were applied to requests.",
    examples: ["Debugging rule matching", "Logging blocked requests"]
  },
  "scripting": {
    category: "Access",
    risk: "medium",
    explanation: "Can execute arbitrary JavaScript code on any web page. Can read and modify page content.",
    details: "Can inject and execute scripts in the context of web pages. Can access DOM, cookies, and page data.",
    examples: ["Injecting scripts into pages", "Reading page content", "Modifying page appearance"]
  },
  "storage": {
    category: "Data",
    risk: "low",
    explanation: "Can store data locally in the browser. This is how extensions save their settings and data.",
    details: "Access to chrome.storage API for persistent local storage. Data stays on your machine.",
    examples: ["Saving extension settings", "Caching data locally"]
  },
  "unlimitedStorage": {
    category: "Data",
    risk: "low",
    explanation: "Can store unlimited data locally. Normal extensions have a 5MB limit; this removes it.",
    details: "Removes the storage quota for extension data. Can use as much disk space as needed.",
    examples: ["Storing large databases locally", "Caching extensive data"]
  },
  "clipboardRead": {
    category: "Data",
    risk: "medium",
    explanation: "Can read whatever is currently in your clipboard (the text you copied with Ctrl+C).",
    details: "Can access clipboard contents programmatically. May read sensitive copied data.",
    examples: ["Pasting copied content", "Reading clipboard text"]
  },
  "clipboardWrite": {
    category: "Data",
    risk: "low",
    explanation: "Can write text to your clipboard. Replaces whatever you previously copied.",
    details: "Can programmatically copy text to the system clipboard.",
    examples: ["Copy-to-clipboard functionality"]
  },
  "geolocation": {
    category: "Data",
    risk: "medium",
    explanation: "Can determine your physical location using your IP address or other methods.",
    details: "Access to geolocation API to get approximate or precise location.",
    examples: ["Showing nearby content", "Location-based features"]
  },
  "tts": {
    category: "System",
    risk: "low",
    explanation: "Can speak text aloud using your computer's text-to-speech engine.",
    details: "Access to Chrome's text-to-speech functionality.",
    examples: ["Reading text aloud", "Accessibility features"]
  },
  "vpnProvider": {
    category: "Network",
    risk: "high",
    explanation: "Can create and manage VPN connections. Can route ALL your network traffic through the extension.",
    details: "Can create virtual network interfaces and route system traffic through the extension. Effectively a VPN.",
    examples: ["Creating VPN tunnels", "Routing all system traffic", "Network-level interception"]
  },
  "debugger": {
    category: "System",
    risk: "high",
    explanation: "Can attach Chrome's debugger to any tab, giving FULL control over the page including network interception, DOM manipulation, and JavaScript execution.",
    details: "Full Chrome DevTools Protocol access. Can inspect, modify, and intercept anything in any tab. This is extremely powerful.",
    examples: ["Full page inspection", "Network interception", "DOM manipulation", "JavaScript debugging"]
  },
  "dns": {
    category: "Network",
    risk: "medium",
    explanation: "Can resolve DNS queries, potentially tracking which domains you visit.",
    details: "Can perform DNS lookups to resolve domain names to IP addresses.",
    examples: ["DNS resolution", "Domain lookup features"]
  },
  "loginState": {
    category: "Auth",
    risk: "medium",
    explanation: "Can detect whether you're signed into Chrome and get your signed-in account email.",
    details: "Can check Chrome sign-in status and read the primary account email address.",
    examples: ["Checking sign-in status", "Reading account email"]
  },
  "passwordsPrivate": {
    category: "Data",
    risk: "high",
    explanation: "Can read and manage your saved passwords. This includes usernames and passwords for all websites.",
    details: "Private API for password management. Can enumerate, read, and modify saved credentials.",
    examples: ["Reading saved passwords", "Managing password store", "Exporting credentials"]
  },
  "settingsPrivate": {
    category: "System",
    risk: "high",
    explanation: "Can read and modify Chrome's internal settings, including startup pages, search engines, and more.",
    details: "Private API for Chrome settings. Can read and write to Chrome's preferences.",
    examples: ["Changing startup pages", "Modifying search engine", "Changing browser settings"]
  },
  "contentSettings": {
    category: "System",
    risk: "high",
    explanation: "Can change what content is allowed on websites - JavaScript, cookies, plugins, popups, etc.",
    details: "Can modify content settings per-site, including enabling/disabling JavaScript, cookies, plugins, and more.",
    examples: ["Enabling JavaScript on sites", "Managing cookie permissions", "Controlling plugin access"]
  },
  "nativeMessaging": {
    category: "System",
    risk: "high",
    explanation: "Can communicate with native programs installed on your computer. Can execute system commands.",
    details: "Can send/receive messages to/from native applications. Can execute arbitrary commands on the host system.",
        examples: ["Running system commands", "Communicating with installed software", "Accessing file system"]
  },
  "platformKeys": {
    category: "System",
    risk: "high",
    explanation: "Can access your system's cryptographic keys and certificates, potentially impersonating your machine.",
    details: "Can access platform TLS keys and client certificates used for mutual TLS authentication.",
    examples: ["Accessing TLS certificates", "Using system keys for authentication"]
  },
  "certificateProvider": {
    category: "System",
    risk: "high",
    explanation: "Can provide custom certificates to Chrome, potentially enabling man-in-the-middle attacks.",
    details: "Can register certificates that Chrome will trust for HTTPS connections.",
    examples: ["Injecting custom certificates", "MITM potential"]
  },
  "copresence": {
    category: "Network",
    risk: "medium",
    explanation: "Can discover nearby devices using Bluetooth or other wireless technologies.",
    details: "Can detect and communicate with nearby Chrome devices.",
    examples: ["Device discovery", "Nearby sharing features"]
  },
  "gcm": {
    category: "Network",
    risk: "medium",
    explanation: "Can use Google Cloud Messaging to send and receive push notifications from remote servers.",
    details: "Can register for and receive push messages from Google's cloud messaging service.",
    examples: ["Receiving push notifications", "Background message handling"]
  },
  "alarms": {
    category: "System",
    risk: "low",
    explanation: "Can schedule code to run at specific times or intervals. Standard timer functionality.",
    details: "Can create alarms that fire at specific times or intervals, waking the service worker.",
    examples: ["Running periodic checks", "Scheduling tasks"]
  },
  "offscreen": {
    category: "System",
    risk: "low",
    explanation: "Can create hidden offscreen documents for background processing without showing a visible page.",
    details: "Creates invisible documents for tasks that need DOM access but shouldn't be visible.",
    examples: ["Background audio processing", "DOM manipulation offscreen"]
  },

  // === Host Permissions ===
  "<all_urls>": {
    category: "Host Access",
    risk: "high",
    explanation: "Can access ALL websites. This is the broadest possible host permission - the extension can read and modify content on every page you visit.",
    details: "Grants access to every URL pattern. Combined with activeTab or scripting, can inject code into any website.",
    examples: ["Accessing any website", "Reading page content everywhere", "Injecting scripts into any site"]
  },
  "*://*/*": {
    category: "Host Access",
    risk: "high",
    explanation: "Can access ALL websites over HTTP and HTTPS. Equivalent to <all_urls> for web traffic.",
    details: "Matches all HTTP and HTTPS URLs. Same practical effect as <all_urls>.",
    examples: ["Accessing any website", "Reading all web content"]
  },
  "http://*/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access all HTTP (non-secure) websites. Cannot access HTTPS sites.",
    details: "Matches all HTTP URLs only. Non-encrypted traffic.",
    examples: ["Accessing unencrypted websites"]
  },
  "https://*/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access all HTTPS (secure) websites. This covers most modern websites.",
    details: "Matches all HTTPS URLs. Since most sites use HTTPS now, this is very broad.",
    examples: ["Accessing any secure website"]
  },
  "file://*": {
    category: "Host Access",
    risk: "high",
    explanation: "Can read local files on your computer. This can access your documents, photos, and any file your browser can open.",
    details: "Matches file:// URLs, allowing access to local filesystem content through the browser.",
    examples: ["Reading local files", "Accessing documents on disk"]
  },
  "chrome://*": {
    category: "Host Access",
    risk: "high",
    explanation: "Can access Chrome's internal pages, including settings, extensions page, and other privileged pages.",
    details: "Matches Chrome's internal URL scheme. Can interact with browser internals.",
    examples: ["Reading Chrome settings", "Interacting with extension pages"]
  },
  "chrome-extension://*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access other extensions' pages and resources.",
    details: "Matches extension URLs, allowing interaction with other installed extensions.",
    examples: ["Reading other extension data", "Cross-extension communication"]
  },
  "*://*.google.com/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access Google services including Search, Gmail, Drive, YouTube, and more.",
    details: "Matches all Google subdomains and paths. Covers most Google services.",
    examples: ["Reading Google search results", "Accessing Gmail", "Interacting with Google services"]
  },
  "*://*.facebook.com/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access Facebook, Instagram, and Messenger (all Meta properties on facebook.com domain).",
    details: "Matches all Facebook subdomains.",
    examples: ["Reading Facebook content", "Accessing Facebook data"]
  },
  "*://*.twitter.com/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access Twitter/X and all its subdomains.",
    details: "Matches all Twitter subdomains.",
    examples: ["Reading tweets", "Accessing Twitter data"]
  },
  "*://*.linkedin.com/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access LinkedIn, including your professional profile and network data.",
    details: "Matches all LinkedIn subdomains.",
    examples: ["Reading LinkedIn profile", "Accessing professional network data"]
  },
  "*://*.amazon.com/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access Amazon, including your shopping history, wish lists, and potentially payment information.",
    details: "Matches all Amazon subdomains.",
    examples: ["Reading Amazon listings", "Accessing order history"]
  },
  "*://*.github.com/*": {
    category: "Host Access",
    risk: "medium",
    explanation: "Can access GitHub, including your repositories, code, and account data.",
    details: "Matches all GitHub subdomains.",
    examples: ["Reading repositories", "Accessing code repositories"]
  },

  // === Content Script Matches ===
  "*://*.google.com/search*": {
    category: "Host Access",
    risk: "low",
    explanation: "Can run code specifically on Google search result pages. Narrow, purpose-specific access.",
    details: "Only matches Google search URLs. Cannot access other Google services.",
    examples: ["Modifying search results", "Adding search annotations"]
  },

  // === Content Security Policy ===
  "content_security_policy": {
    category: "Security",
    risk: "medium",
    explanation: "Defines what scripts and resources the extension can load. A permissive CSP can be a security risk.",
    details: "Controls which scripts, styles, and other resources can be loaded by the extension.",
    examples: ["Allowing inline scripts", "Loading remote resources"]
  },

  // === CSP Extensions ===
  "sandbox": {
    category: "Security",
    risk: "medium",
    explanation: "Can create sandboxed pages with relaxed security. Used for running untrusted code safely.",
    details: "Declares sandboxed pages that run in an isolated environment.",
    examples: ["Running third-party code", "Isolating untrusted content"]
  }
};

const PERMISSION_CATEGORIES = {
  "Access": { icon: "\uD83D\uDD0D", color: "#58a6ff", description: "Can access browser tabs and content" },
  "Data": { icon: "\uD83D\uDCCB", color: "#d29922", description: "Can read or modify your data" },
  "Network": { icon: "\uD83C\uDF10", color: "#f85149", description: "Can intercept network traffic" },
  "System": { icon: "\u2699\uFE0F", color: "#a855f7", description: "Can modify system/browser settings" },
  "Capture": { icon: "\uD83D\uDCF7", color: "#f85149", description: "Can capture screen/audio content" },
  "Auth": { icon: "\uD83D\uDD11", color: "#d29922", description: "Can access authentication data" },
  "UI": { icon: "\uD83C\uDFA8", color: "#3fb950", description: "Can modify browser interface" },
  "Host Access": { icon: "\uD83C\uDFE0", color: "#f85149", description: "Can access specific websites" },
  "Security": { icon: "\uD83D\uDEE1\uFE0F", color: "#a855f7", description: "Security policy configuration" }
};

const RISK_LEVELS = {
  safe: { label: "Safe", color: "#3fb950", bg: "rgba(63, 185, 80, 0.15)", border: "rgba(63, 185, 80, 0.3)", description: "Minimal permissions, low risk" },
  low: { label: "Low Risk", color: "#3fb950", bg: "rgba(63, 185, 80, 0.15)", border: "rgba(63, 185, 80, 0.3)", description: "Limited permissions, unlikely to cause harm" },
  medium: { label: "Medium Risk", color: "#d29922", bg: "rgba(210, 153, 34, 0.15)", border: "rgba(210, 153, 34, 0.3)", description: "Moderate permissions, review carefully" },
  high: { label: "High Risk", color: "#f85149", bg: "rgba(248, 81, 73, 0.15)", border: "rgba(248, 81, 73, 0.3)", description: "Powerful permissions, potential for misuse" },
  critical: { label: "Critical", color: "#ff4444", bg: "rgba(255, 68, 68, 0.15)", border: "rgba(255, 68, 68, 0.3)", description: "Extremely dangerous permissions, high risk of abuse" }
};
