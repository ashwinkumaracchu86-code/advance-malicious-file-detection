importScripts("phishing-detector.js");

const KNOWN_BRANDS = [
  "paypal", "apple", "google", "amazon", "microsoft", "facebook", "netflix",
  "instagram", "twitter", "linkedin", "dropbox", "icloud", "chase", "wellsfargo",
  "bankofamerica", "citibank", "venmo", "zelle", "coinbase", "binance",
  "ebay", "walmart", "target", "costco", "bestbuy", "adobe", "zoom", "slack",
  "github", "gitlab", "bitbucket", "notion", "figma", "canva", "spotify",
  "steam", "epicgames", "roblox", "discord", "twitch", "youtube", "tiktok",
  "whatsapp", "telegram", "signal", "protonmail", "gmail", "outlook", "yahoo"
];

const BUILTIN_SAFE_DOMAINS = [
  "google.com", "google.co.uk", "google.ca", "google.de", "google.fr",
  "google.co.jp", "google.com.au", "google.co.in", "google.com.br",
  "youtube.com", "youtu.be",
  "facebook.com", "fb.com", "instagram.com", "twitter.com", "x.com",
  "linkedin.com", "reddit.com", "pinterest.com", "tumblr.com",
  "wikipedia.org", "wikimedia.org",
  "amazon.com", "amazon.co.uk", "amazon.de", "amazon.ca", "amazon.co.jp",
  "amazon.com.au", "amazon.in", "amazon.com.br",
  "microsoft.com", "live.com", "outlook.com", "office.com", "office365.com",
  "onedrive.com", "teams.microsoft.com", "azure.com", "visualstudio.com",
  "apple.com", "icloud.com", "apps.apple.com", "developer.apple.com",
  "github.com", "github.io", "gitlab.com", "bitbucket.org",
  "stackoverflow.com", "stackexchange.com", "superuser.com",
  "netflix.com", "hulu.com", "disneyplus.com", "hbomax.com", "primevideo.com",
  "spotify.com", "open.spotify.com",
  "t.co",
  "whatsapp.com", "web.whatsapp.com",
  "telegram.org", "web.telegram.org",
  "zoom.us", "us02web.zoom.us",
  "slack.com", "app.slack.com",
  "dropbox.com",
  "adobe.com", "acrobat.com", "behance.net",
  "walmart.com", "target.com", "costco.com", "bestbuy.com",
  "ebay.com", "paypal.com", "venmo.com",
  "chase.com", "wellsfargo.com", "bankofamerica.com", "citi.com",
  "coinbase.com", "binance.com",
  "twitch.tv",
  "roblox.com",
  "discord.com", "discord.gg",
  "tiktok.com",
  "notion.so", "figma.com", "canva.com",
  "duolingo.com", "khanacademy.org", "coursera.org", "udemy.com",
  "medium.com", "substack.com",
  "quora.com", "yahoo.com", "aol.com",
  "cnn.com", "bbc.com", "bbc.co.uk", "reuters.com", "apnews.com",
  "nytimes.com", "washingtonpost.com", "theguardian.com",
  "weather.com", "accuweather.com",
  "maps.google.com", "translate.google.com",
  "drive.google.com", "docs.google.com", "sheets.google.com", "slides.google.com",
  "mail.google.com", "calendar.google.com",
  "store.steampowered.com", "steampowered.com",
  "epicgames.com",
  "play.google.com", "apps.google.com",
  "samsung.com", "sony.com", "nvidia.com", "amd.com", "intel.com",
  "docker.com", "docker.io",
  "npmjs.com", "yarnpkg.com",
  "digitalocean.com", "heroku.com", "vercel.com", "netlify.com",
  "cloudflare.com",
  "mozilla.org", "firefox.com",
  "archive.org",
  "imdb.com", "rottentomatoes.com",
  "tripadvisor.com", "booking.com", "airbnb.com",
  "uber.com", "lyft.com",
  "doordash.com", "ubereats.com", "grubhub.com",
  "etsy.com",
  "zillow.com", "realtor.com",
  "webmd.com", "mayoclinic.org", "healthline.com",
  "investopedia.com", "finance.yahoo.com",
  "chegg.com", "quizlet.com",
  "slack.com", "trello.com", "asana.com", "monday.com",
  "1password.com", "lastpass.com", "bitwarden.com"
];

const SUSPICIOUS_WORDS = [
  "login", "verify", "free", "secure", "account", "update",
  "confirm", "password", "banking", "alert", "signin", "paypal",
  "ebay", "lucky", "winner", "prize", "claim", "gift",
  "urgent", "suspended", "locked", "unauthorized", "activity",
  "billing", "payment", "refund", "tax", "irs", "police"
];

const SUSPICIOUS_TLDS = [".xyz", ".top", ".buzz", ".gq", ".ml", ".cf", ".tk", ".ga", ".cc", ".pw", ".work", ".click"];

const HOMOGLYPH_MAP = {
  "\u0430": "a", "\u0435": "e", "\u043E": "o", "\u0440": "p",
  "\u0441": "c", "\u0443": "y", "\u0445": "x", "\u0456": "i",
  "\u0501": "o", "\u050D": "j",
  "\u0251": "a", "\u0261": "g", "\u0285": "j", "\u029C": "H",
  "\u04BB": "h", "\u04CF": "l", "\u2010": "-", "\u2011": "-",
  "\u2012": "-", "\u2013": "-", "\u2014": "-", "\u2015": "-",
  "\u2026": ".", "\uFF0E": "."
};

const AD_DOMAINS = [
  "doubleclick.net", "googlesyndication.com", "googleadservices.com",
  "google-analytics.com", "googletagmanager.com", "adservice.google.com",
  "pagead2.googlesyndication.com", "tpc.googlesyndication.com",
  "pagead2.googleadssyndication.com",
  "facebook.com/tr", "facebook.net", "fbcdn.net",
  "analytics.twitter.com", "ads-twitter.com", "syndication.twitter.com",
  "ad.turn.com", "ads.yahoo.com", "ad.yieldmanager.com",
  "ad.doubleclick.net", "ad.amazon.com",
  "adnxs.com", "adsrvr.org", "adtechus.com",
  "criteo.com", "criteo.net", "static.criteo.net",
  "taboola.com", "tabs.taboola.com", "cdn.taboola.com",
  "outbrain.com", "widgets.outbrain.com",
  "moat.com", "moatads.com",
  "scorecardresearch.com", "sb.scorecardresearch.com",
  "quantserve.com", "quantcast.com",
  "bluekai.com", "exelator.com",
  "demdex.net", "everesttech.net",
  "rubiconproject.com", "rubicon.com",
  "pubmatic.com", "ads.pubmatic.com",
  "openx.net", "servedbyopenx.com",
  "casalemedia.com", "indexww.com",
  "sharethrough.com", "lijit.com",
  "bidswitch.net", "bidswitch.com",
  "media.net",
  "hotjar.com", "static.hotjar.com",
  "mixpanel.com", "cdn.mxpnl.com",
  "segment.com", "cdn.segment.com",
  "amplitude.com", "cdn.amplitude.com",
  "heap.io", "cdn.heapanalytics.com",
  "fullstory.com", "rs.fullstory.com",
  "logrocket.com", "cdn.logrocket.com",
  "newrelic.com", "js-agent.newrelic.com",
  "sentry.io", "browser.sentry-cdn.com",
  "chartbeat.com", "static.chartbeat.com",
  "parsely.com", "static.parsely.com",
  "optimizely.com", "cdn.optimizely.com",
  "vwo.com", "dev.visualwebsiteoptimizer.com",
  "convert.com",
  "clicktale.com", "clicktale.net",
  "kissmetrics.com", "trk.kissmetrics.com",
  "mouseflow.com", "cdn.mouseflow.com",
  "crazyegg.com", "script.crazyegg.com",
  "inspectlet.com",
  "bing.com/msclkid",
  "pinterest.com/ct",
  "snap.com/pixel",
  "tiktok.com/pixel",
  "linkedin.com/insight",
  "spotxchange.com", "spotx.tv",
  "smartyads.com",
  "adcolony.com", "inmobi.com", "smaato.net",
  "mintegral.com", "ironsrc.com", "applovin.com",
  "vungle.com", "fyber.com", "tapjoy.com",
  "chartboost.com", "altitude-arena.com",
  "serving-sys.com", "servedby.byspotx.com",
  "adnxs.com", "adsafeprotected.com",
  "voicefive.com", "cm.everesttech.net",
  "ads.linkedin.com", "tracking.mixpanel.com",
  "appnexus.com", "adzerk.net", "adform.net", "adformdsp.net",
  "adscale.de", "adition.com", "adkernel.com", "adkerneladn.com",
  "admanmedia.com", "admixer.net", "adyoulike.com",
  "amazon-adsystem.com", "aax.amazon-adsystem.com", "aax-eu.amazon-adsystem.com",
  "aniview.com", "atwola.com", "avocet.io", "betweendigital.com",
  "bidtellect.com", "brightroll.com", "brsrvr.com", "chitika.net",
  "colossusssp.com", "connatix.com", "contextweb.com", "convergetrack.com",
  "cpx.to", "crwdcntrl.net", "datonics.com", "dianomi.com",
  "dotomi.com", "e-planning.net", "eyeota.net", "flashtalking.com",
  "gumgum.com", "hooklogic.com", "imonomy.com", "kargo.com",
  "liveintent.com", "lkqd.net", "media6degrees.com", "mgid.com",
  "mopub.com", "nativeroll.tv", "nativo.com", "netseer.com",
  "onetag.com", "openx.com", "partnerize.com", "parrable.com",
  "popads.net", "popcash.net", "projectwonderful.com", "propellads.com",
  "pubnative.net", "pulsepoint.com", "revcontent.com", "rlcdn.com",
  "smartadserver.com", "spot.im", "stackadapt.com", "steelhousemedia.com",
  "teads.tv", "triplelift.com", "tubemogul.com", "turn.com",
  "undertone.com", "unrulymedia.com", "viantinc.com", "vibrantmedia.com",
  "videologygroup.com", "viglink.com", "w55c.net", "xapads.com",
  "yieldbot.com", "yieldlab.net", "yieldmo.com", "zergnet.com",
  "1rx.io", "adservice.google.com", "pagead2.googleadservices.com",
  "fundingchoices.google.com", "adssettings.google.com"
];

const AD_BLOCKER_START_ID = 5000;
let nextAdRuleId = AD_BLOCKER_START_ID;

const YOUTUBE_ADS_URL_PATTERNS = [];

const DYNAMIC_RULE_START_ID = 1000;
const TEMP_RULE_START_ID = 9000;
const BYPASS_ALLOW_RULE_ID = 999;
let nextRuleId = DYNAMIC_RULE_START_ID;
let nextTempRuleId = TEMP_RULE_START_ID;

const MULTI_PART_TLDS = new Set([
  "co.uk", "org.uk", "ac.uk", "gov.uk", "me.uk", "net.uk", "sch.uk",
  "com.au", "net.au", "org.au", "edu.au", "gov.au", "asn.au", "id.au",
  "co.nz", "net.nz", "org.nz", "ac.nz", "govt.nz",
  "co.jp", "ne.jp", "or.jp", "ac.jp", "go.jp", "ad.jp",
  "co.in", "net.in", "org.in", "ac.in", "gov.in", "res.in",
  "com.br", "net.br", "org.br", "gov.br",
  "co.za", "org.za", "net.za", "gov.za", "ac.za",
  "com.mx", "org.mx", "net.mx", "gob.mx",
  "com.ar", "org.ar", "net.ar", "gob.ar",
  "com.tr", "org.tr", "net.tr", "gov.tr", "edu.tr",
  "com.sg", "org.sg", "net.sg", "edu.sg", "gov.sg",
  "com.hk", "org.hk", "net.hk", "edu.hk", "gov.hk",
  "com.tw", "org.tw", "net.tw", "edu.tw", "gov.tw",
  "co.kr", "or.kr", "ne.kr", "re.kr", "pe.kr", "go.kr", "ac.kr",
  "co.id", "or.id", "web.id", "ac.id", "go.id", "sch.id",
  "com.my", "org.my", "net.my", "edu.my", "gov.my",
  "co.th", "or.th", "in.th", "ac.th", "go.th",
  "com.cn", "org.cn", "net.cn", "gov.cn", "edu.cn", "ac.cn",
  "com.ph", "org.ph", "net.ph", "gov.ph", "edu.ph",
  "co.il", "org.il", "net.il", "ac.il", "gov.il",
  "com.pl", "org.pl", "net.pl", "gov.pl", "edu.pl",
  "com.ua", "org.ua", "net.ua", "gov.ua"
]);

let dnrUpdateQueue = Promise.resolve();

function enqueueDnrUpdate(task) {
  dnrUpdateQueue = dnrUpdateQueue.then(task).catch(err => {
    console.warn("[CyberShield] DeclarativeNetRequest update failed:", err);
  });
  return dnrUpdateQueue;
}

function normalizeForHomoglyph(str) {
  return [...str].map(c => HOMOGLYPH_MAP[c] || c).join("");
}

function getRegistrableDomain(hostname) {
  const parts = hostname.split(".");
  if (parts.length < 3) return hostname;
  const lastTwo = parts.slice(-2).join(".");
  if (MULTI_PART_TLDS.has(lastTwo)) {
    return parts.slice(-3).join(".");
  }
  return parts.slice(-2).join(".");
}

function sanitizeDomain(value) {
  let v = String(value || "").trim().toLowerCase();
  if (!v) return "";
  try {
    const url = new URL(v.includes("://") ? v : "http://" + v);
    v = url.hostname;
  } catch (e) {}
  v = v.replace(/^\.+|\.+$/g, "");
  if (!v || v.includes(" ") || !v.includes(".")) return "";
  return v;
}

function domainMatches(hostname, domain) {
  const h = hostname.toLowerCase();
  const d = domain.toLowerCase();
  if (h === d) return true;
  if (h.endsWith("." + d)) return true;
  const www = "www." + d;
  if (h === www || h.endsWith("." + www)) return true;
  return false;
}

function isIpAddress(hostname) {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname);
}

function hasValidTld(hostname) {
  const parts = hostname.split(".");
  if (parts.length < 2) return false;
  const tld = parts[parts.length - 1];
  return tld.length >= 2 && /^[a-z]+$/.test(tld);
}

function countSuspiciousWords(url) {
  const lower = url.toLowerCase();
  let count = 0;
  for (const word of SUSPICIOUS_WORDS) {
    if (lower.includes(word)) count++;
  }
  return count;
}

function detectPhishing(hostname) {
  const flags = [];
  const normalized = normalizeForHomoglyph(hostname.toLowerCase());
  const registrable = getRegistrableDomain(normalized);
  const domainLabel = registrable.replace(/\..*/, "");

  const isKnownBrand = KNOWN_BRANDS.includes(domainLabel);
  if (!isKnownBrand) {
    for (const brand of KNOWN_BRANDS) {
      const dist = levenshteinDistance(domainLabel, brand);
      if (dist > 0 && dist <= 2 && domainLabel.length > brand.length - 3) {
        flags.push(`Possible impersonation of "${brand}" (edit distance: ${dist})`);
      }
    }
  }

  const hasHomoglyphs = [...hostname].some(c => HOMOGLYPH_MAP[c]);
  if (hasHomoglyphs) {
    flags.push("Contains homoglyph characters (possible spoofing)");
  }

  const labels = hostname.split(".");
  const suspiciousLabelPatterns = [
    /^login[-_]/i, /[-_]login$/i,
    /^secure[-_]/i, /[-_]secure$/i,
    /^verify[-_]/i, /[-_]verify$/i,
    /^account[-_]/i, /[-_]account$/i,
    /^auth[-_]/i, /[-_]auth$/i,
    /^signin[-_]/i, /[-_]signin$/i,
    /^my[-_].{1,4}$/i, /^.{1,4}[-_]my$/i
  ];

  for (const label of labels) {
    for (const pattern of suspiciousLabelPatterns) {
      if (pattern.test(label)) {
        flags.push(`Suspicious subdomain pattern: "${label}"`);
      }
    }
  }

  const hyphenCount = (hostname.match(/-/g) || []).length;
  if (hyphenCount >= 3) {
    flags.push("Excessive hyphens in domain name");
  }

  const numberCount = (hostname.match(/\d/g) || []).length;
  if (numberCount >= 4 && numberCount / hostname.length > 0.3) {
    flags.push("High ratio of numbers in domain");
  }

  if (labels.length > 4) {
    flags.push("Deeply nested subdomains");
  }

  return flags;
}

function checkCustomLists(hostname, settings) {
  const blocked = (settings.blockedDomains || []).map(sanitizeDomain).filter(Boolean);
  const safe = (settings.safeDomains || []).map(sanitizeDomain).filter(Boolean);
  const registrable = getRegistrableDomain(hostname.toLowerCase());

  for (const d of blocked) {
    if (domainMatches(hostname.toLowerCase(), d)) {
      return { match: true, type: "blocked", domain: d };
    }
  }

  for (const d of safe) {
    if (domainMatches(hostname.toLowerCase(), d)) {
      return { match: true, type: "safe", domain: d };
    }
  }

  return { match: false };
}

function isBuiltinSafeDomain(hostname) {
  const lower = hostname.toLowerCase();
  for (const domain of BUILTIN_SAFE_DOMAINS) {
    if (lower === domain || lower.endsWith("." + domain)) {
      return true;
    }
  }
  return false;
}

function analyzeUrl(url, settings, contentAnalysis) {
  const checks = [];
  let score = 50;

  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    return {
      score: 0,
      level: "High Risk",
      reasons: [{ text: "Invalid URL format", passed: false }],
      phishingFlags: [],
      customList: null,
      phishingAnalysis: null
    };
  }

  const hostname = parsed.hostname || "";
  const fullUrl = parsed.href || url;

  const customResult = checkCustomLists(hostname, settings || {});

  if (customResult.match && customResult.type === "blocked") {
    return {
      score: 0,
      level: "Blocked",
      reasons: [{ text: `Manually blocked: ${customResult.domain}`, passed: false }],
      phishingFlags: [],
      customList: customResult,
      phishingAnalysis: null
    };
  }

  if (customResult.match && customResult.type === "safe") {
    return {
      score: 100,
      level: "Safe",
      reasons: [{ text: `Manually safelisted: ${customResult.domain}`, passed: true }],
      phishingFlags: [],
      customList: customResult,
      phishingAnalysis: null
    };
  }

  const httpsCheck = parsed.protocol === "https:";
  score += httpsCheck ? 30 : -20;
  checks.push({ text: httpsCheck ? "Uses HTTPS" : "Uses HTTP (not secure)", passed: httpsCheck });

  const safeDomain = isBuiltinSafeDomain(hostname);

  const shortUrl = fullUrl.length < 50;
  const longUrl = fullUrl.length > 75;
  if (shortUrl) {
    score += 10;
    checks.push({ text: "Short URL", passed: true });
  } else if (longUrl && !safeDomain) {
    score -= 10;
    checks.push({ text: "Unusually long URL", passed: false });
  }

  const suspiciousCount = countSuspiciousWords(fullUrl);
  if (suspiciousCount > 0 && !safeDomain) {
    const penalty = Math.min(suspiciousCount * 15, 40);
    score -= penalty;
    checks.push({ text: `Contains ${suspiciousCount} suspicious keyword(s)`, passed: false });
  } else {
    checks.push({ text: "No suspicious keywords", passed: true });
  }

  const ipCheck = isIpAddress(hostname);
  if (ipCheck) {
    score -= 30;
    checks.push({ text: "IP address instead of domain name", passed: false });
  }

  const validTld = hasValidTld(hostname);
  score += validTld ? 20 : -5;
  checks.push({ text: validTld ? "Valid domain format" : "Missing or unusual TLD", passed: validTld });

  const tld = "." + hostname.split(".").pop();
  if (SUSPICIOUS_TLDS.includes(tld.toLowerCase())) {
    score -= 15;
    checks.push({ text: `Suspicious TLD (${tld})`, passed: false });
  }

  const subdomains = hostname.split(".").length - 2;
  if (subdomains > 2) {
    score -= 10;
    checks.push({ text: "Excessive subdomains", passed: false });
  } else {
    checks.push({ text: "Normal subdomain count", passed: true });
  }

  const phishingFlags = detectPhishing(hostname);
  if (phishingFlags.length > 0) {
    score -= phishingFlags.length * 20;
    for (const flag of phishingFlags) {
      checks.push({ text: flag, passed: false });
    }
  } else {
    checks.push({ text: "No phishing patterns detected", passed: true });
  }

  if (contentAnalysis && !isBuiltinSafeDomain(hostname)) {
    if (contentAnalysis.hasFakeLoginForm) {
      score -= 25;
      checks.push({ text: "Suspicious login form detected on page", passed: false });
    }
    if (contentAnalysis.hasHiddenIframes) {
      score -= 20;
      checks.push({ text: "Hidden iframes found (possible malware delivery)", passed: false });
    }
    if (contentAnalysis.hasPasswordField && !httpsCheck) {
      score -= 15;
      checks.push({ text: "Password field on non-HTTPS page", passed: false });
    }
    if (contentAnalysis.hasExternalFormAction) {
      score -= 15;
      checks.push({ text: "Form submits to external domain", passed: false });
    }
    if (contentAnalysis.hasObfuscatedScript) {
      score -= 15;
      checks.push({ text: "Obfuscated JavaScript detected", passed: false });
    }
    if (contentAnalysis.hasDataUri) {
      score -= 10;
      checks.push({ text: "Data URI used in page resources", passed: false });
    }
  } else if (contentAnalysis && isBuiltinSafeDomain(hostname)) {
    checks.push({ text: "Known safe domain - content analysis skipped", passed: true });
  }

  score = Math.max(0, Math.min(100, score));

  let level;
  if (score >= 80) level = "Safe";
  else if (score >= 50) level = "Moderate Risk";
  else level = "High Risk";

  let phishingAnalysis = null;
  if (settings && settings.phishingEnabled !== false) {
    try {
      phishingAnalysis = getPhishingAnalysis(url, settings, contentAnalysis);
    } catch (e) {
      phishingAnalysis = null;
    }
  }

  return { score, level, reasons: checks, phishingFlags, customList: null, phishingAnalysis };
}

async function updateDynamicRulesSafely({ removeRuleIds, addRules }) {
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

async function performBlockingRulesUpdate() {
  const settings = await chrome.storage.local.get(["blockedDomains"]);
  const blockedDomains = (settings.blockedDomains || []).map(sanitizeDomain).filter(Boolean);

  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules
    .filter(r => r.id >= DYNAMIC_RULE_START_ID && r.id < AD_BLOCKER_START_ID)
    .map(r => r.id);

  nextRuleId = DYNAMIC_RULE_START_ID;

  const addRules = blockedDomains.map(domain => ({
    id: nextRuleId++,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: `||${domain}`,
      resourceTypes: ["main_frame", "sub_frame"]
    }
  }));

  await updateDynamicRulesSafely({ removeRuleIds, addRules });
}

function updateBlockingRules() {
  return enqueueDnrUpdate(performBlockingRulesUpdate);
}

async function performAdBlockerRulesUpdate() {
  const settings = await chrome.storage.local.get(["adBlockerEnabled"]);
  const enabled = settings.adBlockerEnabled !== false;

  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules
    .filter(r => r.id >= AD_BLOCKER_START_ID && r.id < TEMP_RULE_START_ID)
    .map(r => r.id);

  nextAdRuleId = AD_BLOCKER_START_ID;

  const addRules = [];
  if (enabled) {
    for (const domain of AD_DOMAINS) {
      addRules.push({
        id: nextAdRuleId++,
        priority: 1,
        action: { type: "block" },
        condition: {
          urlFilter: `||${domain}`,
          resourceTypes: ["script", "image", "xmlhttprequest", "sub_frame", "font", "media"]
        }
      });
    }
  }

  await updateDynamicRulesSafely({ removeRuleIds, addRules });
}

function updateAdBlockerRules() {
  return enqueueDnrUpdate(performAdBlockerRulesUpdate);
}

async function performTemporaryBlockRuleUpdate(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    return;
  }
  const hostname = parsed.hostname;
  if (!hostname) return;

  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const alreadyBlocked = existingRules.some(r => {
    const cond = r.condition;
    return cond.urlFilter && cond.urlFilter.includes(hostname);
  });
  if (alreadyBlocked) return;

  const ruleId = nextTempRuleId++;
  await updateDynamicRulesSafely({
    removeRuleIds: [],
    addRules: [{
      id: ruleId,
      priority: 1,
      action: { type: "block" },
      condition: {
        urlFilter: `||${hostname}`,
        resourceTypes: ["main_frame"]
      }
    }]
  });

  chrome.alarms.create(`cybershield-temp-${ruleId}`, { delayInMinutes: 0.5 });
}

function addTemporaryBlockRule(url) {
  return enqueueDnrUpdate(() => performTemporaryBlockRuleUpdate(url));
}

chrome.alarms?.onAlarm?.addListener((alarm) => {
  if (!alarm.name.startsWith("cybershield-temp-")) return;
  const ruleId = parseInt(alarm.name.slice("cybershield-temp-".length), 10);
  if (!Number.isInteger(ruleId)) return;
  enqueueDnrUpdate(async () => {
    await updateDynamicRulesSafely({ removeRuleIds: [ruleId], addRules: [] });
  });
});

function showNotification(title, message, url) {
  chrome.storage.local.get(["notificationsEnabled"], (result) => {
    if (result.notificationsEnabled === false) return;

    try {
      chrome.notifications.create({
        type: "basic",
        iconUrl: chrome.runtime.getURL("icons/icon128.png"),
        title,
        message,
        priority: 2,
        buttons: [{ title: "Go Back" }, { title: "Continue" }]
      }, (notificationId) => {
        if (chrome.runtime.lastError || !notificationId) return;
        chrome.notifications?.onButtonClicked?.addListener?.(function handler(nId, buttonIndex) {
          if (nId !== notificationId) return;
          chrome.notifications.onButtonClicked.removeListener(handler);
          chrome.notifications.clear(nId);
          if (buttonIndex === 0) {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
              if (!tabs[0]) return;
              try {
                chrome.tabs.goBack(tabs[0].id, () => {
                  if (chrome.runtime.lastError) {
                    chrome.tabs.update(tabs[0].id, { url: "chrome://newtab/" });
                  }
                });
              } catch (e) {}
            });
          }
        });
      });
    } catch (e) {}
  });
}

const DOMAIN_INFO_CACHE_KEY = "cybershield-domain-info-v2";
const DOMAIN_INFO_CACHE_TTL = 24 * 60 * 60 * 1000;

function computeDomainAgeYears(dateStr) {
  const created = new Date(dateStr);
  if (isNaN(created.getTime())) return null;
  const years = (Date.now() - created.getTime()) / (365.25 * 24 * 3600 * 1000);
  return Math.max(0, parseFloat(years.toFixed(1)));
}

function getRdapEndpoints(domain, tld) {
  const endpoints = [`https://rdap.org/domain/${encodeURIComponent(domain)}`];
  const tldLower = tld.toLowerCase();
  const direct = {
    "com": `https://rdap.verisign.com/com/v1/domain/${domain}`,
    "net": `https://rdap.verisign.com/net/v1/domain/${domain}`,
    "org": `https://rdap.publicinterestregistry.org/rdap/domain/${domain}`,
    "io": `https://rdap.identitydigital.services/rdap/domain/${domain}`,
    "co": `https://rdap.identitydigital.services/rdap/domain/${domain}`,
    "info": `https://rdap.afilias.net/rdap/domain/${domain}`,
    "biz": `https://rdap.afilias.net/rdap/domain/${domain}`,
    "de": `https://rdap.denic.de/domain/${domain}`,
    "uk": `https://rdap.nominet.uk/domain/${domain}`,
    "xyz": `https://rdap.centralnic.com/rdap/domain/${domain}`,
    "app": `https://rdap.nic.google/domain/${domain}`,
    "dev": `https://rdap.nic.google/domain/${domain}`,
    "page": `https://rdap.nic.google/domain/${domain}`
  };
  if (direct[tldLower]) {
    endpoints.push(direct[tldLower]);
  }
  return endpoints;
}

async function fetchRdapData(domain, tld) {
  const endpoints = getRdapEndpoints(domain, tld);
  for (const endpoint of endpoints) {
    try {
      const resp = await fetch(endpoint, {
        redirect: "follow",
        signal: AbortSignal.timeout(8000),
        headers: { "Accept": "application/rdap+json" }
      });
      if (resp.ok) {
        return await resp.json();
      }
    } catch (e) {
      // try next endpoint
    }
  }
  return null;
}

async function getDomainInfo(url, forceRefresh) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    return null;
  }

  const hostname = parsed.hostname;
  const isHttps = parsed.protocol === "https:";
  const registrable = getRegistrableDomain(hostname.toLowerCase());
  const tld = hostname.split(".").pop();

  const cacheData = await chrome.storage.local.get([DOMAIN_INFO_CACHE_KEY]);
  const cache = cacheData[DOMAIN_INFO_CACHE_KEY] || {};

  if (!forceRefresh) {
    const cached = cache[registrable];
    if (cached && Date.now() - cached.ts < DOMAIN_INFO_CACHE_TTL) {
      return cached.info;
    }
  }

  // The browser already validated the certificate to load this page,
  // so an HTTPS page means the certificate is valid.
  const info = {
    hostname,
    isHttps,
    certificateValid: isHttps,
    ageYears: null,
    createdDate: null
  };

  if (!isIpAddress(hostname) && hasValidTld(hostname)) {
    const data = await fetchRdapData(registrable, tld);
    if (data) {
      const events = data.events || [];
      const regEvent = events.find(e => e.eventAction === "registration");
      if (regEvent && regEvent.eventDate) {
        info.createdDate = regEvent.eventDate;
        info.ageYears = computeDomainAgeYears(regEvent.eventDate);
      }
    }
  }

  // Only cache successful lookups so failures get retried on the next open
  const result = {
    isHttps: info.isHttps,
    certificateValid: info.certificateValid,
    ageYears: info.ageYears,
    createdDate: info.createdDate
  };
  if (result.ageYears !== null) {
    const updated = { ...cache, [registrable]: { ts: Date.now(), info } };
    const trimmed = trimDomainInfoCache(updated);
    await chrome.storage.local.set({ [DOMAIN_INFO_CACHE_KEY]: trimmed });
  }

  return result;
}

function trimDomainInfoCache(cache) {
  const now = Date.now();
  const out = {};
  for (const key of Object.keys(cache)) {
    if (now - cache[key].ts < DOMAIN_INFO_CACHE_TTL && Object.keys(out).length < 50) {
      out[key] = cache[key];
    }
  }
  return out;
}

function getWarningPageUrl(data) {
  const encoded = encodeURIComponent(JSON.stringify(data));
  return chrome.runtime.getURL(`warning/warning.html?data=${encoded}`);
}

async function isBypassedUrl(url) {
  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname;
    const data = await chrome.storage.local.get(["bypassedUrls"]);
    const bypassed = data.bypassedUrls || {};
    const now = Date.now();
    if (bypassed[hostname] && now - bypassed[hostname] < 30000) {
      return true;
    }
    if (bypassed[url] && now - bypassed[url] < 30000) {
      return true;
    }
    return false;
  } catch (e) {
    return false;
  }
}

async function markUrlBypassed(url) {
  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname;
    const data = await chrome.storage.local.get(["bypassedUrls"]);
    const bypassed = data.bypassedUrls || {};
    const now = Date.now();
    bypassed[hostname] = now;
    bypassed[url] = now;
    const keys = Object.keys(bypassed);
    for (const key of keys) {
      if (now - bypassed[key] > 60000) {
        delete bypassed[key];
      }
    }
    await chrome.storage.local.set({ bypassedUrls: bypassed });
  } catch (e) {
    // Ignore errors
  }
}

function safeSendResponse(sendResponse, data) {
  try {
    sendResponse(data);
  } catch (e) {
    console.error("[CyberShield] safeSendResponse failed:", e && e.message ? e.message : e);
  }
}

chrome.runtime?.onMessage?.addListener?.((message, sender, sendResponse) => {
  if (message.type === "ANALYZE_URL") {
    chrome.storage.local.get(["blockedDomains", "safeDomains", "phishingEnabled"], (settings) => {
      const result = analyzeUrl(message.url, settings, message.contentAnalysis);
      safeSendResponse(sendResponse, result);
    });
    return true;
  }

  if (message.type === "ANALYZE_AND_WARN") {
    chrome.storage.local.get(["blockedDomains", "safeDomains", "blockingEnabled"], (settings) => {
      const result = analyzeUrl(message.url, settings);

      if (result.level === "High Risk" || result.level === "Blocked") {
        if (settings.blockingEnabled !== false) {
          showNotification(
            "CyberShield Warning",
            `This site scored ${result.score}% - ${result.level}. ${message.url}`,
            message.url
          );

          const warningUrl = getWarningPageUrl({
            url: message.url,
            score: result.score,
            level: result.level,
            reasons: result.reasons,
            phishingAnalysis: result.phishingAnalysis
          });

          if (sender.tab && sender.tab.id) {
            chrome.tabs.update(sender.tab.id, { url: warningUrl });
          }
        }
      }
      safeSendResponse(sendResponse, result);
    });
    return true;
  }

  if (message.type === "GET_SETTINGS") {
    chrome.storage.local.get([
      "blockedDomains", "safeDomains", "blockingEnabled",
      "notificationsEnabled", "phishingEnabled", "adBlockerEnabled", "mailGuardEnabled", "theme"
    ], (settings) => {
      safeSendResponse(sendResponse, settings);
    });
    return true;
  }

  if (message.type === "SAVE_SETTINGS") {
    chrome.storage.local.set({
      blockedDomains: message.blockedDomains || [],
      safeDomains: message.safeDomains || [],
      blockingEnabled: message.blockingEnabled,
      notificationsEnabled: message.notificationsEnabled,
      phishingEnabled: message.phishingEnabled,
      adBlockerEnabled: message.adBlockerEnabled,
      mailGuardEnabled: message.mailGuardEnabled,
      theme: message.theme
    }, async () => {
      await updateBlockingRules();
      await updateAdBlockerRules();
      safeSendResponse(sendResponse, { success: true });
    });
    return true;
  }

  if (message.type === "CONTENT_ANALYSIS") {
    try {
      const msgUrl = new URL(message.url);
      if (msgUrl.searchParams.has("_cybershield_bypass")) {
        safeSendResponse(sendResponse, { score: 100, level: "Safe", reasons: [], phishingFlags: [], customList: null, phishingAnalysis: null });
        return true;
      }
      if (isBuiltinSafeDomain(msgUrl.hostname)) {
        safeSendResponse(sendResponse, { score: 100, level: "Safe", reasons: [], phishingFlags: [], customList: null, phishingAnalysis: null });
        return true;
      }
    } catch (e) {
      safeSendResponse(sendResponse, { score: 50, level: "Moderate Risk", reasons: [], phishingFlags: [], customList: null, phishingAnalysis: null });
      return true;
    }

    isBypassedUrl(message.url).then(bypassed => {
      if (bypassed) {
        safeSendResponse(sendResponse, { score: 100, level: "Safe", reasons: [], phishingFlags: [], customList: null, phishingAnalysis: null });
        return;
      }

      chrome.storage.local.get(["blockedDomains", "safeDomains", "blockingEnabled", "phishingEnabled"], (settings) => {
        const result = analyzeUrl(message.url, settings, message.contentAnalysis);

        if (result.level === "High Risk" || result.level === "Blocked") {
          if (settings.blockingEnabled !== false && sender.tab && sender.tab.id) {
            showNotification(
              "CyberShield Warning",
              `This site scored ${result.score}% - ${result.level}`,
              message.url
            );

            const warningUrl = getWarningPageUrl({
              url: message.url,
              score: result.score,
              level: result.level,
              reasons: result.reasons,
              phishingAnalysis: result.phishingAnalysis
            });

            chrome.tabs.update(sender.tab.id, { url: warningUrl }).catch(() => {});
          }
        }
        safeSendResponse(sendResponse, result);
      });
    }).catch(() => {
      safeSendResponse(sendResponse, { score: 50, level: "Moderate Risk", reasons: [], phishingFlags: [], customList: null, phishingAnalysis: null });
    });
    return true;
  }

  if (message.type === "BYPASS_URL") {
    markUrlBypassed(message.url).then(() => {
      safeSendResponse(sendResponse, { success: true });
    }).catch(() => {
      safeSendResponse(sendResponse, { success: false });
    });
    return true;
  }

  if (message.type === "PHISHING_DETECTION") {
    try {
      const parsed = new URL(message.url);
      if (isBuiltinSafeDomain(parsed.hostname)) {
        safeSendResponse(sendResponse, { enabled: false });
        return true;
      }
    } catch (e) {}
    chrome.storage.local.get(["phishingEnabled"], (settings) => {
      if (settings.phishingEnabled === false) {
        safeSendResponse(sendResponse, { enabled: false });
        return;
      }
      try {
        const phishingAnalysis = getPhishingAnalysis(message.url, {}, message.contentAnalysis);
        safeSendResponse(sendResponse, { enabled: true, phishingAnalysis });
      } catch (e) {
        safeSendResponse(sendResponse, { enabled: false });
      }
    });
    return true;
  }

  if (message.type === "GET_PHISHING_REPORTS") {
    chrome.storage.local.get(["phishingReports"], (data) => {
      safeSendResponse(sendResponse, { reports: data.phishingReports || [] });
    });
    return true;
  }

  if (message.type === "GET_DOMAIN_INFO") {
    getDomainInfo(message.url, message.forceRefresh).then((info) => {
      safeSendResponse(sendResponse, info);
    }).catch(() => {
      safeSendResponse(sendResponse, null);
    });
    return true;
  }

  if (message.type === "FETCH_URL") {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    fetch(message.url, {
      mode: "cors",
      headers: { "Accept": "text/html" },
      signal: controller.signal
    }).then(r => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.text();
    }).then(html => {
      safeSendResponse(sendResponse, { success: true, html: html.slice(0, 2000000) });
    }).catch(err => {
      safeSendResponse(sendResponse, { success: false, error: err.message || "Failed to fetch" });
    }).finally(() => clearTimeout(timer));
    return true;
  }

  if (message.type === "MAILGUARD_ANALYZE_EMAIL") {
    chrome.storage.local.get(["mailGuardEnabled"], (settings) => {
      if (settings.mailGuardEnabled === false) {
        safeSendResponse(sendResponse, { enabled: false });
        return;
      }
      try {
        const result = analyzeEmailPayload(message.payload);
        safeSendResponse(sendResponse, { enabled: true, result });
      } catch (e) {
        safeSendResponse(sendResponse, { enabled: true, result: null });
      }
    });
    return true;
  }

  if (message.type === "MAILGUARD_ANALYZE_ROWS") {
    chrome.storage.local.get(["mailGuardEnabled"], (settings) => {
      if (settings.mailGuardEnabled === false) {
        safeSendResponse(sendResponse, { enabled: false, results: [] });
        return;
      }
      try {
        const results = (message.rows || []).map(row => {
          const score = analyzeRowScore(row);
          return { key: row.key, score: score.score, risk: score.risk, threats: score.threats };
        });
        safeSendResponse(sendResponse, { enabled: true, results });
      } catch (e) {
        safeSendResponse(sendResponse, { enabled: true, results: [] });
      }
    });
    return true;
  }

  if (message.type === "MAILGUARD_NOTIFY") {
    chrome.storage.local.get(["notificationsEnabled"], (settings) => {
      if (settings.notificationsEnabled !== false) {
        showNotification(
          "MailGuard Alert",
          "Suspicious email detected: " + (message.subject || "Unknown").slice(0, 80),
          "https://mail.google.com"
        );
      }
      safeSendResponse(sendResponse, { success: true });
    });
    return true;
  }
});

function analyzeUrlDirectly(tabId, url, settings) {
  const result = analyzeUrl(url, settings);

  if (result.level === "High Risk" || result.level === "Blocked") {
    showNotification(
      "CyberShield Warning",
      `This site scored ${result.score}% - ${result.level}`,
      url
    );

    const warningUrl = getWarningPageUrl({
      url: url,
      score: result.score,
      level: result.level,
      reasons: result.reasons,
      phishingAnalysis: result.phishingAnalysis
    });

    chrome.tabs.update(tabId, { url: warningUrl }).catch(() => {});
  }
}

chrome.webNavigation?.onBeforeNavigate?.addListener?.((details) => {
  if (details.frameId !== 0) return;

  chrome.storage.local.get(["blockingEnabled", "blockedDomains", "safeDomains"], (settings) => {
    if (settings.blockingEnabled === false) return;

    let parsed;
    try {
      parsed = new URL(details.url);
    } catch (e) {
      return;
    }

    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return;

    isBypassedUrl(details.url).then(bypassed => {
      if (bypassed) return;

      if (parsed.searchParams.has("_cybershield_bypass")) return;

      if (isBuiltinSafeDomain(parsed.hostname)) return;

      analyzeUrlDirectly(details.tabId, details.url, settings);
    });
  });
});

chrome.webNavigation?.onCompleted?.addListener?.((details) => {
  if (details.frameId !== 0) return;

  chrome.storage.local.get(["blockingEnabled"], (settings) => {
    if (settings.blockingEnabled === false) return;

    let parsed;
    try {
      parsed = new URL(details.url);
    } catch (e) {
      return;
    }

    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return;

    isBypassedUrl(details.url).then(bypassed => {
      if (parsed.searchParams.has("_cybershield_bypass")) {
        parsed.searchParams.delete("_cybershield_bypass");
        chrome.tabs.update(details.tabId, { url: parsed.toString() });
        return;
      }

      if (bypassed) return;

      if (isBuiltinSafeDomain(parsed.hostname)) return;

      try {
        chrome.tabs.sendMessage(details.tabId, {
          type: "ANALYZE_PAGE",
          url: details.url
        }).catch(() => {});
      } catch (e) {}
    });
  });
});

chrome.runtime?.onInstalled?.addListener?.(async () => {
  const settings = await chrome.storage.local.get(["blockingEnabled", "notificationsEnabled", "phishingEnabled", "adBlockerEnabled", "mailGuardEnabled"]);
  if (settings.blockingEnabled === undefined) {
    await chrome.storage.local.set({ blockingEnabled: true });
  }
  if (settings.notificationsEnabled === undefined) {
    await chrome.storage.local.set({ notificationsEnabled: true });
  }
  if (settings.phishingEnabled === undefined) {
    await chrome.storage.local.set({ phishingEnabled: true });
  }
  if (settings.adBlockerEnabled === undefined) {
    await chrome.storage.local.set({ adBlockerEnabled: true });
  }
  if (settings.mailGuardEnabled === undefined) {
    await chrome.storage.local.set({ mailGuardEnabled: true });
  }
  await updateBlockingRules();
  await updateAdBlockerRules();
  await ensureBypassAllowRule();
});

async function ensureBypassAllowRule() {
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  if (existingRules.some(r => r.id === BYPASS_ALLOW_RULE_ID)) return;
  await updateDynamicRulesSafely({
    removeRuleIds: [],
    addRules: [{
      id: BYPASS_ALLOW_RULE_ID,
      priority: 2,
      action: { type: "allow" },
      condition: {
        urlFilter: "_cybershield_bypass",
        resourceTypes: ["main_frame"]
      }
    }]
  });
}

function analyzeEmailPayload(payload) {
  if (!payload) return null;
  const bodyText = (payload.bodyText || "").toLowerCase();
  const subject = (payload.subject || "").toLowerCase();
  const links = payload.links || [];
  const attachments = payload.attachments || [];
  const senderRaw = payload.senderRaw || "";

  let score = 100;
  const threats = [];

  const urgencyPhrases = [
    "verify your account", "confirm your identity", "update your payment",
    "unauthorized access", "click here immediately", "reset your password",
    "security alert", "act now", "suspended", "limited time", "act immediately",
    "account will be", "locked", "blocked", "terminated", "within 24 hours",
    "failure to respond", "final notice", "urgent", "expires today"
  ];
  for (const phrase of urgencyPhrases) {
    if (bodyText.includes(phrase) || subject.includes(phrase)) {
      score -= 8;
      threats.push("Urgency language: \"" + phrase + "\"");
    }
  }

  const financialPhrases = [
    "credit card", "debit", "ssn", "social security", "tax refund",
    "wire transfer", "crypto wallet", "bitcoin", "routing number",
    "account number", "pin code", "cvv"
  ];
  let financialHits = 0;
  for (const phrase of financialPhrases) {
    if (bodyText.includes(phrase)) financialHits++;
  }
  if (financialHits >= 2) {
    score -= financialHits * 5;
    threats.push("Financial data request (" + financialHits + " terms)");
  }

  const techPhrases = [
    "virus detected", "malware", "computer infected", "call now",
    "microsoft support", "apple support", "tech support", "remote access",
    "teamviewer", "anydesk"
  ];
  let techHits = 0;
  for (const phrase of techPhrases) {
    if (bodyText.includes(phrase)) techHits++;
  }
  if (techHits >= 2) {
    score -= techHits * 6;
    threats.push("Tech support scam language (" + techHits + " terms)");
  }

  const suspiciousTlds = [".xyz", ".top", ".buzz", ".gq", ".ml", ".cf", ".tk", ".ga", ".cc", ".pw", ".click", ".work"];
  let susLinks = 0;
  for (const link of links) {
    const href = (link.href || "").toLowerCase();
    for (const tld of suspiciousTlds) {
      if (href.includes(tld)) { susLinks++; break; }
    }
    if (href.includes("login.") || href.includes("verify.") || href.includes("secure-")) susLinks++;
  }
  if (susLinks > 0) {
    score -= susLinks * 10;
    threats.push(susLinks + " suspicious link(s)");
  }

  const brandPatterns = [/paypal/i, /apple/i, /google/i, /amazon/i, /microsoft/i, /facebook/i, /netflix/i];
  const senderDomain = (senderRaw.split("@")[1] || "").toLowerCase();
  for (const brand of brandPatterns) {
    if (brand.test(senderDomain) && !brand.test(senderRaw.split("@")[0] || "")) {
      score -= 15;
      threats.push("Possible brand impersonation in sender");
      break;
    }
  }

  if (attachments.length > 3) {
    score -= 5;
    threats.push(attachments.length + " attachments");
  }
  const dangerousExts = [".exe", ".scr", ".bat", ".cmd", ".js", ".vbs", ".ps1", ".msi"];
  for (const att of attachments) {
    const name = (att.name || "").toLowerCase();
    for (const ext of dangerousExts) {
      if (name.endsWith(ext)) {
        score -= 20;
        threats.push("Dangerous attachment: " + att.name);
        break;
      }
    }
  }

  score = Math.max(0, Math.min(100, score));
  let risk = "low";
  if (score < 50) risk = "high";
  else if (score < 75) risk = "medium";

  const recommendation = risk === "high"
    ? "This email shows strong signs of phishing. Do not click any links or download attachments."
    : risk === "medium"
      ? "This email has some suspicious elements. Verify the sender before taking action."
      : "This email appears to be safe.";

  return {
    score,
    risk,
    threats: threats.slice(0, 8),
    recommendation,
    disclaimer: "MailGuard analysis is advisory. Always exercise caution with emails requesting personal information."
  };
}

function analyzeRowScore(row) {
  const subject = (row.subject || "").toLowerCase();
  const snippet = (row.snippet || "").toLowerCase();
  const senderRaw = (row.senderRaw || "").toLowerCase();
  const combined = subject + " " + snippet;

  let score = 100;
  const threats = [];

  const urgencyPhrases = [
    "verify your account", "confirm your identity", "update your payment",
    "unauthorized access", "click here immediately", "reset your password",
    "security alert", "act now", "suspended", "limited time", "act immediately",
    "account will be", "locked", "blocked", "terminated", "within 24 hours",
    "failure to respond", "final notice", "urgent", "expires today",
    "immediately", "last chance", "don't miss", "hurry"
  ];
  for (const phrase of urgencyPhrases) {
    if (combined.includes(phrase)) { score -= 6; threats.push("Urgency: " + phrase); }
  }

  const financialPhrases = [
    "credit card", "debit", "ssn", "social security", "tax refund",
    "wire transfer", "crypto wallet", "bitcoin", "routing number",
    "account number", "pin code", "cvv", "payment", "billing"
  ];
  let finHits = 0;
  for (const phrase of financialPhrases) {
    if (combined.includes(phrase)) finHits++;
  }
  if (finHits >= 2) { score -= finHits * 5; threats.push("Financial request (" + finHits + " terms)"); }

  const techPhrases = [
    "virus detected", "malware", "computer infected", "call now",
    "microsoft support", "apple support", "tech support", "remote access",
    "teamviewer", "anydesk"
  ];
  let techHits = 0;
  for (const phrase of techPhrases) {
    if (combined.includes(phrase)) techHits++;
  }
  if (techHits >= 2) { score -= techHits * 6; threats.push("Tech scam (" + techHits + " terms)"); }

  const prizePhrases = [
    "you won", "congratulations", "claim your prize", "lottery",
    "sweepstakes", "million dollars", "selected winner", "free gift card"
  ];
  let prizeHits = 0;
  for (const phrase of prizePhrases) {
    if (combined.includes(phrase)) prizeHits++;
  }
  if (prizeHits >= 2) { score -= prizeHits * 6; threats.push("Prize scam (" + prizeHits + " terms)"); }

  const susTlds = [".xyz", ".top", ".buzz", ".gq", ".ml", ".cf", ".tk", ".ga", ".cc", ".pw", ".click", ".work"];
  for (const tld of susTlds) {
    if (combined.includes(tld)) { score -= 10; threats.push("Suspicious TLD"); break; }
  }

  const brandPatterns = [/paypal/i, /apple/i, /google/i, /amazon/i, /microsoft/i, /facebook/i, /netflix/i, /instagram/i];
  const senderDomain = (senderRaw.split("@")[1] || "");
  for (const brand of brandPatterns) {
    if (brand.test(senderDomain)) { score -= 12; threats.push("Brand impersonation: " + senderDomain); break; }
  }

  const susSenderPatterns = ["login", "verify", "secure", "account", "auth", "update", "billing", "support"];
  for (const p of susSenderPatterns) {
    if (senderRaw.indexOf(p) !== -1 && senderDomain && !["gmail.com", "googlemail.com", "outlook.com", "yahoo.com", "hotmail.com"].includes(senderDomain)) {
      score -= 8;
      threats.push("Suspicious sender keyword: " + p);
      break;
    }
  }

  score = Math.max(0, Math.min(100, score));
  let risk = "low";
  if (score < 50) risk = "high";
  else if (score < 75) risk = "medium";

  return { score, risk, threats: threats.slice(0, 6) };
}

chrome.storage?.local?.onChanged?.addListener?.((changes) => {
  if (changes.blockedDomains) {
    updateBlockingRules();
  }
  if (changes.adBlockerEnabled) {
    updateAdBlockerRules();
  }
});
