const PHISHING_CATEGORIES = {
  CREDENTIAL_HARVESTING: {
    name: "Credential Harvesting",
    icon: "\uD83D\uDD11",
    description: "Attempts to steal login credentials via fake forms",
    weight: 1.0
  },
  FINANCIAL_FRAUD: {
    name: "Financial Fraud",
    icon: "\uD83D\uDCB3",
    description: "Targets banking or payment information",
    weight: 1.0
  },
  TECH_SUPPORT_SCAM: {
    name: "Tech Support Scam",
    icon: "\uD83D\uDCBB",
    description: "Fake technical support or virus warnings",
    weight: 0.8
  },
  PRIZE_LOTTERY: {
    name: "Prize/Lottery Scam",
    icon: "\uD83C\uDFC6",
    description: "Fake prize or lottery notifications",
    weight: 0.9
  },
  SOCIAL_PHISHING: {
    name: "Social Media Phishing",
    icon: "\uD83D\uDC65",
    description: "Impersonates social media platforms",
    weight: 0.9
  },
  BRAND_IMPERSONATION: {
    name: "Brand Impersonation",
    icon: "\uD83D\uDEAB",
    description: "Mimics a well-known brand or service",
    weight: 1.0
  },
  GENERIC_PHISHING: {
    name: "Generic Phishing",
    icon: "\u26A0\uFE0F",
    description: "General phishing attempt detected",
    weight: 0.7
  }
};

const URGENCY_KEYWORDS = [
  "act now", "immediately", "urgent", "expires today", "limited time",
  "last chance", "don't miss", "hurry", "only left", "final notice",
  "account will be", "suspended", "locked", "blocked", "terminated",
  "verify now", "confirm identity", "update required", "action needed",
  "failure to", "within 24 hours", "within 48 hours", "respond immediately"
];

const FINANCIAL_KEYWORDS = [
  "bank", "credit card", "debit", "ssn", "social security",
  "tax refund", "payment", "wire transfer", "crypto wallet",
  "bitcoin", "paypal", "venmo", "zelle", "routing number",
  "account number", "pin code", "cvv", "expiration date"
];

const TECH_SUPPORT_KEYWORDS = [
  "virus detected", "malware", "computer infected", "call now",
  "microsoft support", "apple support", "tech support", "helpline",
  "toll free", "1-800", "1-888", "1-877", "remote access",
  "teamviewer", "anydesk", "your computer is at risk"
];

const PRIZE_KEYWORDS = [
  "you won", "congratulations", "claim your prize", "lottery",
  "sweepstakes", "reward center", "million dollars", "selected winner",
  "lucky winner", "free gift card", "no cost", "zero fee"
];

const SOCIAL_KEYWORDS = [
  "friend request", "new message", "someone tagged", "your post",
  "account review", "profile view", "follow back", "login alert",
  "unauthorized access", "security alert", "verify your account"
];

const BRAND_LOGO_PATTERNS = [
  /paypal/i, /apple/i, /google/i, /amazon/i, /microsoft/i,
  /facebook/i, /netflix/i, /instagram/i, /twitter/i, /linkedin/i,
  /dropbox/i, /chase/i, /wellsfargo/i, /bankofamerica/i, /citibank/i,
  /venmo/i, /zelle/i, /coinbase/i, /binance/i, /ebay/i,
  /walmart/i, /target/i, /costco/i, /bestbuy/i, /adobe/i,
  /zoom/i, /slack/i, /github/i, /gitlab/i, /spotify/i,
  /steam/i, /discord/i, /twitch/i, /youtube/i, /tiktok/i,
  /whatsapp/i, /telegram/i, /signal/i, /protonmail/i, /gmail/i,
  /outlook/i, /yahoo/i
];

function calculatePhishingConfidence(urlAnalysis, contentAnalysis, pageText) {
  let confidence = 0;
  const indicators = [];
  let detectedCategory = "GENERIC_PHISHING";

  const hostname = urlAnalysis.hostname || "";
  const fullUrl = urlAnalysis.url || "";
  const phishingFlags = urlAnalysis.phishingFlags || [];

  let contentScore = 0;
  let urlScore = 0;

  if (phishingFlags.length > 0) {
    const brandFlag = phishingFlags.find(f => f.includes("impersonation"));
    if (brandFlag) {
      urlScore += 30;
      indicators.push({
        text: "Domain impersonates a known brand",
        severity: "high",
        weight: 30
      });
      detectedCategory = "BRAND_IMPERSONATION";
    }

    const homoglyphFlag = phishingFlags.find(f => f.includes("homoglyph"));
    if (homoglyphFlag) {
      urlScore += 25;
      indicators.push({
        text: "Uses Unicode homoglyph characters to mimic legitimate domains",
        severity: "high",
        weight: 25
      });
    }

    const patternFlags = phishingFlags.filter(f => f.includes("pattern"));
    if (patternFlags.length > 0) {
      urlScore += 15;
      indicators.push({
        text: `Suspicious subdomain patterns detected (${patternFlags.length})`,
        severity: "medium",
        weight: 15
      });
    }

    const hyphenFlag = phishingFlags.find(f => f.includes("hyphen"));
    if (hyphenFlag) {
      urlScore += 10;
      indicators.push({
        text: "Excessive hyphens in domain name",
        severity: "medium",
        weight: 10
      });
    }

    const deepFlag = phishingFlags.find(f => f.includes("nested"));
    if (deepFlag) {
      urlScore += 10;
      indicators.push({
        text: "Deeply nested subdomains (common in phishing)",
        severity: "medium",
        weight: 10
      });
    }
  }

  if (contentAnalysis) {
    let loginRelated = 0;
    if (contentAnalysis.hasFakeLoginForm) loginRelated++;
    if (contentAnalysis.hasPasswordField) loginRelated++;
    if (contentAnalysis.hasExternalFormAction) loginRelated++;

    if (loginRelated >= 2 && !urlAnalysis.isHttps) {
      contentScore += 20;
      indicators.push({
        text: "Login form on non-HTTPS page with external action",
        severity: "high",
        weight: 20
      });
      if (detectedCategory === "GENERIC_PHISHING") {
        detectedCategory = "CREDENTIAL_HARVESTING";
      }
    } else if (contentAnalysis.hasFakeLoginForm && contentAnalysis.hasExternalFormAction && loginRelated >= 2) {
      contentScore += 15;
      indicators.push({
        text: "Login form submits to external domain",
        severity: "high",
        weight: 15
      });
      if (detectedCategory === "GENERIC_PHISHING") {
        detectedCategory = "CREDENTIAL_HARVESTING";
      }
    }

    if (contentAnalysis.hasPasswordField && !urlAnalysis.isHttps) {
      contentScore += 8;
      indicators.push({
        text: "Password field on non-HTTPS page",
        severity: "medium",
        weight: 8
      });
    }

    if (contentAnalysis.hasHiddenIframes && contentAnalysis.hasFakeLoginForm) {
      contentScore += 12;
      indicators.push({
        text: "Hidden iframes combined with login form",
        severity: "high",
        weight: 12
      });
    }

    if (contentAnalysis.hasObfuscatedScript && contentAnalysis.hasFakeLoginForm) {
      contentScore += 12;
      indicators.push({
        text: "Obfuscated JavaScript with login form present",
        severity: "high",
        weight: 12
      });
    }

    if (contentAnalysis.hasFakeFinancialForm && contentAnalysis.hasExternalFormAction) {
      contentScore += 18;
      indicators.push({
        text: "Financial form submits to external domain",
        severity: "high",
        weight: 18
      });
      if (detectedCategory === "GENERIC_PHISHING" || detectedCategory === "CREDENTIAL_HARVESTING") {
        detectedCategory = "FINANCIAL_FRAUD";
      }
    } else if (contentAnalysis.hasFakeFinancialForm) {
      contentScore += 5;
      indicators.push({
        text: "Financial form detected",
        severity: "medium",
        weight: 5
      });
    }

    if (contentAnalysis.hasTechSupportLanguage) {
      contentScore += 15;
      indicators.push({
        text: "Tech support scam language detected",
        severity: "high",
        weight: 15
      });
      detectedCategory = "TECH_SUPPORT_SCAM";
    }

    if (contentAnalysis.hasPrizeLanguage) {
      contentScore += 15;
      indicators.push({
        text: "Prize/lottery scam language detected",
        severity: "high",
        weight: 15
      });
      detectedCategory = "PRIZE_LOTTERY";
    }

    if (contentAnalysis.hasSocialLanguage && contentAnalysis.hasFakeLoginForm) {
      contentScore += 12;
      indicators.push({
        text: "Social media phishing with login form",
        severity: "high",
        weight: 12
      });
      if (detectedCategory === "GENERIC_PHISHING") {
        detectedCategory = "SOCIAL_PHISHING";
      }
    }

    if (contentAnalysis.hasRedirectMeta) {
      contentScore += 10;
      indicators.push({
        text: "Meta tag redirect detected",
        severity: "medium",
        weight: 10
      });
    }

    if (contentAnalysis.hasUrgencyLanguage && contentAnalysis.hasCountdownTimer) {
      contentScore += 8;
      indicators.push({
        text: "Urgency language combined with countdown timer",
        severity: "medium",
        weight: 8
      });
    }

    if (contentAnalysis.hasHiddenElements && contentAnalysis.hasHiddenIframes) {
      contentScore += 6;
      indicators.push({
        text: "Multiple hidden elements and iframes",
        severity: "medium",
        weight: 6
      });
    }
  }

  if (pageText) {
    const lowerText = pageText.toLowerCase();

    const urgencyCount = URGENCY_KEYWORDS.filter(k => lowerText.includes(k)).length;
    if (urgencyCount >= 3) {
      contentScore += Math.min(urgencyCount * 3, 10);
      indicators.push({
        text: `Multiple urgency keywords found (${urgencyCount})`,
        severity: "medium",
        weight: Math.min(urgencyCount * 3, 10)
      });
    }

    const financialCount = FINANCIAL_KEYWORDS.filter(k => lowerText.includes(k)).length;
    if (financialCount >= 3) {
      contentScore += Math.min(financialCount * 3, 10);
      indicators.push({
        text: `Financial data request language (${financialCount} terms)`,
        severity: "high",
        weight: Math.min(financialCount * 3, 10)
      });
      if (financialCount >= 4) {
        detectedCategory = "FINANCIAL_FRAUD";
      }
    }

    const techCount = TECH_SUPPORT_KEYWORDS.filter(k => lowerText.includes(k)).length;
    if (techCount >= 3) {
      contentScore += Math.min(techCount * 4, 12);
      indicators.push({
        text: `Tech support scam language (${techCount} terms)`,
        severity: "high",
        weight: Math.min(techCount * 4, 12)
      });
      detectedCategory = "TECH_SUPPORT_SCAM";
    }

    const prizeCount = PRIZE_KEYWORDS.filter(k => lowerText.includes(k)).length;
    if (prizeCount >= 3) {
      contentScore += Math.min(prizeCount * 4, 12);
      indicators.push({
        text: `Prize/lottery scam language (${prizeCount} terms)`,
        severity: "high",
        weight: Math.min(prizeCount * 4, 12)
      });
      detectedCategory = "PRIZE_LOTTERY";
    }

    const socialCount = SOCIAL_KEYWORDS.filter(k => lowerText.includes(k)).length;
    if (socialCount >= 3) {
      contentScore += Math.min(socialCount * 3, 10);
      indicators.push({
        text: `Social media phishing language (${socialCount} terms)`,
        severity: "medium",
        weight: Math.min(socialCount * 3, 10)
      });
    }
  }

  if (!urlAnalysis.isHttps) {
    urlScore += 5;
    indicators.push({
      text: "Non-HTTPS connection",
      severity: "medium",
      weight: 5
    });
  }

  if (urlAnalysis.isIpAddress) {
    urlScore += 10;
    indicators.push({
      text: "IP address used instead of domain name",
      severity: "medium",
      weight: 10
    });
  }

  if (urlAnalysis.suspiciousTld) {
    urlScore += 8;
    indicators.push({
      text: "Suspicious top-level domain",
      severity: "medium",
      weight: 8
    });
  }

  if (contentScore > 0 && urlScore > 0) {
    confidence = urlScore + Math.min(contentScore, 40);
  } else if (urlScore > 0) {
    confidence = urlScore;
  } else if (contentScore > 0) {
    confidence = Math.min(contentScore, 35);
  }

  confidence = Math.min(100, Math.max(0, confidence));

  const category = PHISHING_CATEGORIES[detectedCategory] || PHISHING_CATEGORIES.GENERIC_PHISHING;

  let riskLevel;
  if (confidence >= 70) riskLevel = "critical";
  else if (confidence >= 50) riskLevel = "high";
  else if (confidence >= 30) riskLevel = "medium";
  else if (confidence >= 15) riskLevel = "low";
  else riskLevel = "safe";

  indicators.sort((a, b) => b.weight - a.weight);

  return {
    confidence,
    riskLevel,
    category: {
      key: detectedCategory,
      ...category
    },
    indicators,
    summary: generateSummary(confidence, riskLevel, category, indicators)
  };
}

function generateSummary(confidence, riskLevel, category, indicators) {
  if (riskLevel === "safe") {
    return "No significant phishing indicators detected. This page appears to be legitimate.";
  }

  const highIndicators = indicators.filter(i => i.severity === "high");
  const mediumIndicators = indicators.filter(i => i.severity === "medium");

  let summary = `Detected as potential ${category.name.toLowerCase()} (${confidence}% confidence). `;

  if (highIndicators.length > 0) {
    summary += `${highIndicators.length} high-severity indicator(s) found. `;
  }
  if (mediumIndicators.length > 0) {
    summary += `${mediumIndicators.length} medium-severity indicator(s) found. `;
  }

  if (riskLevel === "critical") {
    summary += "Strongly recommend avoiding this site.";
  } else if (riskLevel === "high") {
    summary += "Exercise extreme caution on this site.";
  } else if (riskLevel === "medium") {
    summary += "Some suspicious elements detected. Verify legitimacy before entering data.";
  } else {
    summary += "Minor indicators detected. Generally safe but stay cautious.";
  }

  return summary;
}

function getPhishingAnalysis(url, settings, contentAnalysis) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    return {
      confidence: 0,
      riskLevel: "safe",
      category: PHISHING_CATEGORIES.GENERIC_PHISHING,
      indicators: [],
      summary: "Invalid URL."
    };
  }

  const hostname = parsed.hostname || "";
  const isHttps = parsed.protocol === "https:";
  const isIpAddress = /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname);
  const tld = "." + hostname.split(".").pop();
  const suspiciousTlds = [".xyz", ".top", ".buzz", ".gq", ".ml", ".cf", ".tk", ".ga", ".cc", ".pw", ".work", ".click"];
  const suspiciousTld = suspiciousTlds.includes(tld.toLowerCase());

  const urlAnalysis = {
    hostname,
    url,
    isHttps,
    isIpAddress,
    suspiciousTld,
    phishingFlags: detectPhishingFlags(hostname)
  };

  let pageText = "";
  if (contentAnalysis && contentAnalysis.pageText) {
    pageText = contentAnalysis.pageText;
  }

  return calculatePhishingConfidence(urlAnalysis, contentAnalysis, pageText);
}

function detectPhishingFlags(hostname) {
  const flags = [];

  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(hostname)) {
    flags.push("IP address used instead of domain name");
    return flags;
  }

  const homoglyphMap = {
    "\u0430": "a", "\u0435": "e", "\u043E": "o", "\u0440": "p",
    "\u0441": "c", "\u0443": "y", "\u0445": "x", "\u0456": "i",
    "\u0251": "a", "\u0261": "g", "\u2010": "-", "\u2011": "-",
    "\u2013": "-", "\u2014": "-", "\uFF0E": ".", "\u2026": "."
  };

  const normalized = [...hostname.toLowerCase()].map(c => homoglyphMap[c] || c).join("");

  const brands = [
    "paypal", "apple", "google", "amazon", "microsoft", "facebook", "netflix",
    "instagram", "twitter", "linkedin", "dropbox", "icloud", "chase", "wellsfargo",
    "bankofamerica", "citibank", "venmo", "zelle", "coinbase", "binance",
    "ebay", "walmart", "target", "costco", "bestbuy", "adobe", "zoom", "slack",
    "github", "gitlab", "spotify", "steam", "discord", "twitch", "youtube",
    "whatsapp", "telegram", "signal", "protonmail", "gmail", "outlook", "yahoo"
  ];

  const parts = normalized.split(".");
  const registrable = parts.length >= 2 ? parts.slice(-2).join(".") : normalized;
  const domainLabel = registrable.replace(/\..*/, "");

  for (const brand of brands) {
    const dist = levenshteinDistance(domainLabel, brand);
    if (dist > 0 && dist <= 2 && domainLabel.length > brand.length - 3) {
      flags.push(`Possible impersonation of "${brand}" (edit distance: ${dist})`);
    }
  }

  if ([...hostname].some(c => homoglyphMap[c])) {
    flags.push("Contains homoglyph characters (possible spoofing)");
  }

  const suspiciousLabelPatterns = [
    /^login[-_]/i, /[-_]login$/i,
    /^secure[-_]/i, /[-_]secure$/i,
    /^verify[-_]/i, /[-_]verify$/i,
    /^account[-_]/i, /[-_]account$/i,
    /^auth[-_]/i, /[-_]auth$/i,
    /^signin[-_]/i, /[-_]signin$/i
  ];

  for (const label of parts) {
    for (const pattern of suspiciousLabelPatterns) {
      if (pattern.test(label)) {
        flags.push(`Suspicious subdomain pattern: "${label}"`);
      }
    }
  }

  if ((hostname.match(/-/g) || []).length >= 3) {
    flags.push("Excessive hyphens in domain name");
  }

  if (parts.length > 4) {
    flags.push("Deeply nested subdomains");
  }

  return flags;
}

function levenshteinDistance(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] !== b[j - 1] ? 1 : 0)
      );
    }
  }
  return dp[m][n];
}
