(function () {
  if (/\.youtube\.com$|\.youtube\.com\/|youtu\.be/i.test(window.location.hostname + window.location.pathname)) return;
  if (window.location.hostname === 'mail.google.com') return;

  const SELECTORS = [
    // IDs
    "#ad", "#ads", "#adbox", "#advert", "#adsense", "#adslot", "#ad-slot",
    "#ad-banner", "#ads-banner", "#ad-container", "#ads-container",
    "#ad-wrapper", "#ad-box", "#ad-frame", "#ad-area", "#ad-zone",
    "#ad-panel", "#ad-unit", "#ad-block", "#masthead-ad",
    '[id^="ad-"]', '[id^="ads-"]', '[id^="ad_"]', '[id^="ads_"]',
    '[id^="advert"]', '[id^="div-gpt-ad"]', '[id^="google_ads"]',
    '[id^="aswift_"]', '[id^="yandex_ad"]',
    '[id$="-ad"]', '[id$="-ads"]', '[id*="-ad-"]', '[id*="-ads-"]',
    // Classes
    '[class^="ad-"]', '[class^="ads-"]', '[class^="ad_"]', '[class^="ads_"]',
    '[class^="advert"]', '[class$="-ad"]', '[class$="-ads"]',
    '[class*="-ad-"]', '[class*="-ads-"]',
    '[class*="ad-container"]', '[class*="ads-container"]', '[class*="ad-slot"]',
    '[class*="ads-slot"]', '[class*="ad-unit"]', '[class*="ad-wrapper"]',
    '[class*="ad-banner"]', '[class*="ads-banner"]', '[class*="ad-block"]',
    '[class*="ad-area"]', '[class*="ad-zone"]', '[class*="ad-panel"]',
    '[class*="ad-box"]', '[class*="ad-frame"]', '[class*="ad-placeholder"]',
    '[class*="advertisement"]', '[class*="advertorial"]', '[class*="advertising"]',
    '[class*="adsbygoogle"]', '[class*="sponsored"]', '[class*="promo-ad"]',
    '[class*="ad-promo"]', '[class*="adsense"]',
    // Data attributes
    '[data-ad]', '[data-ad-slot]', '[data-ad-client]', '[data-ads]',
    '[data-advert]', '[data-ad-size]', '[data-google-ad]', '[data-adunit]',
    '[data-ad-unit]', '[data-adformat]', '[data-ad-format]', '[data-adv]',
    // Common ad elements
    "ins.adsbygoogle", ".dfp-ad", ".google-auto-placed", ".googad",
    ".ad-banner", ".ad-container", ".ad-slot", ".ad-unit", ".ad-wrapper",
    ".advert", ".advertisement", ".ads", ".ad", ".sponsored", ".adsbygoogle",
    // Ad iframes
    'iframe[id^="aswift_"]', 'iframe[id^="google_ads_iframe"]',
    'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
    'iframe[src*="adservice.google"]', 'iframe[src*="adnxs.com"]',
    'iframe[src*="criteo"]', 'iframe[src*="taboola"]', 'iframe[src*="outbrain"]',
    'iframe[src*="amazon-adsystem"]', 'iframe[src*="smartadserver"]',
    'iframe[src*="revcontent"]', 'iframe[src*="mgid.com"]',
    'iframe[src*="adform.net"]', 'iframe[src*="advertising.com"]',
    'iframe[src*="adtech"]', 'iframe[src*="rubiconproject"]',
    'iframe[src*="openx"]', 'iframe[src*="pubmatic"]',
    'iframe[src*="casalemedia"]', 'iframe[src*="appnexus"]',
    'iframe[src*="yieldmo"]', 'iframe[src*="teads.tv"]',
    'iframe[src*="adserver"]',
    // Ad resources
    'img[src*="doubleclick.net"]', 'img[src*="googlesyndication.com"]',
    'img[src*="amazon-adsystem.com"]', 'img[src*="/ads/"]',
    'img[src*="adserver"]', 'img[src*="adservice.google"]',
    'script[src*="adsbygoogle"]', 'script[src*="doubleclick.net"]',
    'script[src*="googlesyndication.com"]', 'script[src*="adnxs.com"]',
    'script[src*="taboola"]', 'script[src*="criteo"]',
    'script[src*="outbrain"]', 'script[src*="smartadserver"]',
    'script[src*="revcontent"]', 'script[src*="amazon-adsystem"]',
    // Ad links
    'a[href*="doubleclick.net"]', 'a[href*="googlesyndication.com"]',
    'a[href*="adsrvr.org"]', 'a[href*="taboola.com"]',
    'a[href*="outbrain.com"]', 'a[href*="amazon-adsystem.com"]',
    'a[href*="revcontent.com"]',
    // ARIA-marked ads
    '[aria-label*="advertisement" i]', '[aria-label*="sponsored" i]'
  ];

  let observer = null;
  let removalTimer = null;

  function removeAds() {
    let matches;
    try {
      matches = document.querySelectorAll(SELECTORS.join(","));
    } catch (e) {
      return;
    }
    if (matches.length === 0) return;
    for (const el of matches) {
      try {
        if (el && el.parentNode) el.remove();
      } catch (e) {}
    }
  }

  function scheduleRemoval() {
    if (removalTimer) return;
    removalTimer = setTimeout(() => {
      removalTimer = null;
      removeAds();
    }, 200);
  }

  function start() {
    removeAds();
    if (!observer) {
      observer = new MutationObserver(scheduleRemoval);
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
  }

  function stop() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (removalTimer) {
      clearTimeout(removalTimer);
      removalTimer = null;
    }
  }

  chrome.storage.local.get(["adBlockerEnabled"], (settings) => {
    if (settings.adBlockerEnabled !== false) start();

    chrome.storage.onChanged.addListener((changes) => {
      if (!changes.adBlockerEnabled) return;
      if (changes.adBlockerEnabled.newValue !== false) {
        start();
      } else {
        stop();
      }
    });
  });
})();
