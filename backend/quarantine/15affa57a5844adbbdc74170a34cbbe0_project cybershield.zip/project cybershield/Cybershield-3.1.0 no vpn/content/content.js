(function () {
  const colorMap = {
    safe: "#3fb950",
    moderate: "#d29922",
    high: "#f85149",
    blocked: "#a855f7",
  };

  const bgMap = {
    safe: "rgba(63, 185, 80, 0.08)",
    moderate: "rgba(210, 153, 34, 0.08)",
    high: "rgba(248, 81, 73, 0.08)",
    blocked: "rgba(168, 85, 247, 0.10)",
  };

  const analysisCache = new Map();
  let sharedTooltip = null;
  let observerTimer = null;

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[c]));
  }

  function getGradeKey(score, level) {
    if (level === "Blocked") return "blocked";
    if (score >= 80) return "safe";
    if (score >= 50) return "moderate";
    return "high";
  }

  function isAnalyzableUrl(href) {
    if (!href) return false;
    return /^https?:/i.test(href) || href.startsWith("//");
  }

  function getTooltip() {
    if (!sharedTooltip || !document.body.contains(sharedTooltip)) {
      sharedTooltip = document.createElement("div");
      sharedTooltip.className = "cybershield-tooltip";
      document.body.appendChild(sharedTooltip);
    }
    return sharedTooltip;
  }

  function positionTooltip(linkEl) {
    const tooltip = getTooltip();
    const r = linkEl.getBoundingClientRect();
    tooltip.style.left = Math.max(0, Math.min(r.left, window.innerWidth - 220)) + "px";
    tooltip.style.top = (r.bottom + 6) + "px";
  }

  async function analyzeLink(linkEl) {
    const href = linkEl.href;
    if (!isAnalyzableUrl(href)) return;

    let result = analysisCache.get(href);
    if (!result) {
      try {
        const response = await chrome.runtime.sendMessage({
          type: "ANALYZE_URL",
          url: href,
        });
        if (!response || typeof response.score === "undefined") return;
        result = response;
        analysisCache.set(href, response);
        if (analysisCache.size > 300) analysisCache.clear();
      } catch (e) {
        return;
      }
    }

    const grade = getGradeKey(result.score, result.level);
    const color = colorMap[grade];
    const bg = bgMap[grade];

    linkEl.style.borderLeft = `3px solid ${color}`;
    linkEl.style.paddingLeft = "8px";
    linkEl.style.background = bg;
    linkEl.style.borderRadius = "2px";
    linkEl.style.transition = "all 0.2s ease";

    const phishingConfidence = result.phishingAnalysis ? result.phishingAnalysis.confidence : 0;
    let phishBadge = "";
    if (phishingConfidence >= 50) {
      phishBadge = `<span class="cs-phish-badge">Phishing ${phishingConfidence}%</span>`;
    } else if (phishingConfidence >= 30) {
      phishBadge = `<span class="cs-phish-badge cs-phish-warn">Suspicious ${phishingConfidence}%</span>`;
    }

    linkEl.addEventListener("mouseenter", () => {
      const tooltip = getTooltip();
      tooltip.innerHTML = `
        <span class="cs-score">${result.score}%</span>
        <span class="cs-level">${escapeHtml(result.level)}</span>
        ${phishBadge}
      `;
      positionTooltip(linkEl);
      tooltip.style.opacity = "1";
    });

    linkEl.addEventListener("mouseleave", () => {
      getTooltip().style.opacity = "0";
    });

    linkEl.addEventListener("mouseenter", () => {
      linkEl.style.boxShadow = `0 0 0 1px ${color}40`;
    });

    linkEl.addEventListener("mouseleave", () => {
      linkEl.style.boxShadow = "none";
    });
  }

  function processSearchResults() {
    const isSearchPage = /\/search(\?|$)/.test(window.location.pathname);
    const selector = isSearchPage
      ? "#search a[href], #rso a[href]"
      : "a[href]";
    const links = document.querySelectorAll(selector);
    links.forEach((link) => {
      if (link.dataset.cybershield) return;
      link.dataset.cybershield = "true";
      analyzeLink(link);
    });
  }

  function analyzePageContent() {
    const analysis = {
      hasFakeLoginForm: false,
      hasHiddenIframes: false,
      hasPasswordField: false,
      hasExternalFormAction: false,
      hasObfuscatedScript: false,
      hasDataUri: false,
      hasFakeSecurityBadges: false,
      hasUrgencyLanguage: false,
      hasCountdownTimer: false,
      hasFakeFinancialForm: false,
      hasTechSupportLanguage: false,
      hasPrizeLanguage: false,
      hasSocialLanguage: false,
      hasExternalResources: false,
      hasRedirectMeta: false,
      hasHiddenElements: false,
      brandMatches: [],
      formDetails: [],
      pageText: ""
    };

    const currentHost = window.location.hostname;

    analysis.pageText = extractPageText();

    const forms = document.querySelectorAll("form");
    forms.forEach((form, idx) => {
      const formDetail = { index: idx, action: null, hasPassword: false, fields: [] };

      const action = form.getAttribute("action");
      if (action) {
        try {
          const actionUrl = new URL(action, window.location.href);
          formDetail.action = actionUrl.href;
          if ((actionUrl.protocol === "http:" || actionUrl.protocol === "https:") &&
              actionUrl.hostname && actionUrl.hostname !== currentHost) {
            analysis.hasExternalFormAction = true;
          }
        } catch (e) {
          // Invalid action URL
        }
      }

      const passwordFields = form.querySelectorAll('input[type="password"]');
      if (passwordFields.length > 0) {
        analysis.hasPasswordField = true;
        formDetail.hasPassword = true;

        const usernameFields = form.querySelectorAll(
          'input[type="text"], input[type="email"], input[name*="user"], input[name*="login"], input[name*="email"], input[id*="user"], input[id*="login"], input[id*="email"]'
        );
        if (usernameFields.length > 0) {
          analysis.hasFakeLoginForm = true;
        }

        const allInputs = form.querySelectorAll("input, select, textarea");
        allInputs.forEach(input => {
          const name = input.getAttribute("name") || "";
          const id = input.getAttribute("id") || "";
          const placeholder = input.getAttribute("placeholder") || "";
          const type = input.getAttribute("type") || "text";
          formDetail.fields.push({ name, id, placeholder, type });
        });
      }

      const allInputs = form.querySelectorAll("input, select, textarea");
      allInputs.forEach(input => {
        const name = (input.getAttribute("name") || "").toLowerCase();
        const id = (input.getAttribute("id") || "").toLowerCase();
        const placeholder = (input.getAttribute("placeholder") || "").toLowerCase();
        const combined = name + id + placeholder;

        const financialKeywords = [
          "bank", "credit", "debit", "ssn", "social", "tax", "payment",
          "wire", "crypto", "bitcoin", "paypal", "account number", "routing",
          "pin", "cvv", "card"
        ];
        if (financialKeywords.some(k => combined.includes(k))) {
          analysis.hasFakeFinancialForm = true;
        }
      });

      analysis.formDetails.push(formDetail);
    });

    const iframes = document.querySelectorAll("iframe");
    iframes.forEach((iframe) => {
      const style = window.getComputedStyle(iframe);
      const isHidden =
        style.display === "none" ||
        style.visibility === "hidden" ||
        style.opacity === "0" ||
        iframe.width === "0" ||
        iframe.height === "0" ||
        iframe.offsetWidth === 0 ||
        iframe.offsetHeight === 0;
      if (isHidden) {
        analysis.hasHiddenIframes = true;
      }

      const src = iframe.getAttribute("src") || "";
      if (src && !src.startsWith("about:") && !src.startsWith("data:")) {
        try {
          const iframeUrl = new URL(src, window.location.href);
          if (iframeUrl.hostname !== currentHost) {
            analysis.hasExternalResources = true;
          }
        } catch (e) {
          // Invalid URL
        }
      }
    });

    const scripts = document.querySelectorAll("script");
    scripts.forEach((script) => {
      const content = script.textContent || "";
      if (content.length > 100) {
        const obfuscationPatterns = [
          /eval\s*\(/i,
          /document\.write\s*\(\s*unescape/i,
          /String\.fromCharCode/i,
          /\\x[0-9a-f]{2}/i,
          /\\u[0-9a-f]{4}/i,
          /atob\s*\(/i,
          /document\.location\s*=/i,
          /window\.location\s*=\s*["']http/i,
        ];
        let matchCount = 0;
        for (const pattern of obfuscationPatterns) {
          if (pattern.test(content)) matchCount++;
        }
        if (matchCount >= 2) {
          analysis.hasObfuscatedScript = true;
        }
      }
    });

    const dataElements = document.querySelectorAll(
      'img[src^="data:"], script[src^="data:"], iframe[src^="data:"], object[data^="data:"], embed[src^="data:"]'
    );
    if (dataElements.length > 0) {
      analysis.hasDataUri = true;
    }

    const lowerText = analysis.pageText.toLowerCase();

    const securityBadgeSelectors = [
      'img[alt*="ssl" i]', 'img[alt*="secure" i]', 'img[alt*="trusted" i]',
      'img[alt*="verified" i]', 'img[alt*="norton" i]', 'img[alt*="mcafee" i]',
      'img[alt*="geotrust" i]', 'img[alt*="symantec" i]', 'img[alt*="comodo" i]',
      'img[src*="ssl" i]', 'img[src*="secure" i]', 'img[src*="badge" i]',
      'img[src*="trust" i]', 'img[src*="verified" i]',
      '.ssl-badge', '.trust-seal', '.security-badge', '.verified-badge'
    ];
    for (const selector of securityBadgeSelectors) {
      if (document.querySelector(selector)) {
        analysis.hasFakeSecurityBadges = true;
        break;
      }
    }

    const urgencyKeywords = [
      "act now", "immediately", "urgent", "expires today", "limited time",
      "last chance", "don't miss", "hurry", "final notice", "verify now",
      "confirm identity", "update required", "action needed", "within 24 hours"
    ];
    analysis.hasUrgencyLanguage = urgencyKeywords.filter(k => lowerText.includes(k)).length >= 2;

    analysis.hasCountdownTimer = !!(
      document.querySelector('[class*="countdown" i], [id*="countdown" i], [class*="timer" i], [id*="timer" i]') ||
      /\d+\s*:\s*\d+\s*:\s*\d+/.test(analysis.pageText)
    );

    const techSupportKeywords = [
      "virus detected", "malware", "computer infected", "call now",
      "microsoft support", "apple support", "tech support", "helpline",
      "toll free", "remote access", "your computer is at risk"
    ];
    analysis.hasTechSupportLanguage = techSupportKeywords.filter(k => lowerText.includes(k)).length >= 2;

    const prizeKeywords = [
      "you won", "congratulations", "claim your prize", "lottery",
      "sweepstakes", "reward center", "million dollars", "lucky winner"
    ];
    analysis.hasPrizeLanguage = prizeKeywords.filter(k => lowerText.includes(k)).length >= 2;

    const socialKeywords = [
      "friend request", "new message", "someone tagged", "your post",
      "account review", "profile view", "follow back", "login alert"
    ];
    analysis.hasSocialLanguage = socialKeywords.filter(k => lowerText.includes(k)).length >= 2;

    const redirectMeta = document.querySelector(
      'meta[http-equiv="refresh"], meta[http-equiv="redirect"]'
    );
    if (redirectMeta) {
      const content = redirectMeta.getAttribute("content") || "";
      if (/url\s*=/i.test(content) || /\d+\s*;/.test(content)) {
        analysis.hasRedirectMeta = true;
      }
    }

    const hiddenElements = document.querySelectorAll(
      '[style*="display: none" i], [style*="visibility: hidden" i], [style*="opacity: 0" i], [hidden]'
    );
    if (hiddenElements.length > 5) {
      analysis.hasHiddenElements = true;
    }

    const brandPatterns = [
      /paypal/i, /apple/i, /google/i, /amazon/i, /microsoft/i,
      /facebook/i, /netflix/i, /instagram/i, /twitter/i, /linkedin/i,
      /chase/i, /wellsfargo/i, /bankofamerica/i, /citibank/i,
      /venmo/i, /zelle/i, /coinbase/i, /ebay/i, /walmart/i,
      /target/i, /steam/i, /discord/i, /twitch/i, /youtube/i,
      /whatsapp/i, /telegram/i, /gmail/i, /outlook/i, /yahoo/i
    ];
    const html = document.documentElement.outerHTML.toLowerCase();
    for (const pattern of brandPatterns) {
      if (pattern.test(html)) {
        const match = html.match(pattern);
        if (match) analysis.brandMatches.push(match[0]);
      }
    }
    analysis.brandMatches = [...new Set(analysis.brandMatches)];

    return analysis;
  }

  function extractPageText() {
    const MAX_TEXT_LENGTH = 10000;
    const MAX_ELEMENTS = 500;
    const parts = [];
    let totalLength = 0;

    const title = document.title;
    if (title) parts.push(title);

    const headings = document.querySelectorAll("h1, h2, h3, h4, h5, h6");
    headings.forEach(h => {
      if (totalLength >= MAX_TEXT_LENGTH) return;
      const t = h.textContent.trim();
      parts.push(t);
      totalLength += t.length;
    });

    const textElements = document.querySelectorAll("p, li, a, button, label");
    let count = 0;
    textElements.forEach(el => {
      if (totalLength >= MAX_TEXT_LENGTH || count >= MAX_ELEMENTS) return;
      const text = el.textContent.trim();
      if (text.length > 5 && text.length < 500) {
        parts.push(text);
        totalLength += text.length;
        count++;
      }
    });

    const meta = document.querySelectorAll('meta[name="description"], meta[name="keywords"]');
    meta.forEach(m => {
      const content = m.getAttribute("content");
      if (content) parts.push(content);
    });

    const inputs = document.querySelectorAll("input[placeholder], input[aria-label], textarea[placeholder], textarea[aria-label]");
    inputs.forEach(input => {
      const placeholder = input.getAttribute("placeholder");
      const label = input.getAttribute("aria-label");
      if (placeholder) parts.push(placeholder);
      if (label) parts.push(label);
    });

    return parts.join(" ");
  }

  function createPhishingBadge(phishingAnalysis) {
    if (!phishingAnalysis || phishingAnalysis.confidence < 30) return;

    const existing = document.getElementById("cybershield-phishing-badge");
    if (existing) existing.remove();

    const badge = document.createElement("div");
    badge.id = "cybershield-phishing-badge";
    badge.className = "cybershield-phishing-badge";

    let color, bgColor, borderColor;
    if (phishingAnalysis.riskLevel === "critical") {
      color = "#ff4444";
      bgColor = "rgba(255, 68, 68, 0.95)";
      borderColor = "#ff4444";
    } else if (phishingAnalysis.riskLevel === "high") {
      color = "#f85149";
      bgColor = "rgba(248, 81, 73, 0.95)";
      borderColor = "#f85149";
    } else if (phishingAnalysis.riskLevel === "medium") {
      color = "#d29922";
      bgColor = "rgba(210, 153, 34, 0.95)";
      borderColor = "#d29922";
    } else {
      color = "#8b949e";
      bgColor = "rgba(30, 35, 44, 0.95)";
      borderColor = "#30363d";
    }

    badge.style.cssText = `
      position: fixed;
      top: 12px;
      right: 12px;
      z-index: 2147483647;
      background: ${bgColor};
      color: #fff;
      border: 2px solid ${borderColor};
      border-radius: 10px;
      padding: 10px 14px;
      font-family: 'Segoe UI', system-ui, sans-serif;
      font-size: 13px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.4);
      max-width: 280px;
      cursor: pointer;
      transition: all 0.2s ease;
    `;

    badge.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
        <span style="font-size:18px;">${escapeHtml(phishingAnalysis.category.icon)}</span>
        <div>
          <div style="font-weight:700;font-size:14px;">Phishing Detected</div>
          <div style="font-size:11px;opacity:0.9;">${phishingAnalysis.confidence}% confidence</div>
        </div>
        <span style="margin-left:auto;font-size:16px;opacity:0.7;">&times;</span>
      </div>
      <div style="font-size:11px;opacity:0.85;line-height:1.4;">
        <strong>${escapeHtml(phishingAnalysis.category.name)}</strong>
        ${escapeHtml(phishingAnalysis.category.description)}
      </div>
    `;

    let expanded = false;
    const detailsDiv = document.createElement("div");
    detailsDiv.style.cssText = "display:none;margin-top:8px;font-size:11px;max-height:150px;overflow-y:auto;";
    detailsDiv.innerHTML = phishingAnalysis.indicators.slice(0, 5).map(ind =>
      `<div style="padding:2px 0;opacity:0.85;">
        <span style="color:${ind.severity === 'high' ? '#ff6b6b' : ind.severity === 'medium' ? '#ffd93d' : '#8b949e'};">&#9679;</span>
        ${escapeHtml(ind.text)}
      </div>`
    ).join("");
    badge.appendChild(detailsDiv);

    badge.addEventListener("click", (e) => {
      if (e.target.textContent === "\u00d7") {
        badge.remove();
        return;
      }
      expanded = !expanded;
      detailsDiv.style.display = expanded ? "block" : "none";
    });

    document.body.appendChild(badge);
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "ANALYZE_PAGE") {
      const contentAnalysis = analyzePageContent();
      try {
        chrome.runtime.sendMessage({
          type: "CONTENT_ANALYSIS",
          url: message.url || window.location.href,
          contentAnalysis
        }, (result) => {
          if (chrome.runtime.lastError) return;
          if (result && result.phishingAnalysis) {
            createPhishingBadge(result.phishingAnalysis);
          }
          sendResponse(result);
        });
      } catch (e) {}
      return true;
    }

    if (message.type === "GET_PAGE_ANALYSIS") {
      const contentAnalysis = analyzePageContent();
      sendResponse({ contentAnalysis });
      return false;
    }
  });

  processSearchResults();

  const observer = new MutationObserver(() => {
    clearTimeout(observerTimer);
    observerTimer = setTimeout(processSearchResults, 150);
  });

  observer.observe(document.body, { childList: true, subtree: true });

  setTimeout(() => {
    if (window.location.search.includes("_cybershield_bypass")) return;
    if (window.location.protocol !== "http:" && window.location.protocol !== "https:") return;

    const isGoogleSearch = window.location.hostname.includes("google.") &&
      window.location.pathname.includes("/search");
    if (isGoogleSearch) return;

    const contentAnalysis = analyzePageContent();
    try {
      chrome.runtime.sendMessage({
        type: "CONTENT_ANALYSIS",
        url: window.location.href,
        contentAnalysis
      }, (result) => {
        if (chrome.runtime.lastError) return;
        if (result && result.phishingAnalysis) {
          createPhishingBadge(result.phishingAnalysis);
        }
      });
    } catch (e) {}
  }, 1500);
})();
