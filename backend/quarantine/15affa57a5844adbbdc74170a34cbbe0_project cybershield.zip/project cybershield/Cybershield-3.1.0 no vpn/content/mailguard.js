(function () {
  if (window.__cybershield_mailguard_init) return;
  window.__cybershield_mailguard_init = true;

  var colorMap = {
    safe: "#3fb950",
    moderate: "#d29922",
    high: "#f85149"
  };

  var bgMap = {
    safe: "rgba(63, 185, 80, 0.08)",
    moderate: "rgba(210, 153, 34, 0.08)",
    high: "rgba(248, 81, 73, 0.08)"
  };

  var PANEL = null;
  var OBSERVER = null;
  var URL_INTERVAL = null;
  var LAST_URL = "";
  var DEBOUNCE = null;
  var ROW_CACHE = new Map();
  var SCANNED = new WeakSet();
  var ANALYSIS_CACHE = new Map();
  var CURRENT_DATA = null;

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function find(el, sels) {
    if (!el) return null;
    for (var i = 0; i < sels.length; i++) {
      var f = el.querySelector(sels[i]);
      if (f) return f;
    }
    return null;
  }

  function findAll(el, sels) {
    if (!el) return [];
    for (var i = 0; i < sels.length; i++) {
      var f = el.querySelectorAll(sels[i]);
      if (f.length) return Array.prototype.slice.call(f);
    }
    return [];
  }

  function checkEnabled() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(["mailGuardEnabled"], function (d) {
          resolve(d.mailGuardEnabled !== false);
        });
      } catch (e) { resolve(true); }
    });
  }

  function getView() {
    var h = window.location.hash || "";
    if (h.indexOf("#compose") !== -1 || h.indexOf("/compose") !== -1) return "compose";
    return "mail";
  }

  function getGradeKey(score) {
    if (score >= 80) return "safe";
    if (score >= 50) return "moderate";
    return "high";
  }

  // ---- ROW SCANNING ----
  function getRows() {
    var rows = document.querySelectorAll("tr.zA");
    if (rows.length) return rows;
    rows = document.querySelectorAll("tr[role='row']");
    if (rows.length) return rows;
    rows = document.querySelectorAll("tbody tr");
    if (rows.length > 2) return rows;
    return [];
  }

  function getRowThreadId(row) {
    var id = row.getAttribute("data-thread-id");
    if (id) return id;
    var links = row.querySelectorAll("a[href]");
    for (var i = 0; i < links.length; i++) {
      var m = links[i].href.match(/\/([A-Z0-9]{16,})(?:\?|$|#)/);
      if (m) return m[1];
    }
    return null;
  }

  function getRowInfo(row) {
    var threadId = getRowThreadId(row);
    if (!threadId) return null;

    var senderEl = find(row, ["span[email]", "[email]", "a[data-hovercard-id]"]);
    var sender = senderEl ? (senderEl.getAttribute("email") || senderEl.getAttribute("data-hovercard-id") || "") : "";

    var subjEl = find(row, [".bog", ".y6 .bog", ".y6 span", "span.bog"]);
    var subject = subjEl ? subjEl.textContent.trim().slice(0, 200) : "";

    var snipEl = find(row, [".y2", ".y2 span", "span.y2"]);
    var snippet = snipEl ? snipEl.textContent.trim().slice(0, 400) : "";

    return { threadId: threadId, sender: sender, subject: subject, snippet: snippet };
  }

  function applyRowGrade(row, score) {
    if (!row) return;
    var grade = getGradeKey(score);
    var color = colorMap[grade];
    var bg = bgMap[grade];

    row.style.borderLeft = "3px solid " + color;
    row.style.paddingLeft = "8px";
    row.style.background = bg;
    row.style.borderRadius = "2px";
    row.style.transition = "all 0.2s ease";

    var firstTd = row.querySelector("td:first-child");
    if (firstTd && !firstTd.querySelector(".cs-mg-grade")) {
      var pill = document.createElement("span");
      pill.className = "cs-mg-grade";
      pill.textContent = score + "%";
      pill.style.cssText =
        "display:inline-block;font-size:10px;font-weight:700;padding:2px 6px;" +
        "border-radius:3px;margin-right:6px;vertical-align:middle;" +
        "font-family:system-ui,sans-serif;white-space:nowrap;" +
        "color:" + color + ";background:" + color + "18;border:1px solid " + color + "44;";
      firstTd.insertBefore(pill, firstTd.firstChild);
    }
  }

  function scanAllRows() {
    var rows = getRows();
    if (!rows.length) return;

    var toAnalyze = [];
    for (var i = 0; i < rows.length && i < 100; i++) {
      var row = rows[i];
      if (SCANNED.has(row)) continue;
      var info = getRowInfo(row);
      if (!info) continue;
      SCANNED.add(row);

      if (ROW_CACHE.has(info.threadId)) {
        applyRowGrade(row, ROW_CACHE.get(info.threadId));
        continue;
      }
      toAnalyze.push({ row: row, info: info });
    }

    if (!toAnalyze.length) return;

    var batch = toAnalyze.map(function (p) {
      return { key: p.info.threadId, senderRaw: p.info.sender, subject: p.info.subject, snippet: p.info.snippet };
    });

    chrome.runtime.sendMessage({ type: "MAILGUARD_ANALYZE_ROWS", rows: batch }, function (resp) {
      if (!resp || !resp.enabled || !resp.results) return;
      var byKey = {};
      resp.results.forEach(function (r) { byKey[r.key] = r; });
      for (var k = 0; k < toAnalyze.length; k++) {
        var result = byKey[toAnalyze[k].info.threadId];
        if (!result) continue;
        ROW_CACHE.set(toAnalyze[k].info.threadId, result.score);
        applyRowGrade(toAnalyze[k].row, result.score);
      }
    });
  }

  function clearRowGrades() {
    var styled = document.querySelectorAll("tr[style*='border-left']");
    for (var i = 0; i < styled.length; i++) {
      styled[i].style.borderLeft = "";
      styled[i].style.paddingLeft = "";
      styled[i].style.background = "";
      styled[i].style.borderRadius = "";
      styled[i].style.transition = "";
    }
    document.querySelectorAll(".cs-mg-grade").forEach(function (p) { p.remove(); });
    ROW_CACHE.clear();
  }

  // ---- ANALYZER PANEL ----
  function extractEmail() {
    var main = find(document, ["div[role='main']", ".nH .nH", "#center_col"]);
    if (!main) return null;

    var subjEl = find(main, ["h2[data-thread-perm-id]", "h2.hP", ".ha h2"]);
    var subject = subjEl ? subjEl.textContent.trim().slice(0, 300) : "";

    var senderEl = find(main, ["[email]", "span[email]", "a[data-hovercard-id]", "a[href^='mailto:']"]);
    var sender = "";
    if (senderEl) {
      sender = senderEl.getAttribute("email") || senderEl.getAttribute("data-hovercard-id") || "";
    }

    var bodyEl = find(main, [".a3s.aiL", ".a3s", "div[dir='ltr']"]);
    var bodyText = bodyEl ? (bodyEl.innerText || bodyEl.textContent || "").trim().slice(0, 5000) : "";

    var links = [];
    if (bodyEl) {
      var seen = {};
      var anchors = bodyEl.querySelectorAll("a[href]");
      for (var i = 0; i < anchors.length && links.length < 25; i++) {
        var href = anchors[i].getAttribute("href") || "";
        if (!/^https?:/i.test(href) && href.indexOf("//") !== 0) continue;
        var text = (anchors[i].textContent || "").trim().slice(0, 120);
        var key = href + "|" + text;
        if (seen[key]) continue;
        seen[key] = true;
        links.push({ href: href, text: text });
      }
    }

    var attachments = [];
    var attEls = findAll(main, ["a[download]", "a[href*='mail-attachment']", ".aQH a"]);
    var seenAtt = {};
    for (var j = 0; j < attEls.length && attachments.length < 10; j++) {
      var name = attEls[j].getAttribute("download") || attEls[j].getAttribute("title") || attEls[j].textContent.trim() || "";
      name = String(name).replace(/\s+/g, " ").trim().slice(0, 150);
      if (!name || seenAtt[name]) continue;
      seenAtt[name] = true;
      attachments.push({ name: name });
    }

    return { senderRaw: sender, subject: subject, bodyText: bodyText, links: links, attachments: attachments };
  }

  function hasOpenEmail() {
    var body = find(document, [".a3s.aiL", ".a3s"]);
    var subject = find(document, ["h2[data-thread-perm-id]", "h2.hP"]);
    return body && body.textContent.trim().length > 10 && subject;
  }

  function createPanel() {
    if (PANEL && document.body.contains(PANEL)) return PANEL;
    PANEL = document.createElement("div");
    PANEL.id = "cs-mg-analyzer";
    PANEL.innerHTML =
      '<div class="cs-mg-hdr">' +
        '<span class="cs-mg-shield-icon">\uD83D\uDEE1\uFE0F</span>' +
        '<span class="cs-mg-hdr-title">MailGuard</span>' +
        '<button class="cs-mg-toggle" title="Collapse">\u2212</button>' +
      '</div>' +
      '<div class="cs-mg-bd">' +
        '<div class="cs-mg-empty-state">' +
          '<div class="cs-mg-empty-icon">\uD83D\uDC4B</div>' +
          '<div class="cs-mg-empty-text">No email selected</div>' +
          '<div class="cs-mg-empty-sub">Open an email to analyze its safety</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(PANEL);
    PANEL.querySelector(".cs-mg-toggle").addEventListener("click", function () {
      PANEL.classList.toggle("cs-mg-minimized");
      this.textContent = PANEL.classList.contains("cs-mg-minimized") ? "+" : "\u2212";
    });
    return PANEL;
  }

  function showEmpty() {
    if (!PANEL) createPanel();
    PANEL.querySelector(".cs-mg-bd").innerHTML =
      '<div class="cs-mg-empty-state">' +
        '<div class="cs-mg-empty-icon">\uD83D\uDC4B</div>' +
        '<div class="cs-mg-empty-text">No email selected</div>' +
        '<div class="cs-mg-empty-sub">Open an email to analyze its safety</div>' +
      '</div>';
    PANEL.style.display = "";
  }

  function showLoading() {
    if (!PANEL) createPanel();
    PANEL.querySelector(".cs-mg-bd").innerHTML =
      '<div class="cs-mg-loading-state">' +
        '<div class="cs-mg-spinner"></div>' +
        '<div class="cs-mg-loading-text">Analyzing email...</div>' +
      '</div>';
    PANEL.style.display = "";
  }

  function showResult(result) {
    if (!PANEL) createPanel();
    var bd = PANEL.querySelector(".cs-mg-bd");
    if (!result) { showEmpty(); return; }

    var grade = getGradeKey(result.score);
    var color = colorMap[grade];
    var labels = { safe: "SAFE", moderate: "SUSPICIOUS", high: "UNSAFE" };
    var icons = { safe: "\u2705", moderate: "\u26A0\uFE0F", high: "\u274C" };
    var label = labels[grade];
    var icon = icons[grade];

    var threatsHtml = "";
    if (result.threats && result.threats.length) {
      threatsHtml = '<div class="cs-mg-issues">';
      for (var i = 0; i < Math.min(result.threats.length, 6); i++) {
        threatsHtml += '<div class="cs-mg-issue-item">' +
          '<span class="cs-mg-issue-dot" style="background:' + color + '"></span>' +
          '<span>' + esc(result.threats[i]) + '</span></div>';
      }
      if (result.threats.length > 6) {
        threatsHtml += '<div class="cs-mg-more">+' + (result.threats.length - 6) + ' more</div>';
      }
      threatsHtml += '</div>';
    }

    var senderDomain = (result.senderRaw || "").split("@")[1] || "unknown";

    bd.innerHTML =
      '<div class="cs-mg-verdict-block" style="background:' + color + '10;border:1px solid ' + color + '33">' +
        '<div class="cs-mg-verdict-row">' +
          '<span class="cs-mg-verdict-icon">' + icon + '</span>' +
          '<span class="cs-mg-verdict-label" style="color:' + color + '">' + label + '</span>' +
        '</div>' +
        '<div class="cs-mg-score-ring" style="border-color:' + color + '">' +
          '<span class="cs-mg-score-num" style="color:' + color + '">' + result.score + '</span>' +
          '<span class="cs-mg-score-of">/100</span>' +
        '</div>' +
      '</div>' +
      '<div class="cs-mg-detail-row">' +
        '<span class="cs-mg-detail-label">From</span>' +
        '<span class="cs-mg-detail-value">' + esc(senderDomain) + '</span>' +
      '</div>' +
      '<div class="cs-mg-detail-row">' +
        '<span class="cs-mg-detail-label">Subject</span>' +
        '<span class="cs-mg-detail-value">' + esc((result.subject || "No subject").slice(0, 60)) + '</span>' +
      '</div>' +
      threatsHtml +
      '<div class="cs-mg-rec-box" style="border-left:3px solid ' + color + ';background:' + color + '08">' +
        esc(result.recommendation || "") +
      '</div>' +
      '<div class="cs-mg-panel-footer">MailGuard \u00B7 CyberShield</div>';
    PANEL.style.display = "";
  }

  function analyzeCurrentEmail() {
    if (!PANEL) createPanel();
    showLoading();

    var data = extractEmail();
    if (!data || (!data.bodyText && !data.subject)) {
      showEmpty();
      CURRENT_DATA = null;
      return;
    }

    var cacheKey = data.senderRaw + "|" + data.subject;
    if (ANALYSIS_CACHE.has(cacheKey)) {
      var cached = ANALYSIS_CACHE.get(cacheKey);
      cached.senderRaw = data.senderRaw;
      cached.subject = data.subject;
      showResult(cached);
      CURRENT_DATA = data;
      return;
    }

    CURRENT_DATA = data;
    chrome.runtime.sendMessage({ type: "MAILGUARD_ANALYZE_EMAIL", payload: data }, function (resp) {
      if (chrome.runtime.lastError || !resp || !resp.enabled || !resp.result) {
        showEmpty();
        return;
      }
      var r = resp.result;
      r.senderRaw = data.senderRaw;
      r.subject = data.subject;
      ANALYSIS_CACHE.set(cacheKey, r);
      showResult(r);

      if (r.risk === "high" && data.subject) {
        chrome.runtime.sendMessage({
          type: "MAILGUARD_NOTIFY",
          threadId: cacheKey,
          subject: data.subject,
          score: r.score
        }, function () {});
      }
    });
  }

  // ---- SPA NAVIGATION ----
  function onNavigation() {
    var cur = window.location.href;
    if (cur === LAST_URL) return;
    LAST_URL = cur;
    SCANNED = new WeakSet();

    var view = getView();
    setTimeout(function () {
      scanAllRows();
      if (view === "compose") {
        showEmpty();
        CURRENT_DATA = null;
      } else if (hasOpenEmail()) {
        analyzeCurrentEmail();
      } else {
        showEmpty();
        CURRENT_DATA = null;
      }
    }, 1000);
  }

  function startNavWatch() {
    LAST_URL = window.location.href;
    URL_INTERVAL = setInterval(onNavigation, 1200);

    var origPush = history.pushState;
    var origReplace = history.replaceState;
    history.pushState = function () {
      origPush.apply(this, arguments);
      setTimeout(onNavigation, 300);
    };
    history.replaceState = function () {
      origReplace.apply(this, arguments);
      setTimeout(onNavigation, 300);
    };
    window.addEventListener("popstate", function () {
      setTimeout(onNavigation, 300);
    });
  }

  function startObserver() {
    if (OBSERVER) return;
    OBSERVER = new MutationObserver(function () {
      clearTimeout(DEBOUNCE);
      DEBOUNCE = setTimeout(function () {
        scanAllRows();
        if (hasOpenEmail()) {
          var subject = find(document, ["h2[data-thread-perm-id]", "h2.hP"]);
          var subjText = subject ? subject.textContent.trim() : "";
          if (!CURRENT_DATA || CURRENT_DATA.subject !== subjText) {
            analyzeCurrentEmail();
          }
        } else if (CURRENT_DATA) {
          showEmpty();
          CURRENT_DATA = null;
        }
      }, 600);
    });
    OBSERVER.observe(document.body, { childList: true, subtree: true });
  }

  function stopMailguard() {
    if (OBSERVER) { OBSERVER.disconnect(); OBSERVER = null; }
    if (URL_INTERVAL) { clearInterval(URL_INTERVAL); URL_INTERVAL = null; }
    if (PANEL) { PANEL.remove(); PANEL = null; }
    clearRowGrades();
    CURRENT_DATA = null;
  }

  function startMailguard() {
    checkEnabled().then(function (on) {
      if (!on) { stopMailguard(); return; }
      createPanel();
      showEmpty();
      startNavWatch();
      startObserver();
      setTimeout(onNavigation, 1500);

      setTimeout(function () {
        try {
          chrome.storage.session.get(["csMgToastShown"], function (s) {
            if (s && s.csMgToastShown) return;
            chrome.storage.session.set({ csMgToastShown: Date.now() });
            var toast = document.createElement("div");
            toast.className = "cs-mg-toast";
            toast.innerHTML =
              '<div class="cs-mg-toast-title">\uD83D\uDEE1\uFE0F MailGuard Active</div>' +
              '<div class="cs-mg-toast-body">Gmail emails are being analyzed for phishing and scams.</div>' +
              '<button class="cs-mg-toast-close">\u00D7</button>';
            document.body.appendChild(toast);
            toast.querySelector(".cs-mg-toast-close").addEventListener("click", function () { toast.remove(); });
            setTimeout(function () { if (toast.parentNode) toast.remove(); }, 6000);
          });
        } catch (e) {}
      }, 2500);
    });
  }

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.mailGuardEnabled) {
      if (changes.mailGuardEnabled.newValue === false) stopMailguard();
      else startMailguard();
    }
  });

  startMailguard();
})();