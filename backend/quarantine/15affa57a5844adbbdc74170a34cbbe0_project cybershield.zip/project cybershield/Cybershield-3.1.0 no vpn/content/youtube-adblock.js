(function() {
  const AD_SELECTORS = [
    ".video-ads",
    ".ad-container",
    ".ytp-ad-overlay-container",
    ".ytp-ad-text-overlay",
    ".ytp-ad-image-overlay",
    ".ytp-ad-video-overlay",
    "#player-ads",
    ".ytd-player-legacy-desktop-watch-ads-overlay-renderer",
    ".ytd-promoted-sparkles-web-renderer",
    ".ytd-ad-slot-renderer",
    ".ytd-display-ad-renderer",
    ".ytd-in-feed-ad-layout-renderer",
    ".ytd-banner-promo-renderer",
    ".ytd-statement-banner-renderer",
    ".ytd-video-masthead-ad-v3-renderer",
    ".ytd-primetime-promo-renderer",
    ".ytd-promoted-video-renderer",
    ".ytd-compact-promoted-video-renderer",
    ".ytd-ad-renderer",
    "#masthead-ad",
    "ytd-ad-slot-renderer",
    ".ytd-in-feed-ad-renderer",
    ".ytd-ad-inline-playback-renderer"
  ];

  const VIDEO_AD_CSS = [
    AD_SELECTORS.join(", ") + " { display: none !important; }",
    ".ytp-ad-player-overlay { display: none !important; }",
    ".ytp-ad-showing .html5-video-player > video { visibility: visible !important; }",
    ".ytp-ad-showing .html5-video-player .ytp-chrome-bottom { display: none !important; }"
  ].join("\n");

  let adStyle = null;
  let skipTimer = null;

  function injectCss() {
    if (adStyle && adStyle.parentNode) return;
    adStyle = document.createElement("style");
    adStyle.textContent = VIDEO_AD_CSS;
    (document.head || document.documentElement).appendChild(adStyle);
  }

  function getSkipButton() {
    return document.querySelector(
      ".ytp-ad-skip-button, .ytp-skip-button, .ytp-ad-skip-button-modern, " +
      ".ytp-ad-skip-button-slot .ytp-button, [class*='skip-button'], " +
      ".ytp-skip-ad-button, button.ytp-ad-skip-button-modern"
    );
  }

  function isAdPlaying() {
    return !!document.querySelector(
      ".ad-showing, .ytp-ad-player-overlay, .ytp-ad-overlay-container, " +
      ".ytp-ad-text-overlay, .video-ads"
    );
  }

  function hideOverlayAds() {
    const overlays = document.querySelectorAll(
      ".ytp-ad-overlay-container, .ytp-ad-text-overlay, .ytp-ad-image-overlay, .ytp-ad-video-overlay"
    );
    overlays.forEach(el => {
      if (el && el.parentNode) el.style.display = "none";
    });
  }

  function skipAds() {
    const skipBtn = getSkipButton();
    if (skipBtn) {
      try {
        skipBtn.click();
      } catch (e) {}
      try {
        skipBtn.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
      } catch (e) {}
      return;
    }

    if (!isAdPlaying()) return;

    const video = document.querySelector("video");
    if (!video) return;

    try {
      if (video.duration && video.duration > 0 && video.duration < 40) {
        video.currentTime = video.duration;
      }
    } catch (e) {}

    try {
      video.play();
    } catch (e) {}
  }

  function run() {
    injectCss();
    skipAds();
    hideOverlayAds();
  }

  function fastLoop() {
    if (isAdPlaying()) {
      skipAds();
      hideOverlayAds();
    }
  }

  chrome.storage.local.get(["adBlockerEnabled"], (settings) => {
    if (settings.adBlockerEnabled === false) return;

    if (document.body) {
      run();
    } else {
      const interval = setInterval(() => {
        if (document.body) {
          clearInterval(interval);
          run();
        }
      }, 200);
      setTimeout(() => clearInterval(interval), 10000);
    }

    skipTimer = setInterval(fastLoop, 100);

    const observer = new MutationObserver(() => {
      skipAds();
      hideOverlayAds();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  });
})();
