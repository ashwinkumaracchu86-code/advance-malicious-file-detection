const scoreEl = document.getElementById("scoreValue");
const ringFill = document.getElementById("ringFill");
const levelBadge = document.getElementById("levelBadge");
const reasonsEl = document.getElementById("reasons");
const urlDisplay = document.getElementById("urlDisplay");
const loadingEl = document.getElementById("loading");
const resultEl = document.getElementById("result");
const errorEl = document.getElementById("error");
const settingsBtn = document.getElementById("settingsBtn");
const settingsPanel = document.getElementById("settings");
const blockedInput = document.getElementById("blockedInput");
const safeInput = document.getElementById("safeInput");
const addBlockedBtn = document.getElementById("addBlocked");
const addSafeBtn = document.getElementById("addSafe");
const blockedTags = document.getElementById("blockedTags");
const safeTags = document.getElementById("safeTags");
const saveSettingsBtn = document.getElementById("saveSettings");
const saveMsg = document.getElementById("saveMsg");
const themeToggle = document.getElementById("themeToggle");
const blockingToggle = document.getElementById("blockingToggle");
const notificationsToggle = document.getElementById("notificationsToggle");
const phishingToggle = document.getElementById("phishingToggle");
const adBlockerToggle = document.getElementById("adBlockerToggle");
const mailGuardToggle = document.getElementById("mailGuardToggle");
const adBlockerBtn = document.getElementById("adBlockerBtn");
const adBlockerLabel = document.getElementById("adBlockerLabel");
const phishingPanel = document.getElementById("phishingPanel");
const phishingIcon = document.getElementById("phishingIcon");
const phishingTitle = document.getElementById("phishingTitle");
const confidenceFill = document.getElementById("confidenceFill");
const confidenceValue = document.getElementById("confidenceValue");
const phishingCategory = document.getElementById("phishingCategory");
const phishingSummary = document.getElementById("phishingSummary");
const phishingIndicators = document.getElementById("phishingIndicators");
const reportBtn = document.getElementById("reportBtn");
const reportForm = document.getElementById("reportForm");
const reportType = document.getElementById("reportType");
const reportNotes = document.getElementById("reportNotes");
const submitReport = document.getElementById("submitReport");
const reportSuccess = document.getElementById("reportSuccess");
const domainInfo = document.getElementById("domainInfo");
const diAge = document.getElementById("diAge");
const diHttps = document.getElementById("diHttps");
const diCert = document.getElementById("diCert");
const diCreated = document.getElementById("diCreated");
const diRefresh = document.getElementById("diRefresh");

const CIRCUMFERENCE = 2 * Math.PI * 50;

let currentBlocked = [];
let currentSafe = [];
let showingSettings = false;
let currentTheme = "dark";
let currentPhishingAnalysis = null;
let currentUrl = "";

function getBadgeClass(level) {
  if (level === "Safe") return "safe";
  if (level === "Moderate Risk") return "moderate";
  if (level === "Blocked") return "blocked";
  return "high";
}

function getScoreColor(score) {
  if (score >= 80) return "#3fb950";
  if (score >= 50) return "#d29922";
  return "#f85149";
}

function getConfidenceColor(confidence) {
  if (confidence >= 70) return "#f85149";
  if (confidence >= 50) return "#d29922";
  if (confidence >= 30) return "#e3b341";
  return "#3fb950";
}

function setRing(score) {
  const offset = CIRCUMFERENCE - (score / 100) * CIRCUMFERENCE;
  ringFill.style.strokeDasharray = CIRCUMFERENCE;
  ringFill.style.strokeDashoffset = offset;
  const color = getScoreColor(score);
  ringFill.style.stroke = score >= 80 ? "url(#ringGradientSafe)"
    : score >= 50 ? "url(#ringGradientModerate)"
    : "url(#ringGradientHigh)";
  ringFill.style.filter = `drop-shadow(0 0 5px ${color}aa)`;
}

function animateScore(target) {
  const startTime = performance.now();
  const duration = 700;
  const tick = (now) => {
    const p = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - p, 3);
    scoreEl.textContent = Math.round(target * eased);
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function renderTags(container, items, type) {
  container.innerHTML = "";
  items.forEach((item, i) => {
    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = item;
    const removeBtn = document.createElement("span");
    removeBtn.className = "tag-remove";
    removeBtn.textContent = "\u00d7";
    removeBtn.addEventListener("click", () => {
      if (type === "blocked") currentBlocked.splice(i, 1);
      else currentSafe.splice(i, 1);
      renderTags(blockedTags, currentBlocked, "blocked");
      renderTags(safeTags, currentSafe, "safe");
    });
    tag.appendChild(removeBtn);
    container.appendChild(tag);
  });
}

function renderPhishingPanel(phishingAnalysis) {
  if (!phishingAnalysis || phishingAnalysis.confidence < 15) {
    phishingPanel.classList.add("hidden");
    return;
  }

  currentPhishingAnalysis = phishingAnalysis;
  phishingPanel.classList.remove("hidden");

  phishingIcon.textContent = phishingAnalysis.category.icon;

  let titleText = "Phishing Analysis";
  let titleColor = "var(--text-primary)";
  if (phishingAnalysis.riskLevel === "critical") {
    titleText = "Critical Phishing Threat";
    titleColor = "#f85149";
  } else if (phishingAnalysis.riskLevel === "high") {
    titleText = "High Phishing Risk";
    titleColor = "#f85149";
  } else if (phishingAnalysis.riskLevel === "medium") {
    titleText = "Suspicious Activity";
    titleColor = "#d29922";
  } else if (phishingAnalysis.riskLevel === "low") {
    titleText = "Minor Indicators";
    titleColor = "#e3b341";
  }
  phishingTitle.textContent = titleText;
  phishingTitle.style.color = titleColor;

  const confColor = getConfidenceColor(phishingAnalysis.confidence);
  confidenceFill.style.width = phishingAnalysis.confidence + "%";
  confidenceFill.style.background = confColor;
  confidenceValue.textContent = phishingAnalysis.confidence + "%";
  confidenceValue.style.color = confColor;

  phishingCategory.innerHTML = `
    <span class="category-badge">${phishingAnalysis.category.name}</span>
    <span class="category-desc">${phishingAnalysis.category.description}</span>
  `;

  phishingSummary.textContent = phishingAnalysis.summary;

  phishingIndicators.innerHTML = "";
  const topIndicators = phishingAnalysis.indicators.slice(0, 8);
  topIndicators.forEach(ind => {
    const div = document.createElement("div");
    div.className = "indicator-item";

    let severityColor, severityBg;
    if (ind.severity === "high") {
      severityColor = "#f85149";
      severityBg = "rgba(248, 81, 73, 0.15)";
    } else if (ind.severity === "medium") {
      severityColor = "#d29922";
      severityBg = "rgba(210, 153, 34, 0.15)";
    } else {
      severityColor = "#8b949e";
      severityBg = "rgba(139, 148, 158, 0.15)";
    }

    div.innerHTML = `
      <span class="indicator-dot" style="background:${severityColor};"></span>
      <span class="indicator-text">${ind.text}</span>
      <span class="indicator-severity" style="color:${severityColor};background:${severityBg};">${ind.severity}</span>
    `;
    phishingIndicators.appendChild(div);
  });

  if (phishingAnalysis.indicators.length > 8) {
    const more = document.createElement("div");
    more.className = "indicator-more";
    more.textContent = `+${phishingAnalysis.indicators.length - 8} more indicators`;
    phishingIndicators.appendChild(more);
  }
}

function formatDomainAge(years) {
  if (years === null || years === undefined) return "Unknown";
  if (years < 1) {
    const months = Math.max(1, Math.round(years * 12));
    return "Under " + months + " month" + (months > 1 ? "s" : "");
  }
  const rounded = Math.round(years * 10) / 10;
  return rounded + " yrs";
}

function formatCreatedDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const opts = { year: "numeric", month: "short", day: "numeric" };
  return "Registered " + d.toLocaleDateString(undefined, opts);
}

async function loadDomainInfo(forceRefresh) {
  if (!currentUrl) return;
  domainInfo.classList.remove("hidden");

  const refreshBtn = diRefresh;
  if (refreshBtn) refreshBtn.classList.add("spinning");

  let info = null;
  try {
    info = await chrome.runtime.sendMessage({ type: "GET_DOMAIN_INFO", url: currentUrl, forceRefresh: !!forceRefresh });
  } catch (e) {
    info = null;
  } finally {
    if (refreshBtn) refreshBtn.classList.remove("spinning");
  }

  if (!info || typeof info.isHttps === "undefined") {
    try {
      const isHttps = new URL(currentUrl).protocol === "https:";
      info = {
        isHttps,
        certificateValid: isHttps,
        ageYears: null,
        createdDate: null
      };
    } catch (e) {
      info = null;
    }
  }

  renderDomainInfo(info);
}

function renderDomainInfo(info) {
  if (!info) {
    diAge.textContent = "N/A";
    diAge.className = "di-value di-muted";
    diHttps.textContent = "N/A";
    diHttps.className = "di-value di-muted";
    diCert.textContent = "N/A";
    diCert.className = "di-value di-muted";
    diCreated.textContent = "";
    return;
  }

  diAge.textContent = formatDomainAge(info.ageYears);
  diAge.className = "di-value" + (info.ageYears === null || info.ageYears === undefined ? " di-muted" : "");

  if (info.isHttps) {
    diHttps.textContent = "Secure";
    diHttps.className = "di-value di-secure";
  } else {
    diHttps.textContent = "Not Secure";
    diHttps.className = "di-value di-insecure";
  }

  if (info.isHttps && info.certificateValid !== false) {
    diCert.textContent = "Valid";
    diCert.className = "di-value di-secure";
  } else if (info.isHttps) {
    diCert.textContent = "Unverified";
    diCert.className = "di-value di-warn";
  } else {
    diCert.textContent = "N/A";
    diCert.className = "di-value di-muted";
  }

  diCreated.textContent = formatCreatedDate(info.createdDate);
  if (!info.createdDate) {
    diCreated.textContent = "Live lookup failed \u2014 click \u21BB to retry";
  }
}

function renderResult(data) {
  if (!data || typeof data.score === "undefined") {
    loadingEl.classList.add("hidden");
    errorEl.classList.remove("hidden");
    errorEl.textContent = "Unable to analyze this page";
    return;
  }

  loadingEl.classList.add("hidden");
  resultEl.classList.remove("hidden");

  animateScore(data.score);
  setRing(data.score);

  levelBadge.textContent = data.level;
  levelBadge.className = "level-badge " + getBadgeClass(data.level);

  if (data.phishingAnalysis) {
    renderPhishingPanel(data.phishingAnalysis);
  } else {
    phishingPanel.classList.add("hidden");
  }

  reasonsEl.innerHTML = "<h3>Reputation Breakdown</h3>";
  data.reasons.forEach((check) => {
    const div = document.createElement("div");
    div.className = "reason-item " + (check.passed ? "passed" : "failed");

    const icon = document.createElement("span");
    icon.className = "check-icon";
    icon.textContent = check.passed ? "\u2713" : "\u2717";

    const text = document.createElement("span");
    text.textContent = check.text;

    div.appendChild(icon);
    div.appendChild(text);
    reasonsEl.appendChild(div);
  });
}

function applyTheme(theme) {
  currentTheme = theme;
  document.documentElement.setAttribute("data-theme", theme);
  themeToggle.innerHTML = theme === "dark" ? "&#9789;" : "&#9788;";
  chrome.storage.local.set({ theme });
}

async function loadSettings() {
  try {
    const settings = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
    if (!settings) return;
    currentBlocked = settings.blockedDomains || [];
    currentSafe = settings.safeDomains || [];
    renderTags(blockedTags, currentBlocked, "blocked");
    renderTags(safeTags, currentSafe, "safe");

    blockingToggle.checked = settings.blockingEnabled !== false;
    notificationsToggle.checked = settings.notificationsEnabled !== false;
    phishingToggle.checked = settings.phishingEnabled !== false;
    adBlockerToggle.checked = settings.adBlockerEnabled !== false;
    mailGuardToggle.checked = settings.mailGuardEnabled !== false;
    updateAdBlockerBtn(settings.adBlockerEnabled !== false);

    if (settings.theme) {
      applyTheme(settings.theme);
    }
  } catch (e) {
    // Settings load failed, use defaults
  }
}

async function init() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) {
      throw new Error("No active tab found");
    }

    const url = new URL(tab.url);
    urlDisplay.textContent = url.href;
    currentUrl = tab.url;

    const lockEl = document.getElementById("urlLock");
    if (lockEl) {
      if (url.protocol === "https:") {
        lockEl.textContent = "\u{1F512}";
        lockEl.className = "url-lock secure";
      } else if (url.protocol === "http:") {
        lockEl.textContent = "\u{1F513}";
        lockEl.className = "url-lock insecure";
      }
    }

    if (url.protocol !== "http:" && url.protocol !== "https:") {
      throw new Error("No website is open. Open a web page to see its safety score.");
    }

    let contentAnalysis;
    try {
      const page = await chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_ANALYSIS" });
      contentAnalysis = page && page.contentAnalysis;
    } catch (e) {
      contentAnalysis = undefined;
    }

    const response = await chrome.runtime.sendMessage({
      type: "ANALYZE_URL",
      url: tab.url,
      contentAnalysis,
    });

    if (!response) {
      throw new Error("No response from analysis");
    }

    renderResult(response);
    await loadSettings();
    loadDomainInfo();
  } catch (err) {
    loadingEl.classList.add("hidden");
    errorEl.classList.remove("hidden");
    errorEl.textContent = err.message || "Unable to analyze this page";
  }
}

settingsBtn.addEventListener("click", () => {
  showingSettings = !showingSettings;
  settingsPanel.classList.toggle("hidden", !showingSettings);
  resultEl.classList.toggle("hidden", showingSettings);
  if (showingSettings) {
    errorEl.classList.add("hidden");
    loadingEl.classList.add("hidden");
  }
});

themeToggle.addEventListener("click", () => {
  applyTheme(currentTheme === "dark" ? "light" : "dark");
});

diRefresh.addEventListener("click", () => {
  loadDomainInfo(true);
});

function sanitizeDomain(value) {
  let v = String(value || "").trim().toLowerCase();
  if (!v) return "";
  try {
    v = new URL(v.includes("://") ? v : "http://" + v).hostname;
  } catch (e) {}
  v = v.replace(/^\.+|\.+$/g, "");
  if (!v || v.includes(" ") || !v.includes(".")) return "";
  return v;
}

function addDomainToList(list, input, tagsContainer, type) {
  const val = sanitizeDomain(input.value);
  if (val && !list.includes(val)) {
    list.push(val);
    renderTags(tagsContainer, list, type);
    input.value = "";
  }
}

addBlockedBtn.addEventListener("click", () => {
  addDomainToList(currentBlocked, blockedInput, blockedTags, "blocked");
});

addSafeBtn.addEventListener("click", () => {
  addDomainToList(currentSafe, safeInput, safeTags, "safe");
});

blockedInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addBlockedBtn.click();
});

safeInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addSafeBtn.click();
});

saveSettingsBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({
    type: "SAVE_SETTINGS",
    blockedDomains: currentBlocked,
    safeDomains: currentSafe,
    blockingEnabled: blockingToggle.checked,
    notificationsEnabled: notificationsToggle.checked,
    phishingEnabled: phishingToggle.checked,
    adBlockerEnabled: adBlockerToggle.checked,
    mailGuardEnabled: mailGuardToggle.checked,
    theme: currentTheme
  });
  saveMsg.classList.remove("hidden");
  setTimeout(() => saveMsg.classList.add("hidden"), 1500);
});

reportBtn.addEventListener("click", () => {
  reportForm.classList.toggle("hidden");
  if (!reportForm.classList.contains("hidden")) {
    if (currentPhishingAnalysis) {
      const catMap = {
        CREDENTIAL_HARVESTING: "credential",
        FINANCIAL_FRAUD: "financial",
        TECH_SUPPORT_SCAM: "techsupport",
        PRIZE_LOTTERY: "prize",
        SOCIAL_PHISHING: "social",
        BRAND_IMPERSONATION: "brand"
      };
      const val = catMap[currentPhishingAnalysis.category.key] || "";
      if (val) reportType.value = val;
    }
  }
});

submitReport.addEventListener("click", async () => {
  const type = reportType.value;
  if (!type) {
    reportType.style.borderColor = "var(--red)";
    return;
  }
  reportType.style.borderColor = "";

  const report = {
    url: currentUrl,
    type: type,
    notes: reportNotes.value.trim(),
    confidence: currentPhishingAnalysis ? currentPhishingAnalysis.confidence : 0,
    category: currentPhishingAnalysis ? currentPhishingAnalysis.category.key : "UNKNOWN",
    timestamp: Date.now()
  };

  const reports = await chrome.storage.local.get(["phishingReports"]);
  const existingReports = reports.phishingReports || [];
  existingReports.push(report);
  await chrome.storage.local.set({ phishingReports: existingReports });

  reportForm.classList.add("hidden");
  reportSuccess.classList.remove("hidden");
  reportType.value = "";
  reportNotes.value = "";
  setTimeout(() => {
    reportSuccess.classList.add("hidden");
    reportBtn.classList.add("hidden");
  }, 2000);
});

function updateAdBlockerBtn(enabled) {
  if (enabled) {
    adBlockerBtn.classList.add("active");
    adBlockerLabel.textContent = "Ad Blocker: ON";
  } else {
    adBlockerBtn.classList.remove("active");
    adBlockerLabel.textContent = "Ad Blocker: OFF";
  }
}

adBlockerBtn.addEventListener("click", async () => {
  const settings = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
  const newVal = settings.adBlockerEnabled === false;
  adBlockerToggle.checked = newVal;
  updateAdBlockerBtn(newVal);
  await chrome.runtime.sendMessage({
    type: "SAVE_SETTINGS",
    blockedDomains: currentBlocked,
    safeDomains: currentSafe,
    blockingEnabled: blockingToggle.checked,
    notificationsEnabled: notificationsToggle.checked,
    phishingEnabled: phishingToggle.checked,
    adBlockerEnabled: newVal,
    mailGuardEnabled: mailGuardToggle.checked,
    theme: currentTheme
  });
});

const toolsBtn = document.getElementById("toolsBtn");
const toolsDropdown = document.getElementById("toolsDropdown");

function positionToolsDropdown() {
  const btnRect = toolsBtn.getBoundingClientRect();
  const spaceAbove = btnRect.top;
  const spaceBelow = window.innerHeight - btnRect.bottom;

  if (spaceAbove >= spaceBelow && spaceAbove > 100) {
    toolsDropdown.style.top = "auto";
    toolsDropdown.style.bottom = "calc(100% + 6px)";
  } else {
    toolsDropdown.style.top = "calc(100% + 6px)";
    toolsDropdown.style.bottom = "auto";
  }

  const available = Math.max(spaceAbove, spaceBelow) - 12;
  toolsDropdown.style.maxHeight = Math.max(80, available) + "px";
}

toolsBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  const isOpen = !toolsDropdown.classList.contains("hidden");
  if (!isOpen) positionToolsDropdown();
  toolsDropdown.classList.toggle("hidden", isOpen);
  toolsBtn.classList.toggle("open", !isOpen);
});

document.addEventListener("click", (e) => {
  const footerTools = document.getElementById("footerTools");
  if (footerTools && !footerTools.contains(e.target)) {
    toolsDropdown.classList.add("hidden");
    toolsBtn.classList.remove("open");
  }
});

toolsDropdown.addEventListener("click", (e) => {
  e.stopPropagation();
});

init();
