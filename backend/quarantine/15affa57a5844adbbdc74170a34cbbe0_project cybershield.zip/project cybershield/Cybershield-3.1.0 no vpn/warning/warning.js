const urlDisplay = document.getElementById("urlDisplay");
const scoreValue = document.getElementById("scoreValue");
const scoreCircle = document.getElementById("scoreCircle");
const levelBadge = document.getElementById("levelBadge");
const reasonsSection = document.getElementById("reasonsSection");
const proceedBtn = document.getElementById("proceedBtn");
const goBackBtn = document.getElementById("goBackBtn");
const warningIcon = document.getElementById("warningIcon");
const warningTitle = document.getElementById("warningTitle");
const phishingSection = document.getElementById("phishingSection");
const phishingBadgeIcon = document.getElementById("phishingBadgeIcon");
const phishingBadgeTitle = document.getElementById("phishingBadgeTitle");
const phishingConfFill = document.getElementById("phishingConfFill");
const phishingConfVal = document.getElementById("phishingConfVal");
const phishingCategoryLabel = document.getElementById("phishingCategoryLabel");
const phishingSummaryText = document.getElementById("phishingSummaryText");
const phishingIndicatorsList = document.getElementById("phishingIndicatorsList");

function getBadgeClass(level) {
  if (level === "Safe") return "safe";
  if (level === "Moderate Risk") return "moderate";
  if (level === "Blocked") return "blocked";
  return "";
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[c]));
}

function getScoreColor(score) {
  if (score >= 80) return "#3fb950";
  if (score >= 50) return "#d29922";
  return "#f85149";
}

function getConfidenceColor(confidence) {
  if (confidence >= 70) return "#f85149";
  if (confidence >= 50) return "#d29922";
  if (confidence >= 30) return "#e3b341";
  return "#3fb950";
}

function renderPhishingSection(phishingAnalysis) {
  if (!phishingAnalysis || phishingAnalysis.confidence < 15) {
    phishingSection.classList.add("hidden");
    return;
  }

  phishingSection.classList.remove("hidden");

  phishingBadgeIcon.textContent = phishingAnalysis.category.icon;

  let title = "Phishing Detected";
  let titleColor = "#e3b341";
  if (phishingAnalysis.riskLevel === "critical") {
    title = "Critical Phishing Threat";
    titleColor = "#ff4444";
    warningIcon.textContent = "\uD83D\uDEA8";
    warningTitle.textContent = "Critical: Phishing Site Detected";
  } else if (phishingAnalysis.riskLevel === "high") {
    title = "High Phishing Risk";
    titleColor = "#f85149";
    warningIcon.textContent = "\u26A0\uFE0F";
    warningTitle.textContent = "Warning: High Phishing Risk";
  } else if (phishingAnalysis.riskLevel === "medium") {
    title = "Suspicious Activity Detected";
    titleColor = "#d29922";
  } else {
    title = "Minor Indicators Found";
    titleColor = "#e3b341";
  }

  phishingBadgeTitle.textContent = title;
  phishingBadgeTitle.style.color = titleColor;

  const confColor = getConfidenceColor(phishingAnalysis.confidence);
  phishingConfFill.style.width = phishingAnalysis.confidence + "%";
  phishingConfFill.style.background = confColor;
  phishingConfVal.textContent = phishingAnalysis.confidence + "%";
  phishingConfVal.style.color = confColor;

  phishingCategoryLabel.innerHTML = `
    <span class="cat-badge">${escapeHtml(phishingAnalysis.category.name)}</span>
    <span class="cat-desc">${escapeHtml(phishingAnalysis.category.description)}</span>
  `;

  phishingSummaryText.textContent = phishingAnalysis.summary;

  phishingIndicatorsList.innerHTML = "";
  const topIndicators = phishingAnalysis.indicators.slice(0, 6);
  topIndicators.forEach(ind => {
    const div = document.createElement("div");
    div.className = "ind-item";

    let dotColor;
    if (ind.severity === "high") dotColor = "#f85149";
    else if (ind.severity === "medium") dotColor = "#d29922";
    else dotColor = "#8b949e";

    div.innerHTML = `
      <span class="ind-dot" style="background:${dotColor};"></span>
      <span class="ind-text">${escapeHtml(ind.text)}</span>
    `;
    phishingIndicatorsList.appendChild(div);
  });

  if (phishingAnalysis.indicators.length > 6) {
    const more = document.createElement("div");
    more.className = "ind-more";
    more.textContent = `+${phishingAnalysis.indicators.length - 6} more indicators`;
    phishingIndicatorsList.appendChild(more);
  }
}

function animateValue(el, target, duration = 700) {
  const startTime = performance.now();
  const tick = (now) => {
    const p = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(target * eased);
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function renderWarning(data) {
  urlDisplay.textContent = data.url;

  animateValue(scoreValue, data.score);
  const color = getScoreColor(data.score);
  scoreCircle.style.borderColor = color;
  scoreCircle.style.background = `${color}1a`;
  scoreValue.style.color = color;
  scoreCircle.style.boxShadow = `0 0 36px ${color}44, inset 0 0 18px ${color}1a`;

  const isBlocked = data.level === "Blocked";
  if (isBlocked) {
    warningIcon.textContent = "\uD83D\uDEAB";
    warningTitle.textContent = "This Website Has Been Blocked";
    levelBadge.textContent = "Blocked";
    levelBadge.className = "level-badge blocked";
  } else {
    levelBadge.textContent = data.level;
    levelBadge.className = "level-badge " + getBadgeClass(data.level);
  }

  if (data.phishingAnalysis) {
    renderPhishingSection(data.phishingAnalysis);
  } else {
    phishingSection.classList.add("hidden");
  }

  let html = "<h3>Security Analysis</h3>";
  (data.reasons || []).forEach((check) => {
    html += `
      <div class="reason-item ${check.passed ? "passed" : "failed"}">
        <span class="check-icon">${check.passed ? "\u2713" : "\u2717"}</span>
        <span>${escapeHtml(check.text)}</span>
      </div>
    `;
  });
  if (!data.reasons || data.reasons.length === 0) {
    html += `<div class="reason-item failed"><span>No analysis details available.</span></div>`;
  }
  reasonsSection.innerHTML = html;
}

async function init() {
  const params = new URLSearchParams(window.location.search);
  const dataParam = params.get("data");

  if (!dataParam) {
    urlDisplay.textContent = "Unknown URL";
    return;
  }

  try {
    const data = JSON.parse(decodeURIComponent(dataParam));
    renderWarning(data);
  } catch (e) {
    urlDisplay.textContent = "Unable to load warning data";
  }
}

proceedBtn.addEventListener("click", () => {
  const params = new URLSearchParams(window.location.search);
  const dataParam = params.get("data");
  if (dataParam) {
    try {
      const data = JSON.parse(decodeURIComponent(dataParam));
      let targetUrl = null;
      try {
        const parsed = new URL(data.url);
        if (parsed.protocol === "http:" || parsed.protocol === "https:") {
          targetUrl = parsed.href;
        }
      } catch (e) {}

      if (!targetUrl) {
        window.history.back();
        return;
      }

      try {
        const parsed = new URL(targetUrl);
        parsed.searchParams.set("_cybershield_bypass", "1");
        targetUrl = parsed.toString();
      } catch (e) {}

      let navigated = false;
      const doNavigate = () => {
        if (navigated) return;
        navigated = true;
        window.location.href = targetUrl;
      };
      try {
        chrome.runtime.sendMessage({ type: "BYPASS_URL", url: targetUrl }, () => {
          doNavigate();
        });
      } catch (e) {
        doNavigate();
      }
      setTimeout(doNavigate, 1000);
    } catch (e) {
      window.history.back();
    }
  }
});

goBackBtn.addEventListener("click", () => {
  if (window.history.length > 1) {
    window.history.back();
  } else {
    window.location.href = "about:blank";
  }
});

init();
