"use strict";

// Proton VPN integration via the CyberShield native messaging host.
//
// The host (native/protonvpn-host.ps1, registered by native/install-host.bat)
// launches the official Proton VPN desktop application on Windows and reports
// the REAL tunnel state by checking the Windows tunnel adapter that Proton's
// own driver creates. No Proton credentials, tokens or private data are ever
// read, stored or transmitted; the Proton app handles its own authentication.
//
// Status is only ever derived from the host's verified report - CyberShield
// never guesses or fakes a connection state. Requests are serialized through a
// FIFO queue because the native host processes one message at a time; a status
// probe that arrives while a connect/disconnect action is in flight simply
// waits its turn instead of timing out and reporting a bogus failure.
// If no fresh reading can be obtained, the last VERIFIED state is returned
// flagged as `stale` so the UI never loses the real connected/disconnected
// state just because a probe was interrupted.

const PROTON_VPN_HOST_NAME = "com.cybershield.protonvpn";
const PROTON_VPN_STATUS_TIMEOUT_MS = 15000;
const PROTON_VPN_ACTION_TIMEOUT_MS = 80000;
const PROTON_VPN_DOWNLOAD_URL = "https://protonvpn.com/download";
const VPN_STALE_MAX_AGE_MS = 30000;

let vpnPort = null;
let vpnSeq = 0;
const vpnPending = new Map();
const vpnQueue = [];
let vpnDispatching = false;
let vpnLastHostError = null;
let vpnLastHostErrorMessage = null;
let vpnLastVerified = null;
let vpnLastVerifiedAt = 0;

function vpnPortErrorKind(message) {
  if (!message) return "error";
  if (/not found|forbidden|access|missing/i.test(message)) {
    return "host_missing";
  }
  return "error";
}

function vpnOnNativeMessage(msg) {
  if (!msg || typeof msg !== "object" || !vpnPending.has(msg.seq)) {
    console.warn("[CyberShield] vpnOnNativeMessage: received msg but no pending handler for seq=" + (msg && msg.seq), msg);
    return;
  }
  const pending = vpnPending.get(msg.seq);
  vpnPending.delete(msg.seq);
  clearTimeout(pending.timer);
  console.log("[CyberShield] vpnOnNativeMessage: resolving seq=" + msg.seq);
  pending.resolve(msg);
}

function vpnOnNativeDisconnect() {
  const err = chrome.runtime.lastError && chrome.runtime.lastError.message;
  console.error("[CyberShield] vpnOnNativeDisconnect: port disconnected, error=" + (err || "none"));
  vpnLastHostError = vpnPortErrorKind(err);
  vpnLastHostErrorMessage = err || null;
  vpnPort = null;
  const pendingItems = [...vpnPending.values()];
  vpnPending.clear();
  for (const pending of pendingItems) {
    clearTimeout(pending.timer);
    pending.reject(new Error(vpnLastHostError === "host_missing" ? "host_missing" : "port_failed"));
  }
}

function vpnEnsurePort() {
  if (vpnPort) return vpnPort;
  try {
    console.log("[CyberShield] vpnEnsurePort: connecting to native host:", PROTON_VPN_HOST_NAME);
    vpnPort = chrome.runtime.connectNative(PROTON_VPN_HOST_NAME);
    vpnPort.onMessage.addListener(vpnOnNativeMessage);
    vpnPort.onDisconnect.addListener(vpnOnNativeDisconnect);
    vpnLastHostError = null;
    vpnLastHostErrorMessage = null;
    console.log("[CyberShield] vpnEnsurePort: native port connected successfully");
  } catch (e) {
    console.error("[CyberShield] vpnEnsurePort: connectNative failed:", e && e.message ? e.message : e);
    vpnLastHostError = "host_missing";
    vpnLastHostErrorMessage = (e && e.message) || "host not found";
    vpnPort = null;
  }
  return vpnPort;
}

function vpnDispatchNext() {
  if (vpnDispatching) return;
  const item = vpnQueue.shift();
  if (!item) return;

  vpnDispatching = true;
  const finish = () => {
    vpnDispatching = false;
    vpnDispatchNext();
  };

  const port = vpnEnsurePort();
  if (!port || vpnLastHostError === "host_missing") {
    console.error("[CyberShield] vpnDispatchNext: no port available, rejecting with host_missing");
    item.reject(new Error("host_missing"));
    finish();
    return;
  }

  const seq = ++vpnSeq;
  console.log("[CyberShield] vpnDispatchNext: sending action=" + item.action + " seq=" + seq);
  const timer = setTimeout(() => {
    vpnPending.delete(seq);
    console.warn("[CyberShield] vpnDispatchNext: timeout for action=" + item.action + " seq=" + seq);
    item.reject(new Error("timeout"));
    finish();
  }, item.timeoutMs);

  vpnPending.set(seq, {
    resolve: (msg) => {
      console.log("[CyberShield] vpnDispatchNext: resolved action=" + item.action + " seq=" + seq);
      item.resolve(msg);
      finish();
    },
    reject: (err) => {
      console.error("[CyberShield] vpnDispatchNext: rejected action=" + item.action + " seq=" + seq + " err=" + (err && err.message ? err.message : err));
      item.reject(err);
      finish();
    },
    timer
  });

  try {
    port.postMessage({ action: item.action, seq });
  } catch (e) {
    console.error("[CyberShield] vpnDispatchNext: postMessage failed:", e && e.message ? e.message : e);
    clearTimeout(timer);
    vpnPending.delete(seq);
    item.reject(new Error("port_failed"));
    finish();
  }
}

function vpnRequest(action, timeoutMs) {
  return new Promise((resolve, reject) => {
    vpnQueue.push({ action, timeoutMs, resolve, reject });
    vpnDispatchNext();
  });
}

function vpnHostUnavailable(reason) {
  return {
    ok: false,
    state: "unavailable",
    reason: reason === "host_missing" ? "host_missing" : "error",
    hostAvailable: false,
    installed: null,
    connected: null,
    hostError: vpnLastHostErrorMessage || null,
    message: vpnHostMessage(reason)
  };
}

function vpnHostMessage(reason) {
  if (reason === "host_missing") {
    return "Chrome could not find the CyberShield helper. Run native\\install-host.bat once, restart Chrome, then remove and reload CyberShield (ID: oaokfdekbpkicbmdildlhooihfiddhhl).";
  }
  if (reason === "timeout") {
    return "Proton VPN did not respond in time. The status will refresh automatically.";
  }
  return "Could not reach the Proton VPN helper.";
}

function vpnNormalizeHostStatus(res) {
  if (!res || typeof res !== "object" || typeof res.connected !== "boolean") {
    return { ok: false, state: "unknown", reason: "error", hostAvailable: true, installed: null, connected: null, message: "Proton VPN returned an unexpected response." };
  }
  if (res.installed === false) {
    return {
      ok: true,
      state: "unavailable",
      reason: "app_missing",
      hostAvailable: true,
      installed: false,
      connected: false,
      message: "Proton VPN desktop app is not installed.",
      installUrl: PROTON_VPN_DOWNLOAD_URL
    };
  }
  if (res.connected === true) {
    return { ok: true, state: "connected", reason: null, hostAvailable: true, installed: true, connected: true, message: null };
  }
  return { ok: true, state: "disconnected", reason: null, hostAvailable: true, installed: true, connected: false, message: null };
}

function vpnRememberVerified(status) {
  if (status && (status.state === "connected" || status.state === "disconnected")) {
    vpnLastVerified = status;
    vpnLastVerifiedAt = Date.now();
  }
}

function vpnStaleFallback() {
  if (vpnLastVerified && (Date.now() - vpnLastVerifiedAt) < VPN_STALE_MAX_AGE_MS) {
    return { ...vpnLastVerified, stale: true, message: "Last known state (refreshing\u2026)" };
  }
  return { ok: false, state: "unknown", reason: "error", hostAvailable: true, installed: null, connected: null, message: "Proton VPN did not respond in time. The status will refresh automatically." };
}

async function vpnGetStatus(options) {
  const allowStale = !options || options.allowStale !== false;
  let res;
  try {
    res = await vpnRequest("status", PROTON_VPN_STATUS_TIMEOUT_MS);
  } catch (e) {
    if (e.message === "host_missing") {
      return vpnHostUnavailable("host_missing");
    }
    if (allowStale) {
      return vpnStaleFallback();
    }
    return { ok: false, state: "unknown", reason: "error", hostAvailable: true, installed: null, connected: null, message: "Proton VPN did not respond in time." };
  }
  const status = vpnNormalizeHostStatus(res);
  vpnRememberVerified(status);
  return status;
}

async function vpnConfirmState() {
  try {
    return await vpnGetStatus({ allowStale: false });
  } catch (e) {
    return { ok: false, state: "unknown", reason: "error", hostAvailable: true, installed: null, connected: null, message: "Could not confirm Proton VPN state." };
  }
}

async function vpnRunAction(action) {
  let res;
  try {
    res = await vpnRequest(action === "disconnect" ? "disconnect" : "connect", PROTON_VPN_ACTION_TIMEOUT_MS);
  } catch (e) {
    if (e.message === "host_missing") {
      return vpnHostUnavailable("host_missing");
    }
    return {
      ok: false,
      state: "unknown",
      reason: "timeout",
      hostAvailable: true,
      installed: null,
      connected: null,
      message: "The connection operation did not finish in time. Check the Proton VPN window."
    };
  }

  if (!res || typeof res !== "object" || res.success !== true) {
    const errText = res && res.error ? String(res.error) : "unknown error";
    return {
      ok: false,
      state: action === "disconnect" ? "connected" : "disconnected",
      reason: "action_failed",
      hostAvailable: true,
      installed: res && res.installed === false ? false : true,
      connected: res ? res.connected === true : null,
      message: action === "disconnect"
        ? "Disconnect failed" + (errText ? ": " + errText : "") + "."
        : "Connect failed" + (errText ? ": " + errText : "") + "."
    };
  }

  const confirmed = await vpnConfirmState();
  vpnRememberVerified(confirmed);

  if (action === "connect") {
    if (confirmed.state === "connected") {
      return { ...confirmed, message: null };
    }
    return {
      ...confirmed,
      ok: false,
      reason: "timeout",
      message: "Connection not confirmed yet - check the Proton VPN window. Tip: enable Auto Connect in the Proton VPN app for one-click connection."
    };
  }

  if (confirmed.state === "disconnected") {
    return { ...confirmed, message: null };
  }
  return {
    ...confirmed,
    ok: false,
    reason: "action_failed",
    message: "Proton VPN is still connected. Please disconnect it from the app."
  };
}