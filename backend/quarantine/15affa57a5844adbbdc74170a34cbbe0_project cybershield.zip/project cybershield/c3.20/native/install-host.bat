@echo off
setlocal
title CyberShield - Install Proton VPN launcher host
echo ============================================================
echo  CyberShield - Proton VPN native messaging host installer
echo ============================================================
echo.
echo This installs a small helper that lets the CyberShield
echo extension start Proton VPN and auto-connect to a server.
echo It also generates a stable extension key (no ID needed).
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-host.ps1"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo Installed successfully. Restart the browser, then reload
  echo the CyberShield extension (remove it, then Load unpacked).
  echo For best results, enable "Auto connect" in Proton VPN settings.
) else (
  echo Setup FAILED. See messages above.
)
echo.
pause
exit /b %RC%
