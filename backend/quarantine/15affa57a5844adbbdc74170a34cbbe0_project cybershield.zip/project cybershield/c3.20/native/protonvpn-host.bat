@echo off
rem CyberShield - Proton VPN native messaging host wrapper
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0protonvpn-host.ps1"
