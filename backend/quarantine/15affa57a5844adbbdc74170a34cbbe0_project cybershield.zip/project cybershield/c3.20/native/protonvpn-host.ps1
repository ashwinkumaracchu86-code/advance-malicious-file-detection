# CyberShield - Proton VPN native messaging host
# connect:    opens the Proton VPN app and connects it to a server automatically
# disconnect: opens the app, tears down the tunnel (elevated helper), leaves the app showing Disconnected
# status:     reports installed / connected (tunnel adapter) / window / running
# Protocol: length-prefixed JSON messages on stdin/stdout (Chrome native messaging).
$ErrorActionPreference = 'SilentlyContinue'

$stdin = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()

# Cache of the resolved Proton launch path. Resolving it is expensive (disk
# scans / registry walks), so a successful resolve is trusted for up to 24h
# (re-validated with a cheap Test-Path on every use), and a failed resolve is
# only retried every 5 minutes.
$script:launchPathCache = $null
$script:launchPathMissUntil = [DateTime]::MinValue
$script:launchPathMissTtl = [TimeSpan]::FromMinutes(5)

function Read-NativeMessage {
    $header = New-Object byte[] 4
    $offset = 0
    while ($offset -lt 4) {
        $n = $stdin.Read($header, $offset, 4 - $offset)
        if ($n -le 0) { return $null }
        $offset += $n
    }
    $length = [BitConverter]::ToUInt32($header, 0)
    $body = New-Object byte[] $length
    $offset = 0
    while ($offset -lt $length) {
        $n = $stdin.Read($body, $offset, $length - $offset)
        if ($n -le 0) { return $null }
        $offset += $n
    }
    return [System.Text.Encoding]::UTF8.GetString($body)
}

function Write-NativeMessage([string]$text) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
    $header = [BitConverter]::GetBytes([uint32]$bytes.Length)
    $stdout.Write($header, 0, 4)
    $stdout.Write($bytes, 0, $bytes.Length)
    $stdout.Flush()
}

function Test-ProtonExe([string]$path) {
    return (-not [string]::IsNullOrWhiteSpace($path)) -and (Test-Path -LiteralPath $path -PathType Leaf)
}

function Find-ProtonClientInRoot([string]$root) {
    if ([string]::IsNullOrWhiteSpace($root)) { return $null }
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { return $null }
    $client = Get-ChildItem -LiteralPath $root -Recurse -Depth 3 -Filter 'ProtonVPN.Client.exe' -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1
    if ($client) { return $client.FullName }
    $legacy = Get-ChildItem -LiteralPath $root -Recurse -Depth 2 -Include 'ProtonVPN.Launcher.exe', 'ProtonVPN.exe' -File -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($legacy) { return $legacy.FullName }
    return $null
}

function Get-ProtonClientPath {
    # 1. Exact paths (per-machine and per-user installs).
    $fast = @(
        (Join-Path $env:ProgramFiles 'Proton\VPN\ProtonVPN.Client.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Proton\VPN\ProtonVPN.Client.exe'),
        (Join-Path $env:ProgramFiles 'ProtonVPN\ProtonVPN.Client.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'ProtonVPN\ProtonVPN.Client.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Proton\VPN\ProtonVPN.Client.exe'),
        (Join-Path $env:LOCALAPPDATA 'Proton\VPN\ProtonVPN.Client.exe'),
        (Join-Path $env:LOCALAPPDATA 'Proton\ProtonVPN.Client.exe')
    )
    foreach ($p in $fast) {
        if (Test-ProtonExe $p) { return $p }
    }

    # 2. Known install roots: shallow scan only (versioned subfolders like
    #    v5.1.6 live at depth 1-3, no need to crawl the whole Program Files).
    $roots = @(
        (Join-Path $env:ProgramFiles 'Proton'),
        (Join-Path ${env:ProgramFiles(x86)} 'Proton'),
        (Join-Path $env:ProgramFiles 'ProtonVPN'),
        (Join-Path ${env:ProgramFiles(x86)} 'ProtonVPN'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Proton'),
        (Join-Path $env:LOCALAPPDATA 'Proton')
    )
    foreach ($root in $roots) {
        $found = Find-ProtonClientInRoot $root
        if ($found) { return $found }
    }

    # 3. Registry uninstall entries (last resort for non-standard installs).
    $regRoots = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($regRoot in $regRoots) {
        $apps = Get-ItemProperty -Path $regRoot -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like '*Proton VPN*' -or $_.DisplayName -like '*ProtonVPN*' }
        foreach ($app in $apps) {
            if (-not $app.InstallLocation) { continue }
            $found = Find-ProtonClientInRoot $app.InstallLocation
            if ($found) { return $found }
        }
    }
    return $null
}

function Get-ProtonLaunchPath {
    if ($script:launchPathCache) {
        if (Test-ProtonExe $script:launchPathCache) { return $script:launchPathCache }
        $script:launchPathCache = $null
    }
    $now = Get-Date
    if ($now -lt $script:launchPathMissUntil) { return $null }
    $path = Get-ProtonClientPath
    if ($path) {
        $script:launchPathCache = $path
        return $path
    }
    $script:launchPathMissUntil = $now.Add($script:launchPathMissTtl)
    return $null
}

Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class CybProtonWin {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  public static void UnlockForeground() {
    keybd_event(0x12, 0, 0, UIntPtr.Zero);       // ALT down
    keybd_event(0x12, 0, 2, UIntPtr.Zero);       // ALT up
  }
}
"@

function Get-ProtonProcess {
    return (Get-Process -Name 'ProtonVPN.Client' -ErrorAction SilentlyContinue | Select-Object -First 1)
}

function Get-ProtonMainWindow {
    $client = Get-ProtonProcess
    if (-not $client) { return $null }
    $script:targetPid = [uint32]$client.Id
    $script:foundHwnd = $null
    $cb = {
        param($hWnd, $lParam)
        $pidOut = 0
        [CybProtonWin]::GetWindowThreadProcessId($hWnd, [ref]$pidOut) | Out-Null
        if ([int]$pidOut -ne $script:targetPid) { return $true }
        $sb = New-Object System.Text.StringBuilder 256
        [CybProtonWin]::GetWindowText($hWnd, $sb, 256) | Out-Null
        if ($sb.ToString() -like 'Proton VPN*') {
            $script:foundHwnd = $hWnd
            return $false
        }
        return $true
    }
    $delegate = [CybProtonWin+EnumWindowsProc]$cb
    [CybProtonWin]::EnumWindows($delegate, [IntPtr]::Zero) | Out-Null
    return $script:foundHwnd
}

function Show-ProtonWindow {
    $hwnd = Get-ProtonMainWindow
    if (-not $hwnd) { return $false }
    [CybProtonWin]::ShowWindow($hwnd, 9) | Out-Null
    [CybProtonWin]::UnlockForeground()
    Start-Sleep -Milliseconds 150
    [CybProtonWin]::SetForegroundWindow($hwnd) | Out-Null
    [CybProtonWin]::BringWindowToTop($hwnd) | Out-Null
    Start-Sleep -Milliseconds 200
    return ([CybProtonWin]::IsWindowVisible($hwnd))
}

function Click-ScreenAt([double]$x, [double]$y) {
    [CybProtonWin]::SetCursorPos([int]$x, [int]$y) | Out-Null
    Start-Sleep -Milliseconds 80
    [CybProtonWin]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero) | Out-Null  # left down
    Start-Sleep -Milliseconds 60
    [CybProtonWin]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero) | Out-Null  # left up
}

function Invoke-ProtonUiButtonClick([string]$name, [int]$attempts = 4) {
    # Clicks a button in the Proton VPN window (e.g. "Connect" / "Disconnect").
    # Tries UI Automation Invoke first, then falls back to a real mouse click.
    $hwnd = Get-ProtonMainWindow
    if (-not $hwnd) { return $false }
    try {
        Add-Type -AssemblyName UIAutomationClient -ErrorAction Stop
        Add-Type -AssemblyName UIAutomationTypes -ErrorAction Stop
    } catch {
        return $false
    }
    $win = [System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
    if (-not $win) { return $false }
    for ($i = 0; $i -lt $attempts; $i++) {
        try {
            $btnCond = New-Object System.Windows.Automation.AndCondition(
                (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)),
                (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty, $name)))
            $buttons = $win.FindAll([System.Windows.Automation.TreeScope]::Descendants, $btnCond)
            foreach ($btn in $buttons) {
                if ($btn.Current.IsOffscreen) { continue }
                try {
                    $invoke = $btn.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
                    if ($invoke) {
                        $invoke.Invoke()
                        return $true
                    }
                } catch { }
            }
            foreach ($btn in $buttons) {
                if ($btn.Current.IsOffscreen) { continue }
                $rect = $btn.Current.BoundingRectangle
                if ($rect.Width -gt 0 -and $rect.Height -gt 0) {
                    Show-ProtonWindow | Out-Null
                    Click-ScreenAt ($rect.Left + $rect.Width / 2) ($rect.Top + $rect.Height / 2)
                    return $true
                }
            }
        } catch { }
        Start-Sleep -Milliseconds 600
    }
    return $false
}

function Test-ProtonConnected {
    $tun = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'ProTUN|Proton|TAP|WireGuard' -and $_.Status -eq 'Up' }
    return [bool]$tun
}

function Wait-ProtonConnected([int]$timeoutSec) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)
    while ((Get-Date) -lt $deadline) {
        if (Test-ProtonConnected) { return $true }
        Start-Sleep -Milliseconds 1000
    }
    return (Test-ProtonConnected)
}

function Wait-ProtonWindow([int]$timeoutSec) {
    $deadline = (Get-Date).AddSeconds($timeoutSec)
    while ((Get-Date) -lt $deadline) {
        $hwnd = Get-ProtonMainWindow
        if ($hwnd) { return $hwnd }
        Start-Sleep -Milliseconds 500
    }
    return $null
}

function Stop-ProtonClients {
    foreach ($name in @('ProtonVPN.Client', 'ProtonVPN')) {
        Get-Process -Name $name -ErrorAction SilentlyContinue | ForEach-Object {
            try { Stop-Process -Id $_.Id -Force -ErrorAction Stop } catch { }
        }
    }
}

function Invoke-ElevatedTeardown {
    # The tunnel is owned by ProtonVPNService (LocalSystem) and survives client death.
    # Tearing it down requires elevation, so run a helper via UAC.
    $helper = Join-Path $env:TEMP 'cybershield-vpn-teardown.ps1'
    @'
$ErrorActionPreference = 'SilentlyContinue'
Stop-Process -Name 'ProtonVPNService' -Force
Stop-Process -Name 'ProtonVPN.NrptWatchdog' -Force
Start-Sleep -Milliseconds 1500
Get-NetAdapter -Name 'ProTUN' | Disable-NetAdapter -Confirm:$false
Start-Sleep -Milliseconds 1000
$svc = Get-Service -Name 'ProtonVPN Service'
if ($svc -and $svc.Status -ne 'Running') { Start-Service -Name 'ProtonVPN Service' }
exit 0
'@ | Set-Content -LiteralPath $helper -Encoding UTF8
    try {
        $p = Start-Process -FilePath 'powershell.exe' -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$helper`"" -Verb RunAs -PassThru -Wait
        return ($p.ExitCode -eq 0)
    } catch {
        return $false
    }
}

function Start-ProtonApp {
    $launchPath = Get-ProtonLaunchPath
    if (-not $launchPath) { return $null }
    try {
        Start-Process -FilePath $launchPath | Out-Null
        return $launchPath
    } catch {
        return $null
    }
}

function Invoke-ProtonAction([string]$action) {
    $launchPath = Get-ProtonLaunchPath
    if (-not $launchPath) {
        return @{ success = $false; installed = $false; connected = $false; window = $false }
    }

    if ($action -eq 'connect') {
        $client = Get-ProtonProcess
        if (-not $client) {
            $started = Start-ProtonApp
            if (-not $started) {
                return @{ success = $false; installed = $true; connected = (Test-ProtonConnected); window = $false }
            }
        }
        $hwnd = Get-ProtonMainWindow
        if (-not $hwnd) {
            $hwnd = Wait-ProtonWindow 20
            if (-not $hwnd) {
                return @{ success = $true; installed = $true; connected = (Test-ProtonConnected); window = $false }
            }
        }
        Start-Sleep -Milliseconds 1000
        Show-ProtonWindow | Out-Null
        if (-not (Test-ProtonConnected)) {
            # Click the in-app Connect button so it actually connects (no Auto Connect needed).
            Invoke-ProtonUiButtonClick 'Connect' | Out-Null
        }
        $connected = Wait-ProtonConnected 40
        return @{ success = $true; installed = $true; connected = $connected; window = [bool]$hwnd }
    }

    if ($action -eq 'disconnect') {
        Show-ProtonWindow | Out-Null
        if (-not (Test-ProtonConnected)) {
            return @{ success = $true; installed = $true; connected = $false; window = [bool](Get-ProtonMainWindow) }
        }
        $clicked = Invoke-ProtonUiButtonClick 'Disconnect'
        if ($clicked) {
            $deadline = (Get-Date).AddSeconds(20)
            while ((Get-Date) -lt $deadline -and (Test-ProtonConnected)) {
                Start-Sleep -Milliseconds 1000
            }
            if (-not (Test-ProtonConnected)) {
                return @{ success = $true; installed = $true; connected = $false; window = [bool](Get-ProtonMainWindow) }
            }
        }
        # UIA click did not tear the tunnel down (button missing / renamed):
        # fall back to the legacy elevated teardown.
        $teardownOk = Invoke-ElevatedTeardown
        if (-not $teardownOk) {
            return @{ success = $false; installed = $true; connected = (Test-ProtonConnected); window = $true; error = 'elevation required or cancelled' }
        }
        return @{ success = $true; installed = $true; connected = $false; window = [bool](Get-ProtonMainWindow) }
    }

    return @{ success = $false; installed = $true; error = 'unknown action' }
}

function Get-ProtonState {
    $launchPath = Get-ProtonLaunchPath
    $installed = [bool]$launchPath
    $client = Get-ProtonProcess
    $window = $false
    if ($client) {
        $hwnd = Get-ProtonMainWindow
        $window = [bool]$hwnd
    }
    return @{
        success = $true
        installed = $installed
        connected = (Test-ProtonConnected)
        window = $window
        running = [bool]$client
    }
}

while ($true) {
    $raw = Read-NativeMessage
    if ($null -eq $raw) { break }

    $req = $null
    try { $req = $raw | ConvertFrom-Json } catch { }
    if ($null -eq $req) {
        Write-NativeMessage (@{ success = $false; error = 'invalid message' } | ConvertTo-Json -Compress)
        continue
    }

    $reqSeq = $null
    if ($req.PSObject.Properties.Name -contains 'seq') { $reqSeq = $req.seq }

    switch ($req.action) {
        'ping' {
            $r = @{ success = $true }
        }
        'connect' {
            $r = Invoke-ProtonAction 'connect'
        }
        'disconnect' {
            $r = Invoke-ProtonAction 'disconnect'
        }
        'status' {
            $r = Get-ProtonState
        }
        default {
            $r = @{ success = $false; error = 'unknown action' }
        }
    }

    if ($null -ne $reqSeq) {
        $r | Add-Member -NotePropertyName seq -NotePropertyValue $reqSeq -Force
    }
    Write-NativeMessage ($r | ConvertTo-Json -Compress)
}
