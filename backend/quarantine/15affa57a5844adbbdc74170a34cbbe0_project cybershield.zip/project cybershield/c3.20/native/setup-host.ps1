# setup-host.ps1 - one-click, no-prompt setup for the CyberShield Proton VPN native messaging host.
# Generates a stable extension key (fixed extension ID), registers the host for Chrome/Edge.
# Run with:  powershell -NoProfile -ExecutionPolicy Bypass -File setup-host.ps1

$ErrorActionPreference = "Stop"

$extRoot = Split-Path -Parent $PSScriptRoot
$hostDir = Join-Path $env:LOCALAPPDATA "CyberShield\ProtonVpnHost"
$keyFile = Join-Path $PSScriptRoot "cybershield-key.xml"
$hostName = "com.cybershield.protonvpn"
$manifestPath = Join-Path $extRoot "manifest.json"

function New-Tlv {
  param([byte]$Tag, [byte[]]$Content)
  $len = $Content.Length
  $lenBytes = New-Object System.Collections.Generic.List[byte]
  if ($len -lt 0x80) { $lenBytes.Add([byte]$len) }
  elseif ($len -lt 0x100) { $lenBytes.Add(0x81); $lenBytes.Add([byte]$len) }
  elseif ($len -lt 0x10000) { $lenBytes.Add(0x82); $lenBytes.Add([byte]([int]($len -shr 8))); $lenBytes.Add([byte]($len -band 0xFF)) }
  else { throw "DER content too long: $len" }
  $out = New-Object System.Collections.Generic.List[byte]
  $out.Add($Tag)
  $out.AddRange($lenBytes)
  $out.AddRange($Content)
  return $out.ToArray()
}

function New-Integer {
  param([byte[]]$Bytes)
  $i = 0
  while ($i -lt $Bytes.Length - 1 -and $Bytes[$i] -eq 0) { $i++ }
  $int = New-Object System.Collections.Generic.List[byte]
  if (($Bytes[$i] -band 0x80) -ne 0) { $int.Add(0) }
  for ($j = $i; $j -lt $Bytes.Length; $j++) { $int.Add($Bytes[$j]) }
  return New-Tlv 0x02 $int.ToArray()
}

function Get-RsaSpkiDer {
  param($Rsa)
  $params = $Rsa.ExportParameters($false)
  $modInt = [byte[]](New-Integer $params.Modulus)
  $expInt = [byte[]](New-Integer $params.Exponent)

  $rsaInner = New-Object System.Collections.Generic.List[byte]
  $rsaInner.AddRange($modInt)
  $rsaInner.AddRange($expInt)
  $rsaPub = [byte[]](New-Tlv 0x30 $rsaInner.ToArray())

  $oidBytes = [byte[]](0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01)
  $oid = [byte[]](New-Tlv 0x06 $oidBytes)
  $nullTlv = [byte[]](0x05, 0x00)
  $algInner = New-Object System.Collections.Generic.List[byte]
  $algInner.AddRange($oid)
  $algInner.AddRange($nullTlv)
  $algSeq = [byte[]](New-Tlv 0x30 $algInner.ToArray())

  $bsInner = New-Object System.Collections.Generic.List[byte]
  $bsInner.Add(0x00)
  $bsInner.AddRange($rsaPub)
  $bitStr = [byte[]](New-Tlv 0x03 $bsInner.ToArray())

  $spkiInner = New-Object System.Collections.Generic.List[byte]
  $spkiInner.AddRange($algSeq)
  $spkiInner.AddRange($bitStr)
  return [byte[]](New-Tlv 0x30 $spkiInner.ToArray())
}

function Get-ExtensionId {
  param([byte[]]$Spki)
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $hash = $sha.ComputeHash($spki)
  $alpha = "abcdefghijklmnop"
  $sb = New-Object System.Text.StringBuilder
  for ($i = 0; $i -lt 16; $i++) {
    [void]$sb.Append($alpha[[int]($hash[$i] -shr 4)])
    [void]$sb.Append($alpha[[int]($hash[$i] -band 0x0F)])
  }
  return $sb.ToString()
}

Write-Host "CyberShield Proton VPN native host setup" -ForegroundColor Cyan

# 1. Load or generate the extension key (stable across runs).
if (Test-Path -LiteralPath $keyFile) {
  Write-Host "Reusing existing extension key ($keyFile)."
  $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
  $rsa.FromXmlString((Get-Content -LiteralPath $keyFile -Raw))
} else {
  Write-Host "Generating a 2048-bit extension key..."
  $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider -ArgumentList 2048
  $rsa.PersistKeyInCsp = $false
  [System.IO.File]::WriteAllText($keyFile, $rsa.ToXmlString($true), [System.Text.Encoding]::UTF8)
}

$spki = Get-RsaSpkiDer $rsa
$keyB64 = [System.Convert]::ToBase64String($spki)
$extId = Get-ExtensionId $spki
Write-Host "Extension ID: chrome-extension://$extId/" -ForegroundColor Green

# 2. Add the key to manifest.json (idempotent; replaces stale keys).
$manifest = [System.IO.File]::ReadAllText($manifestPath)
$keyMatch = [System.Text.RegularExpressions.Regex]::Match($manifest, '"key"\s*:\s*"([^"]*)"')
if ($keyMatch.Success) {
  if ($keyMatch.Groups[1].Value -eq $keyB64) {
    Write-Host "manifest.json key already up to date."
  } else {
    $manifest = $manifest.Replace($keyMatch.Groups[0].Value, '"key": "' + $keyB64 + '"')
    [System.IO.File]::WriteAllText($manifestPath, $manifest, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "Updated key field in $manifestPath"
  }
} else {
  if ($manifest -notmatch '"version"\s*:\s*"[^"]*"') { throw "manifest.json has no version field" }
  $manifest = [System.Text.RegularExpressions.Regex]::Replace(
    $manifest,
    '("version"\s*:\s*"[^"]*")',
    "`$1,`r`n  `"key`": `"$keyB64`"",
    1)
  [System.IO.File]::WriteAllText($manifestPath, $manifest, (New-Object System.Text.UTF8Encoding($false)))
  Write-Host "Added key field to $manifestPath"
}

# 3. Copy host scripts.
New-Item -ItemType Directory -Force -Path $hostDir | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "protonvpn-host.ps1") -Destination $hostDir -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "protonvpn-host.bat") -Destination $hostDir -Force

# 4. Write the native host manifest.
$hostJson = @{
  name = $hostName
  description = "CyberShield Proton VPN controller"
  path = Join-Path $hostDir "protonvpn-host.bat"
  type = "stdio"
  allowed_origins = @("chrome-extension://$extId/")
} | ConvertTo-Json -Compress
[System.IO.File]::WriteAllText(
  (Join-Path $hostDir "$hostName.json"),
  $hostJson,
  (New-Object System.Text.UTF8Encoding($false)))

# 5. Register for Chrome and Edge (HKCU - no admin needed).
$browsers = @(
  @{ Name = "Chrome"; Path = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName" },
  @{ Name = "Edge";   Path = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$hostName" }
)
foreach ($b in $browsers) {
  New-Item -Path $b.Path -Force | Out-Null
  New-ItemProperty -Path $b.Path -Name "(default)" -Value (Join-Path $hostDir "$hostName.json") -Force | Out-Null
  Write-Host "Registered native host for $($b.Name)."
}

Write-Host ""
Write-Host "Setup complete!" -ForegroundColor Green
Write-Host "1. Remove CyberShield from chrome://extensions (id changed to $extId)."
Write-Host "2. Load unpacked extension again from: $extRoot"
Write-Host "3. Restart Chrome, then the VPN toggle will auto-connect via the host."
