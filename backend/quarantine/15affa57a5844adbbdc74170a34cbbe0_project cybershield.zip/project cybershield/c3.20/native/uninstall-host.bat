@echo off
setlocal
title CyberShield - Uninstall Proton VPN launcher host
echo Removing CyberShield Proton VPN native messaging host...

reg delete "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.cybershield.protonvpn" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.cybershield.protonvpn" /f >nul 2>&1

set "HOST_DIR=%LOCALAPPDATA%\CyberShield\ProtonVpnHost"
if exist "%HOST_DIR%" rmdir /S /Q "%HOST_DIR%" >nul 2>&1

echo Done. The extension will fall back to opening Proton VPN normally.
pause
exit /b 0
