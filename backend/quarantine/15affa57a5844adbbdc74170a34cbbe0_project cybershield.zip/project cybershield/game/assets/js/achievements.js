(function () {
  "use strict";

  var P = window.CyberPlayer;
  if (!P) return;

  var DEFS = [
    { id: "first-mission", emoji: "🔍", name: "First Investigation", desc: "Complete your first mission" },
    { id: "red-hunter", emoji: "🚨", name: "Red Flag Hunter", desc: "Find all red flags in one investigation" },
    { id: "scam-spotter", emoji: "🎯", name: "Scam Spotter", desc: "Reach a streak of 3 correct decisions" },
    { id: "digital-defender", emoji: "🛡️", name: "Digital Defender", desc: "Get a perfect protection result" },
    { id: "security-expert", emoji: "🔐", name: "Security Expert", desc: "Earn 2000 protection points" },
    { id: "five-streak", emoji: "🔥", name: "5 Correct Decisions", desc: "Reach a streak of 5 correct decisions" },
    { id: "cyber-guardian", emoji: "🏆", name: "Cyber Guardian", desc: "Complete all 5 missions and protect the city" },
    { id: "cyber-master", emoji: "💎", name: "Cyber Master", desc: "Score 80+ in the Final Cyber Attack" }
  ];

  function getDef(id) {
    for (var i = 0; i < DEFS.length; i++) {
      if (DEFS[i].id === id) return DEFS[i];
    }
    return null;
  }

  function getDefs() {
    return DEFS;
  }

  function unlock(id) {
    var def = getDef(id);
    if (!def) return false;
    if (P.hasAchievement(id)) return false;
    if (!P.addAchievement(id)) return false;
    var UI = window.CyberUI;
    if (UI) {
      if (window.CyberSound) window.CyberSound.play("achievement");
      UI.showToast(def.emoji + " Achievement unlocked: " + def.name + "!");
      if (UI.confetti) UI.confetti(90);
    }
    return true;
  }

  function checkAll() {
    var s = P.getState();
    if (s.completedMissions.length >= 1) unlock("first-mission");
    if (s.bestStreak >= 3) unlock("scam-spotter");
    if (s.bestStreak >= 5) unlock("five-streak");
    if (s.protection.score >= 2000) unlock("security-expert");
    if (s.completedMissions.length >= 5) unlock("cyber-guardian");
  }

  window.CyberAwards = {
    DEFS: DEFS,
    getDef: getDef,
    getDefs: getDefs,
    unlock: unlock,
    checkAll: checkAll
  };
})();