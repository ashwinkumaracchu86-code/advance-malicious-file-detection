(function () {
  "use strict";

  var P = window.CyberPlayer;
  if (!P) return;

  var TIPS = [
    { emoji: "🎣", title: "Phishing", text: "Phishing is a fake message that tries to trick you into clicking a link or sharing private info. Check the sender, look for urgency and odd links, and never trust unexpected messages." },
    { emoji: "🕵️", title: "Scams", text: "If a deal looks too good to be true, it probably is. Scammers promise prizes, jobs or discounts to steal your money or data. Slow down and verify before you act." },
    { emoji: "🔐", title: "Strong Passwords", text: "Use a long passphrase that is unique to each account — for example 'Blue-Falcon-Sunset-42'. Never use '123456', your name, or the same password everywhere." },
    { emoji: "📲", title: "2FA", text: "Two-Factor Authentication adds a second step when you log in — usually a code on your phone. Even if your password leaks, 2FA keeps the account locked." },
    { emoji: "🔑", title: "OTP Safety", text: "An OTP (One-Time Password) is a secret code for you only. No real company, bank or support person will ever ask you to read it out or send it. If someone asks, it's a scam." },
    { emoji: "🛜", title: "Public Wi-Fi", text: "Public networks can be watched by anyone. Avoid banking and passwords on them, only use https websites, and turn off automatic connection to unknown networks." },
    { emoji: "📱", title: "App Permissions", text: "Apps should only access what they need. A flashlight app doesn't need your contacts. Read permissions before installing and deny anything that looks unnecessary." },
    { emoji: "📁", title: "Suspicious Files", text: "Unexpected attachments can contain viruses. Verify the sender, scan the file with security software, and delete or report it if anything seems off." },
    { emoji: "🌐", title: "Fake Websites", text: "Fake shops copy real designs but use odd domains, no contact page and huge discounts. Check the address bar, look for https, and buy only from sites you trust." },
    { emoji: "🤫", title: "Privacy", text: "The less you share, the safer you are. Think before posting personal details, keep profiles private, and never share passwords, OTPs or card numbers with anyone." }
  ];

  function renderNav() {
    var s = P.getState();
    var set = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.textContent = val;
    };
    set("d-name", s.name);
    set("d-rank", P.rankFor(s.level));
    set("d-level", s.level);
    set("d-xp", s.xp + " / " + P.xpNeeded(s.level));
    set("d-score", s.score);
    set("d-streak", s.bestStreak);
    set("d-protpoints", s.protection.score);

    var sec = P.securityScore();
    set("d-secscore", sec + "/100");
    var secFill = document.getElementById("d-sec-fill");
    if (secFill) secFill.style.width = sec + "%";

    var xpFill = document.getElementById("d-xp-fill");
    if (xpFill) xpFill.style.width = Math.min(100, (s.xp / P.xpNeeded(s.level)) * 100) + "%";

    var lives = document.getElementById("d-lives");
    if (lives) {
      var hearts = "";
      for (var i = 0; i < P.MAX_LIVES; i++) {
        hearts += '<span class="heart' + (i < s.lives ? "" : " dim") + '">❤️</span>';
      }
      lives.innerHTML = hearts;
    }

    var rank = P.cyberRankFor(sec);
    set("d-cyber-emoji", rank.emoji);
    set("d-cyber-rank", rank.name);

    set("d-prot-pct", s.cityProtection + "%");
    var protFill = document.getElementById("d-prot-fill");
    if (protFill) protFill.style.width = s.cityProtection + "%";
    var ticks = document.getElementById("d-prot-ticks");
    if (ticks) {
      var html = "";
      for (var t = 0; t < P.getLocations().length; t++) {
        html += '<span class="prot-tick' + (t < s.completedMissions.length ? " done" : "") + '"></span>';
      }
      ticks.innerHTML = html;
    }

    var c = s.career;
    var inv = c.flagsTotal > 0 ? Math.round((c.flagsFound / c.flagsTotal) * 100) : 0;
    var dec = c.totalDecisions > 0 ? Math.round((c.correctDecisions / c.totalDecisions) * 100) : 0;
    var prot = s.protection.good + s.protection.bad > 0
      ? Math.round((s.protection.good / (s.protection.good + s.protection.bad)) * 100)
      : 0;
    set("sk-inv", inv + "%");
    set("sk-dec", dec + "%");
    set("sk-prot", prot + "%");
    var fill = function (id, v) {
      var el = document.getElementById(id);
      if (el) el.style.width = v + "%";
    };
    fill("sk-inv-fill", inv);
    fill("sk-dec-fill", dec);
    fill("sk-prot-fill", prot);
  }

  function renderMissions() {
    var wrap = document.getElementById("d-missions");
    if (!wrap) return;
    var s = P.getState();
    var html = "";
    P.getLocations().forEach(function (loc) {
      var done = s.completedMissions.indexOf(loc.id) !== -1;
      html +=
        '<div class="mission-line' +
        (done ? " done" : "") +
        '"><span class="mission-line-emoji">' +
        (done ? "✅" : loc.id === "internet" ? "🌐" : "⬜") +
        "</span><span>" +
        loc.name +
        "</span><span class='mission-line-state'>" +
        (done ? "Protected" : "Pending") +
        "</span></div>";
    });
    wrap.innerHTML = html;
  }

  function renderAchievements() {
    var wrap = document.getElementById("d-achievements");
    if (!wrap) return;
    var s = P.getState();
    var html = "";
    window.CyberAwards.DEFS.forEach(function (a) {
      var unlocked = s.achievements.indexOf(a.id) !== -1;
      html +=
        '<div class="ach-card' +
        (unlocked ? " unlocked" : "") +
        '"><span class="ach-emoji">' +
        (unlocked ? a.emoji : "🔒") +
        '</span><div><strong>' +
        a.name +
        "</strong><p>" +
        a.desc +
        "</p></div></div>";
    });
    wrap.innerHTML = html;
  }

  function renderTips() {
    var wrap = document.getElementById("d-tips");
    if (!wrap) return;
    var html = "";
    TIPS.forEach(function (t) {
      html +=
        '<div class="card tip-card"><div class="tip-head"><span class="tip-emoji">' +
        t.emoji +
        "</span><strong>" +
        t.title +
        '</strong></div><p class="tip-body">' +
        t.text +
        "</p></div>";
    });
    wrap.innerHTML = html;
  }

  document.querySelectorAll(".dash-tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll(".dash-tab").forEach(function (t) {
        t.classList.toggle("active", t === tab);
      });
      document.querySelectorAll(".dash-panel").forEach(function (p) {
        p.hidden = p.id !== "panel-" + tab.getAttribute("data-tab");
      });
    });
  });

  var resetBtn = document.getElementById("reset-btn");
  var resetModal = document.getElementById("reset-modal");
  var resetConfirm = document.getElementById("reset-confirm");

  if (resetBtn && resetModal) {
    resetBtn.addEventListener("click", function () {
      if (window.CyberUI) {
        window.CyberUI.openModal(resetModal);
      } else {
        resetModal.hidden = false;
        document.body.style.overflow = "hidden";
      }
    });
    resetConfirm.addEventListener("click", function () {
      P.resetAll();
      if (window.CyberUI) {
        window.CyberUI.closeModal(resetModal);
        window.CyberUI.showToast("🗑️ Progress reset. Fresh start, Guardian!");
      } else {
        resetModal.hidden = true;
        document.body.style.overflow = "";
      }
      renderNav();
      renderMissions();
      renderAchievements();
    });
  }

  renderNav();
  renderMissions();
  renderAchievements();
  renderTips();

  window.addEventListener("cyber:player-updated", function () {
    renderNav();
    renderMissions();
    renderAchievements();
  });
})();