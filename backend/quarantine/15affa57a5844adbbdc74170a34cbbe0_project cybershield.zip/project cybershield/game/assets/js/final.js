(function () {
  "use strict";

  var P = window.CyberPlayer;
  if (!P) return;

  var SITUATIONS = [
    {
      emoji: "📧",
      tag: "Suspicious Email",
      context: "A sudden email claims your account was hacked. Click the red flags in this message.",
      type: "flags",
      maxPts: 30,
      email: {
        from: "support@account-recovery-urgent.test",
        subject: "🚨 Your account was hacked — act now!",
        body:
          "We detected suspicious activity on your account. Your account will be closed unless you confirm your identity within 12 hours. Click the link below to verify:",
        link: "www.verify-account-now.test",
        request: "Enter your username and password to continue.",
        signature: "Best regards,\nSecurity Support Team"
      },
      flags: {
        from: {
          flag: true,
          explain: "Unknown sender domain — not an official service."
        },
        subject: {
          flag: true,
          explain: "Panic in the subject is a classic phishing trick."
        },
        body: {
          flag: false,
          explain: "The story itself looks like a normal warning."
        },
        link: {
          flag: true,
          explain: "A fake link to a website that steals your login."
        },
        request: {
          flag: false,
          explain: "Asking for password is bad — but that part is covered by the link trap."
        },
        signature: {
          flag: false,
          explain: "A signature alone is not a red flag."
        }
      }
    },
    {
      emoji: "📱",
      tag: "OTP Request",
      context: "Someone calls you, says they are from your bank, and asks for the OTP code sent to your phone.",
      question: "Select all safe actions:",
      type: "multi",
      maxPts: 24,
      tip: "No real bank ever asks for your OTP. If someone does, it's a scammer.",
      actions: [
        { text: "Refuse to give the code and end the call", good: true, explain: "The OTP protects your account — never share it with callers." },
        { text: "Call your bank using the official number on their website", good: true, explain: "Verify through a channel you trust, not the one they gave you." },
        { text: "Read out the OTP so they can confirm it's you", good: false, explain: "The caller is a scammer. The code lets them empty your account." },
        { text: "Send them a screenshot of the OTP message", good: false, explain: "A screenshot shows the code too — never send it." }
      ]
    },
    {
      emoji: "🌐",
      tag: "Suspicious Website",
      context: "You find a site selling amazing deals at 90% off. When you try to buy, it asks for your card details and has no contact page.",
      question: "Is this website safe?",
      type: "single",
      maxPts: 20,
      choices: [
        { value: "safe", label: "SAFE", pts: 0, explain: "A site with no contact info asking for card details is not safe at all." },
        { value: "suspicious", label: "SUSPICIOUS", pts: 12, explain: "Close — it clearly looks wrong, but a scam site is more than suspicious: it's malicious." },
        { value: "scam", label: "SCAM", pts: 20, explain: "Correct! Too-good deals + card request + no contact page = a scam shop." }
      ]
    },
    {
      emoji: "🔐",
      tag: "Weak Password",
      context: "Your account uses the password '123456' — the same one you use everywhere.",
      question: "Select all safe actions:",
      type: "multi",
      maxPts: 14,
      tip: "Use a long unique passphrase for each account, and turn on 2FA.",
      actions: [
        { text: "Change it to a long unique passphrase", good: true, explain: "A long passphrase like 'Blue-Falcon-Sunset-42' is hard to guess and unique to this account." },
        { text: "Enable Two-Factor Authentication", good: true, explain: "2FA protects the account even if the password leaks." },
        { text: "Keep '123456' — it's easy to remember", good: false, explain: "'123456' is the most guessed password in the world." },
        { text: "Use the same password for all accounts", good: false, explain: "One leaked password then opens every account you own." }
      ]
    },
    {
      emoji: "🛜",
      tag: "Public Wi-Fi",
      context: "You connect your laptop to free cafe Wi-Fi to work.",
      question: "Select all safe actions:",
      type: "multi",
      maxPts: 12,
      tip: "Treat public Wi-Fi as watched. Keep private data off it.",
      actions: [
        { text: "Avoid logging into your bank account", good: true, explain: "Public networks can be monitored by strangers." },
        { text: "Only visit secure https websites", good: true, explain: "https encrypts the connection so others can't read it." },
        { text: "Turn off auto-connect to unknown networks", good: true, explain: "Your device should not silently join random networks." },
        { text: "Log in to your bank to check your balance", good: false, explain: "Banking on public Wi-Fi is one of the riskiest things you can do." }
      ]
    }
  ];

  var intro = document.getElementById("final-intro");
  var play = document.getElementById("final-play");
  var results = document.getElementById("final-results");
  if (!intro || !play || !results) return;

  var els = {
    count: document.getElementById("final-count"),
    score: document.getElementById("final-score"),
    emoji: document.getElementById("final-emoji"),
    tag: document.getElementById("final-tag"),
    context: document.getElementById("final-context"),
    body: document.getElementById("final-body"),
    choices: document.getElementById("final-choices"),
    confirm: document.getElementById("final-confirm"),
    feedback: document.getElementById("final-feedback"),
    continueBtn: document.getElementById("final-continue"),
    card: document.getElementById("final-card")
  };

  var idx = 0;
  var secScore = 0;
  var xpGain = 0;
  var correctSituations = 0;
  var selected = [];
  var answered = false;
  var flagged = [];
  var flagsFoundTotal = 0;

  var bestStreakAtStart = P.getState().bestStreak;
  var scoreAtStart = P.getState().score;

  document.getElementById("intro-protection").textContent = P.getState().cityProtection + "%";

  document.getElementById("final-start").addEventListener("click", function () {
    var s = P.getState();
    if (s.completedMissions.length < 5 && window.CyberUI) {
      window.CyberUI.showToast("⚠️ Complete all 5 missions first — the city is not fully protected yet!");
    }
    intro.hidden = true;
    play.hidden = false;
    if (window.CyberSound) window.CyberSound.play("warn");
    renderSituation();
  });

  function renderSituation() {
    answered = false;
    selected = [];
    var sit = SITUATIONS[idx];
    els.emoji.textContent = sit.emoji;
    els.tag.textContent = "Situation " + (idx + 1) + " • " + sit.tag;
    els.context.textContent = sit.context;
    els.feedback.hidden = true;
    els.feedback.className = "feedback final-feedback";
    els.confirm.hidden = true;
    els.continueBtn.hidden = true;
    els.count.textContent = (idx + 1) + "/" + SITUATIONS.length;
    els.score.textContent = secScore;
    els.body.innerHTML = "";
    els.choices.innerHTML = "";

    if (sit.type === "flags") {
      buildEmail(sit);
    } else if (sit.type === "multi") {
      buildMulti(sit);
    } else {
      buildSingle(sit);
    }

    els.card.classList.remove("card-in");
    void els.card.offsetWidth;
    els.card.classList.add("card-in");
  }

  function buildEmail(sit) {
    var mail = document.createElement("div");
    mail.className = "final-email";
    var parts = [
      { id: "from", text: "From: " + sit.email.from, cls: "email-from" },
      { id: "subject", text: "Subject: " + sit.email.subject, cls: "email-subject" },
      { id: "body", text: sit.email.body, cls: "email-body" },
      { id: "link", text: "Link: " + sit.email.link, cls: "email-link" },
      { id: "request", text: sit.email.request, cls: "email-body" },
      { id: "signature", text: sit.email.signature, cls: "email-signature" }
    ];
    parts.forEach(function (p) {
      var zone = document.createElement("button");
      zone.type = "button";
      zone.className = "email-zone " + p.cls;
      zone.setAttribute("data-part", p.id);
      zone.textContent = p.text;
      zone.addEventListener("click", function () {
        clickFlag(zone, sit);
      });
      mail.appendChild(zone);
    });
    els.body.appendChild(mail);
  }

  var flagged = [];

  function clickFlag(zone, sit) {
    if (answered) return;
    var id = zone.getAttribute("data-part");
    if (flagged.indexOf(id) !== -1) return;
    var cfg = sit.flags[id];
    if (!cfg) return;
    if (cfg.flag) {
      flagged.push(id);
      flagsFoundTotal++;
      zone.classList.add("flag-hit");
      secScore += 10;
      if (window.CyberSound) window.CyberSound.play("correct");
      if (flagged.length === 3) {
        answered = true;
        correctSituations++;
        els.feedback.className = "feedback final-feedback good-msg";
        els.feedback.innerHTML = "<strong>🎉 All red flags found! +30</strong>";
        els.feedback.hidden = false;
        els.continueBtn.hidden = false;
        if (window.CyberSound) window.CyberSound.play("complete");
      }
    } else {
      zone.classList.add("flag-miss");
      if (window.CyberSound) window.CyberSound.play("warn");
    }
    els.score.textContent = secScore;
  }

  function buildMulti(sit) {
    sit.actions.forEach(function (a, i) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "action-btn";
      btn.setAttribute("data-action", i);
      btn.innerHTML =
        '<span class="a-mark">◻️</span><span class="a-body"><strong>' + a.text + "</strong></span>";
      btn.addEventListener("click", function () {
        if (answered) return;
        var at = selected.indexOf(i);
        if (at === -1) {
          selected.push(i);
        } else {
          selected.splice(at, 1);
        }
        btn.classList.toggle("selected", at === -1);
      });
      els.choices.appendChild(btn);
    });
    els.confirm.hidden = false;
    els.confirm.onclick = function () {
      checkMulti(sit);
    };
  }

  function checkMulti(sit) {
    if (answered) return;
    answered = true;
    var totalGood = 0;
    var goodPicked = 0;
    var badPicked = 0;
    var gain = 0;

    sit.actions.forEach(function (a, i) {
      if (a.good) totalGood++;
      var picked = selected.indexOf(i) !== -1;
      if (picked && a.good) {
        goodPicked++;
        gain += sit.maxPts / totalGood;
      } else if (picked && !a.good) {
        badPicked++;
        gain -= 8;
      }
    });

    gain = Math.max(0, Math.round(gain));
    var perfect = goodPicked === totalGood && badPicked === 0;
    secScore += gain;
    if (perfect) correctSituations++;

    els.choices.querySelectorAll(".action-btn").forEach(function (btn) {
      var i = parseInt(btn.getAttribute("data-action"), 10);
      var a = sit.actions[i];
      var picked = selected.indexOf(i) !== -1;
      var mark, cls;
      if (picked && a.good) {
        mark = "✅";
        cls = "good-pick";
      } else if (picked && !a.good) {
        mark = "❌";
        cls = "bad-pick";
      } else if (!picked && a.good) {
        mark = "👁️";
        cls = "good-missed";
      } else {
        mark = "➖";
        cls = "bad-clear";
      }
      btn.disabled = true;
      btn.classList.add(cls);
      btn.innerHTML =
        '<span class="a-mark">' +
        mark +
        '</span><span class="a-body"><strong>' +
        a.text +
        "</strong><small>" +
        a.explain +
        "</small></span>";
    });

    els.confirm.hidden = true;
    els.feedback.innerHTML =
      "<strong>" +
      (perfect ? "🛡️ Correct! +" + gain : "Score: +" + gain + " — review the highlighted actions") +
      "</strong><p>" +
      sit.tip +
      "</p>";
    els.feedback.className = "feedback final-feedback " + (perfect ? "good-msg" : "mid-msg");
    els.feedback.hidden = false;
    if (window.CyberSound) window.CyberSound.play(perfect ? "complete" : "warn");
    els.continueBtn.hidden = false;
    els.score.textContent = secScore;
  }

  function buildSingle(sit) {
    sit.choices.forEach(function (c) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "choice-btn " + c.value;
      btn.setAttribute("data-choice", c.value);
      btn.textContent = c.label;
      btn.addEventListener("click", function () {
        chooseSingle(sit, c, btn);
      });
      els.choices.appendChild(btn);
    });
  }

  function chooseSingle(sit, c, btn) {
    if (answered) return;
    answered = true;
    var correct = c.pts === sit.maxPts;
    secScore += c.pts;
    if (correct) correctSituations++;

    els.choices.querySelectorAll(".choice-btn").forEach(function (b) {
      b.disabled = true;
      if (b.getAttribute("data-choice") === sit.choices[sit.choices.length - 1].value) {
        b.classList.add("reveal-correct");
      }
    });
    if (correct) {
      btn.classList.add("chosen-correct");
      els.feedback.className = "feedback final-feedback good-msg";
    } else {
      btn.classList.add("chosen-wrong");
      els.feedback.className = "feedback final-feedback mid-msg";
    }
    els.feedback.innerHTML = "<strong>" + c.explain + "</strong>";
    els.feedback.hidden = false;
    if (window.CyberSound) window.CyberSound.play(correct ? "correct" : "wrong");
    els.continueBtn.hidden = false;
    els.score.textContent = secScore;
  }

  els.continueBtn.addEventListener("click", function () {
    idx++;
    flagged = [];
    if (idx < SITUATIONS.length) {
      renderSituation();
    } else {
      showResults();
    }
  });

  function showResults() {
    play.hidden = true;
    results.hidden = false;

    secScore = Math.max(0, Math.min(100, secScore));
    xpGain = Math.round(secScore / 2);
    P.addRewards({ xp: xpGain, score: secScore });

    if (P.getState().completedMissions.length >= 5 && secScore >= 60) {
      P.protectCity();
    }
    if (secScore >= 80 && window.CyberAwards) {
      window.CyberAwards.unlock("cyber-master");
    }
    if (window.CyberSound) window.CyberSound.play("complete");
    if (secScore >= 60 && window.CyberUI) window.CyberUI.confetti(120);

    var s = P.getState();
    document.getElementById("results-sub").textContent =
      "The attackers struck everywhere — and you held the line. Here is your cybersecurity report.";

    var accuracy = Math.round((correctSituations / SITUATIONS.length) * 100);
    document.getElementById("rs-accuracy").textContent = accuracy + "%";
    document.getElementById("rs-flags").textContent = flaggedCountLabel();
    document.getElementById("rs-protect").textContent = s.protection.good + " good / " + s.protection.bad + " bad";
    document.getElementById("rs-xp").textContent = "+" + xpGain + " XP";
    document.getElementById("rs-total").textContent = scoreAtStart + secScore;
    document.getElementById("rs-streak").textContent = Math.max(bestStreakAtStart, s.bestStreak);
    document.getElementById("rs-city").textContent = s.cityProtection + "%";

    countScore(secScore);
  }

  function flaggedCountLabel() {
    var f = SITUATIONS[0].flags;
    var total = 0;
    for (var k in f) {
      if (f.hasOwnProperty(k) && f[k].flag) total++;
    }
    return flagsFoundTotal + "/" + total;
  }

  function countScore(target) {
    var el = document.getElementById("cs-score");
    var ring = document.getElementById("score-ring");
    var start = performance.now();
    var dur = 1600;
    var rankRevealed = false;
    function step(now) {
      var p = Math.min(1, (now - start) / dur);
      var eased = 1 - Math.pow(1 - p, 3);
      var val = Math.round(target * eased);
      el.textContent = val;
      var deg = (val / 100) * 360;
      ring.style.setProperty("--score-deg", deg + "deg");
      if (p >= 1 && !rankRevealed) {
        rankRevealed = true;
        revealRank(target);
      }
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  function revealRank(score) {
    var rank = P.cyberRankFor(score);
    var wrap = document.getElementById("rank-reveal");
    var emoji = document.getElementById("rank-emoji");
    var name = document.getElementById("rank-name");
    emoji.textContent = rank.emoji;
    name.textContent = rank.name;
    wrap.hidden = false;
    wrap.classList.remove("rank-pop");
    void wrap.offsetWidth;
    wrap.classList.add("rank-pop");
    if (score >= 80 && window.CyberSound) window.CyberSound.play("achievement");
  }
})();