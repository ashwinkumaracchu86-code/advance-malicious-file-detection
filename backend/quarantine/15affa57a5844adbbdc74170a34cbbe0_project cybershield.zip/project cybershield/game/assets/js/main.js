(function () {
  "use strict";

  var canvas = document.getElementById("bg-canvas");
  var ctx = canvas.getContext("2d");
  var particles = [];
  var mouse = { x: null, y: null };
  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var running = true;

  var COLORS = ["56,189,248", "167,139,250", "34,211,238", "124,58,237"];

  function resize() {
    var w = window.innerWidth;
    var h = window.innerHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function makeParticles() {
    particles = [];
    var count = Math.min(Math.floor(window.innerWidth * window.innerHeight / 14000), 110);
    for (var i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 0.45,
        vy: (Math.random() - 0.5) * 0.45,
        r: Math.random() * 1.8 + 0.6,
        c: COLORS[Math.floor(Math.random() * COLORS.length)],
        pulse: Math.random() * Math.PI * 2
      });
    }
  }

  function draw() {
    if (!running) return;
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

    var linkDist = 130;
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.pulse += 0.02;

      if (p.x < -20) p.x = window.innerWidth + 20;
      if (p.x > window.innerWidth + 20) p.x = -20;
      if (p.y < -20) p.y = window.innerHeight + 20;
      if (p.y > window.innerHeight + 20) p.y = -20;

      var alpha = 0.35 + Math.sin(p.pulse) * 0.18;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(" + p.c + "," + alpha + ")";
      ctx.shadowColor = "rgba(" + p.c + ",0.9)";
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;

      for (var j = i + 1; j < particles.length; j++) {
        var q = particles[j];
        var dx = p.x - q.x;
        var dy = p.y - q.y;
        var dist = dx * dx + dy * dy;
        if (dist < linkDist * linkDist) {
          var strength = 1 - Math.sqrt(dist) / linkDist;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = "rgba(" + p.c + "," + (strength * 0.16) + ")";
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      if (mouse.x !== null) {
        var mdx = p.x - mouse.x;
        var mdy = p.y - mouse.y;
        var mdist = mdx * mdx + mdy * mdy;
        if (mdist < 140 * 140) {
          var mStrength = 1 - Math.sqrt(mdist) / 140;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mouse.x, mouse.y);
          ctx.strokeStyle = "rgba(" + p.c + "," + (mStrength * 0.35) + ")";
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(draw);
  }

  window.addEventListener("resize", function () {
    resize();
    makeParticles();
  });

  window.addEventListener("pointermove", function (e) {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  });

  window.addEventListener("pointerleave", function () {
    mouse.x = null;
    mouse.y = null;
  });

  document.addEventListener("visibilitychange", function () {
    running = !document.hidden;
    if (running) draw();
  });

  resize();
  makeParticles();
  draw();

  var ui = {
    openModal: function (modal) {
      if (!modal) return;
      modal.hidden = false;
      document.body.style.overflow = "hidden";
    },
    closeModal: function (modal) {
      if (!modal) return;
      modal.hidden = true;
      document.body.style.overflow = "";
    }
  };

  var toastTimer = null;

  ui.showToast = function (msg) {
    var old = document.querySelector(".toast");
    if (old) old.remove();
    var toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = msg;
    document.body.appendChild(toast);
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.add("out");
      setTimeout(function () {
        toast.remove();
      }, 320);
    }, 2800);
  };

  ui.confetti = function (count) {
    var existing = document.querySelector(".confetti-canvas");
    if (existing) existing.remove();
    var c = document.createElement("canvas");
    c.className = "confetti-canvas";
    var cx = c.getContext("2d");
    var w = window.innerWidth;
    var h = window.innerHeight;
    c.width = w;
    c.height = h;
    document.body.appendChild(c);

    var COLORS = ["#22d3ee", "#a78bfa", "#4ade80", "#fbbf24", "#f472b6", "#60a5fa"];
    var parts = [];
    var n = count || 90;
    for (var i = 0; i < n; i++) {
      parts.push({
        x: Math.random() * w,
        y: -20 - Math.random() * h * 0.4,
        vy: 2.2 + Math.random() * 3.2,
        vx: (Math.random() - 0.5) * 2.4,
        size: 5 + Math.random() * 6,
        rot: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 0.24,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        shape: Math.random() > 0.5 ? "rect" : "circle"
      });
    }

    var start = performance.now();
    function frame(now) {
      var t = now - start;
      cx.clearRect(0, 0, w, h);
      var alive = false;
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        p.x += p.vx + Math.sin(t / 300 + i) * 0.5;
        p.y += p.vy;
        p.rot += p.vr;
        if (p.y < h + 30) alive = true;
        cx.save();
        cx.translate(p.x, p.y);
        cx.rotate(p.rot);
        cx.fillStyle = p.color;
        cx.shadowColor = p.color;
        cx.shadowBlur = 8;
        if (p.shape === "rect") {
          cx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
        } else {
          cx.beginPath();
          cx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          cx.fill();
        }
        cx.restore();
      }
      if (alive && t < 3200) {
        requestAnimationFrame(frame);
      } else {
        c.remove();
      }
    }
    requestAnimationFrame(frame);
  };

  document.querySelectorAll("[data-open-modal]").forEach(function (el) {
    el.addEventListener("click", function () {
      var id = el.getAttribute("data-open-modal") || "howto-modal";
      ui.openModal(document.getElementById(id));
    });
  });

  document.querySelectorAll(".modal-backdrop").forEach(function (m) {
    m.addEventListener("click", function (e) {
      if (e.target === m) ui.closeModal(m);
    });
    var close = m.querySelector("[data-close-modal]");
    if (close) {
      close.addEventListener("click", function () {
        ui.closeModal(m);
      });
    }
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      document.querySelectorAll(".modal-backdrop:not([hidden])").forEach(function (m) {
        ui.closeModal(m);
      });
    }
  });

  window.CyberUI = ui;

  function renderPlayerUI() {
    var P = window.CyberPlayer;
    if (!P) return;
    var s = P.getState();
    var set = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.textContent = val;
    };
    set("nav-level", s.level);
    set("nav-score", s.score);
    set("stat-level", s.level);
    set("stat-score", s.score);
    set("stat-rank", P.rankFor(s.level));
    var progress = document.getElementById("level-progress");
    if (progress) {
      progress.style.width = Math.min(100, (s.xp / P.xpNeeded(s.level)) * 100) + "%";
    }
  }

  window.addEventListener("cyber:player-updated", renderPlayerUI);
  renderPlayerUI();

  var hamburger = document.getElementById("hamburger");
  var navLinks = document.getElementById("nav-links");

  var soundToggle = document.getElementById("sound-toggle");
  if (soundToggle && window.CyberSound) {
    var syncSound = function () {
      var on = window.CyberSound.isEnabled();
      soundToggle.textContent = on ? "🔊" : "🔇";
      soundToggle.setAttribute("aria-pressed", on ? "true" : "false");
      soundToggle.title = on ? "Sound ON" : "Sound OFF";
    };
    window.CyberSound.init();
    syncSound();
    soundToggle.addEventListener("click", function () {
      window.CyberSound.setEnabled(!window.CyberSound.isEnabled());
      syncSound();
      window.CyberSound.play("click");
    });
  }

  document.addEventListener("click", function (e) {
    var btn = e.target.closest("button, .btn");
    if (btn && window.CyberSound) {
      window.CyberSound.play("click");
    }
  });

  window.addEventListener("cyber:player-updated", function () {
    if (window.CyberAwards) window.CyberAwards.checkAll();
  });
  if (window.CyberAwards) window.CyberAwards.checkAll();

  if (hamburger && navLinks) {
    hamburger.addEventListener("click", function () {
      var open = navLinks.classList.toggle("open");
      hamburger.classList.toggle("open", open);
      hamburger.setAttribute("aria-expanded", open ? "true" : "false");
    });

    navLinks.addEventListener("click", function (e) {
      if (e.target.closest("a")) {
        navLinks.classList.remove("open");
        hamburger.classList.remove("open");
        hamburger.setAttribute("aria-expanded", "false");
      }
    });
  }
})();
