(function () {
  "use strict";

  var P = window.CyberPlayer;
  if (!P) return;

  var nodesWrap = document.getElementById("map-nodes");
  var linesSvg = document.getElementById("map-lines");
  var stage = document.getElementById("map-stage");
  if (!nodesWrap || !linesSvg || !stage) return;

  var SVG_NS = "http://www.w3.org/2000/svg";

  var STAGE_LABELS = {
    flags: "📧 RED FLAGS",
    scam: "🎯 SCAM OR SAFE",
    protect: "🛡️ PROTECT",
    final: "⚠️ FINAL CHALLENGE"
  };

  function prevName(id) {
    var loc = P.getLocation(id);
    if (!loc) return "Home";
    var idx = P.getLocations().indexOf(loc);
    return idx > 0 ? P.getLocations()[idx - 1].name : "Home";
  }

  function buildMap() {
    nodesWrap.innerHTML = "";
    linesSvg.innerHTML = "";
    var locations = P.getLocations();

    for (var i = 0; i < locations.length; i++) {
      var loc = locations[i];
      var unlocked = P.isUnlocked(loc.id);
      var prev = i > 0 ? locations[i - 1] : null;

      if (i > 0) {
        var path = document.createElementNS(SVG_NS, "path");
        path.setAttribute("d", "M" + prev.x + " " + prev.y + " L" + loc.x + " " + loc.y);
        path.setAttribute("vector-effect", "non-scaling-stroke");
        path.setAttribute("class", "map-seg" + (unlocked ? " active" : " locked"));
        linesSvg.appendChild(path);
      }

      var node = document.createElement("button");
      node.type = "button";
      node.className = "map-node" + (unlocked ? " unlocked" : " locked");
      node.style.setProperty("--x", loc.x + "%");
      node.style.setProperty("--y", loc.y + "%");
      node.style.setProperty("--i", i);
      node.setAttribute("data-mission", loc.id);
      node.setAttribute("data-side", loc.y <= 45 ? "down" : "up");
      node.setAttribute("aria-label", loc.name + (unlocked ? "" : " (locked)"));

      var desc = unlocked ? loc.desc : "Locked — complete " + prevName(loc.id) + " to unlock";

      node.innerHTML =
        '<span class="node-badge">' +
        (unlocked ? loc.emoji : '<span class="lock-emoji">🔒</span>') +
        '</span><span class="node-text"><span class="node-name">' +
        loc.name +
        '</span><span class="node-desc">' +
        desc +
        "</span></span>";

      if (loc.id === "internet") {
        node.classList.add("final-zone");
      }

      var stageTag = document.createElement("span");
      stageTag.className = "stage-tag";
      stageTag.textContent = STAGE_LABELS[loc.stage] || loc.stage;
      node.querySelector(".node-text").appendChild(stageTag);

      node.addEventListener("click", function (e) {
        var el = e.currentTarget;
        var id = el.getAttribute("data-mission");
        if (el.classList.contains("unlocked")) {
          var loc = P.getLocation(id);
          if (loc && loc.id === "internet") {
            window.location.href = "final.html";
          } else if (loc && loc.stage) {
            window.location.href =
              "mission.html?m=" + encodeURIComponent(id) + "&stage=" + encodeURIComponent(loc.stage);
          } else if (loc && loc.hasMission) {
            window.location.href = "mission.html?m=" + encodeURIComponent(id);
          }
        } else {
          var target = P.getLocation(id);
          showToast("🔒 Complete " + prevName(id) + " to unlock " + (target ? target.name : "this location"));
        }
      });

      nodesWrap.appendChild(node);
    }
  }

  function renderPlayerPanel() {
    var s = P.getState();
    var set = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    set("p-name", s.name);
    set("p-rank", P.rankFor(s.level));
    set("p-level", s.level);
    set("p-xp", s.xp + " / " + P.xpNeeded(s.level));
    set("p-score", s.score);

    var xpFill = document.getElementById("p-xp-fill");
    if (xpFill) xpFill.style.width = Math.min(100, (s.xp / P.xpNeeded(s.level)) * 100) + "%";

    var livesEl = document.getElementById("p-lives");
    if (livesEl) {
      var hearts = "";
      for (var i = 0; i < P.MAX_LIVES; i++) {
        hearts += '<span class="heart' + (i < s.lives ? "" : " dim") + '">❤️</span>';
      }
      livesEl.innerHTML = hearts;
    }

    set("prot-pct", s.cityProtection + "%");

    var protFill = document.getElementById("prot-fill");
    if (protFill) {
      var oldVal = parseFloat(protFill.getAttribute("data-val") || "0");
      protFill.setAttribute("data-val", s.cityProtection);
      protFill.style.width = s.cityProtection + "%";
      var track = document.querySelector(".prot-track");
      if (track) {
        track.classList.remove("prot-anim");
        void track.offsetWidth;
        track.classList.add("prot-anim");
      }
      if (s.cityProtection > oldVal) {
        var burst = document.querySelector(".prot-pct");
        if (burst) {
          burst.classList.remove("pct-pop");
          void burst.offsetWidth;
          burst.classList.add("pct-pop");
        }
      }
    }

    var ticks = document.getElementById("prot-ticks");
    if (ticks) {
      var html = "";
      for (var t = 0; t < P.getLocations().length; t++) {
        html += '<span class="prot-tick' + (t < s.completedMissions.length ? " done" : "") + '"></span>';
      }
      ticks.innerHTML = html;
    }

    var stage = document.getElementById("map-stage");
    if (stage) {
      stage.classList.toggle("city-safe", s.cityProtection >= 60);
      stage.classList.toggle("city-secure", s.cityProtection >= 100);
    }
  }

  var toastTimer = null;

  function showToast(msg) {
    if (window.CyberUI && window.CyberUI.showToast) {
      window.CyberUI.showToast(msg);
      return;
    }
    var old = document.querySelector(".toast");
    if (old) old.remove();
    var toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = msg;
    document.body.appendChild(toast);
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.add("out");
      setTimeout(function () {
        toast.remove();
      }, 320);
    }, 2800);
  }

  buildMap();
  renderPlayerPanel();

  window.addEventListener("cyber:player-updated", function () {
    buildMap();
    renderPlayerPanel();
  });
})();
