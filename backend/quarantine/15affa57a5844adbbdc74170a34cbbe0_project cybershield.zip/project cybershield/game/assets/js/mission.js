(function () {
  "use strict";

  var P = window.CyberPlayer;
  if (!P) return;

  var MISSIONS = {
    home: {
      id: "home",
      num: 1,
      name: "Suspicious Email",
      emoji: "📧",
      timeLimit: 45,
      lesson:
        "Be careful with unexpected messages that offer prizes, create urgency, or ask you to click unknown links. " +
        "Real companies never ask for your bank details by email. When in doubt — don't click, just delete.",
      email: {
        from: "winner@example-mail.com",
        to: "you@cybermail.com",
        subject: "🎉 You Won a Prize!",
        greeting: "Hi there,",
        bodyTop: "Congratulations! You have been selected as the lucky winner of a ₹50,000 prize.",
        urgency: "Claim your prize immediately — this offer expires in 24 hours!",
        clickHere: "Click below to claim your prize:",
        link: "www.example-prize.test",
        info: "To verify your identity, please reply with your full name, bank account and PIN.",
        signature: "Best regards,\nThe Prize Team"
      },
      zones: {
        sender: {
          flag: true,
          explain:
            "The sender is an unknown address. Real prize messages come from official company domains — not random inboxes like this one."
        },
        to: {
          flag: false,
          explain: "This is your own address — nothing suspicious about it."
        },
        subject: {
          flag: true,
          explain: "The subject promises a prize you never entered. Scammers use big prizes to grab your attention."
        },
        greeting: {
          flag: false,
          explain: "A simple greeting looks normal. The danger is hidden further down."
        },
        urgency: {
          flag: true,
          explain: "The message pressures you to act fast. Scammers create urgency so you don't stop to think."
        },
        link: {
          flag: true,
          explain: "The link points to an unknown website. Never click links in unexpected messages."
        },
        info: {
          flag: true,
          explain: "It asks for your bank account and PIN. Real companies never ask for personal details by email."
        },
        signature: {
          flag: false,
          explain: "A signature by itself is normal — but remember, anyone can write one."
        }
      }
    },
    school: {
      id: "school",
      num: 2,
      name: "Report Card Trap",
      emoji: "🎓",
      timeLimit: 45,
      lesson:
        "Messages about marks, accounts or rules often arrive by email. Before clicking, check who sent it and what it asks for. " +
        "Real schools don't collect passwords through links in emails.",
      email: {
        from: "results@exam-results-zone.test",
        to: "you@cybermail.com",
        subject: "⚠️ Your report card is ready — view it now",
        greeting: "Dear student,",
        bodyTop: "Your final report card has been published.",
        urgency: "Results expire in 24 hours — download them immediately!",
        clickHere: "View your results here:",
        link: "www.view-my-results.test",
        info: "To view your report card, enter your student ID and school password.",
        signature: "Best regards,\nThe Exam Office"
      },
      zones: {
        sender: {
          flag: true,
          explain:
            "The sender is an unknown domain. Real school emails come from the official school address — not from a random 'results zone'."
        },
        to: {
          flag: false,
          explain: "This is your own address — nothing suspicious about it."
        },
        subject: {
          flag: true,
          explain: "Scare or curiosity in the subject is a classic trick. Report cards are not published like this."
        },
        greeting: {
          flag: false,
          explain: "A normal greeting. The danger is in the links and the request below."
        },
        urgency: {
          flag: true,
          explain: "A countdown pressure is a red flag. Real schools don't expire your results in 24 hours."
        },
        link: {
          flag: true,
          explain: "An unknown website link. Never click links that arrive in unexpected emails."
        },
        info: {
          flag: true,
          explain: "It asks for your school password. No official service asks for your password by email."
        },
        signature: {
          flag: false,
          explain: "A signature by itself is normal — but remember, anyone can write one."
        }
      }
    },
    bank: {
      id: "bank",
      num: 3,
      name: "Bank Alert",
      emoji: "🏦",
      timeLimit: 45,
      lesson:
        "Banks never ask for your PIN, OTP or password by email or SMS. If a message asks for them, it's a scam. " +
        "Open your banking app directly to check alerts — never through a link in a message.",
      email: {
        from: "security@online-bank-verify.test",
        to: "you@cybermail.com",
        subject: "🚨 Your account has been temporarily locked",
        greeting: "Dear customer,",
        bodyTop: "We detected unusual activity on your account.",
        urgency: "Your account will be permanently closed if you don't verify within 12 hours!",
        clickHere: "Verify your account now:",
        link: "www.bank-verify-now.test",
        info: "Enter your username, password and the OTP sent to your phone to confirm.",
        signature: "Best regards,\nThe Security Team"
      },
      zones: {
        sender: {
          flag: true,
          explain:
            "The sender is not your bank's official domain. Scammers fake addresses that look almost right."
        },
        to: {
          flag: false,
          explain: "This is your own address — nothing suspicious about it."
        },
        subject: {
          flag: true,
          explain: "Threatening to lock your account creates fear — a classic phishing trick."
        },
        greeting: {
          flag: false,
          explain: "A standard greeting. The trap is in the link and the details requested."
        },
        urgency: {
          flag: true,
          explain: "A short deadline pressures you to act without thinking. Banks don't threaten like this."
        },
        link: {
          flag: true,
          explain: "A link to a fake banking page that would steal your login details."
        },
        info: {
          flag: true,
          explain: "It asks for your password and OTP. Real banks NEVER ask for these by message."
        },
        signature: {
          flag: false,
          explain: "A signature by itself is normal — but remember, anyone can write one."
        }
      }
    },
    office: {
      id: "office",
      num: 5,
      name: "IT Password Notice",
      emoji: "🏢",
      timeLimit: 45,
      lesson:
        "Fake 'IT department' emails ask you to click a link and enter your work password. " +
        "Real IT teams update passwords through official portals — never through email links.",
      email: {
        from: "it-support@company-verify-portal.test",
        to: "you@cybermail.com",
        subject: "⚠️ Your password expires today",
        greeting: "Dear employee,",
        bodyTop: "Security policy requires you to reset your password.",
        urgency: "Your account will be suspended in 24 hours if you don't reset now!",
        clickHere: "Reset your password here:",
        link: "www.company-portal-login.test",
        info: "Enter your current password and employee ID to continue.",
        signature: "Best regards,\nIT Support Team"
      },
      zones: {
        sender: {
          flag: true,
          explain:
            "Not the official IT domain. Scammers often impersonate support teams with lookalike addresses."
        },
        to: {
          flag: false,
          explain: "This is your own address — nothing suspicious about it."
        },
        subject: {
          flag: true,
          explain: "Password-expiry panic is a classic phishing bait used against employees."
        },
        greeting: {
          flag: false,
          explain: "A standard opening. The real threat is the link and password request."
        },
        urgency: {
          flag: true,
          explain: "A suspension threat creates panic so you click before thinking."
        },
        link: {
          flag: true,
          explain: "A fake login portal that would capture your work password."
        },
        info: {
          flag: true,
          explain: "It asks for your current password. Real IT teams never ask for passwords by email."
        },
        signature: {
          flag: false,
          explain: "A signature by itself is normal — but remember, anyone can write one."
        }
      }
    }
  };

  var query = new URLSearchParams(window.location.search);
  var missionId = query.get("m") || "home";
  var stage = query.get("stage") || "flags";
  if (stage !== "flags") return;
  var mission = MISSIONS[missionId];

  if (!mission) {
    window.location.href = "game.html";
    return;
  }

  document.title = "Mission " + mission.num + ": " + mission.name + " | Cyber Guardian";

  var titleEl = document.getElementById("mission-title");
  if (titleEl) titleEl.textContent = "Mission " + mission.num + ": " + mission.name;

  var briefEmoji = document.querySelector(".brief-card .brief-emoji");
  if (briefEmoji) briefEmoji.textContent = mission.emoji;

  var flagCount = 0;
  for (var key in mission.zones) {
    if (mission.zones.hasOwnProperty(key) && mission.zones[key].flag) flagCount++;
  }

  var emailCard = document.getElementById("email-card");
  var briefCard = document.getElementById("brief-card");
  var play = document.getElementById("mission-play");
  var resultScreen = document.getElementById("result-screen");
  var flagsFoundEl = document.getElementById("flags-found");
  var hudScore = document.getElementById("hud-score");
  var timerText = document.getElementById("timer-text");
  var timerProgress = document.getElementById("timer-progress");
  var timerRing = document.getElementById("timer-ring");
  var startBtn = document.getElementById("start-btn");

  var RING_CIRC = 2 * Math.PI * 34;

  var timeLeft = mission.timeLimit;
  var score = 0;
  var found = [];
  var timerId = null;
  var finished = false;
  var started = false;

  function buildEmail() {
    var e = mission.email;
    var html =
      '<div class="email-topbar">' +
      '<span class="ebar-dot red"></span><span class="ebar-dot yellow"></span><span class="ebar-dot green"></span>' +
      '<span class="ebar-title">CyberMail — Inbox</span>' +
      "</div>" +
      '<div class="email-head">' +
      '<div class="head-row"><span class="head-lbl">From:</span><span class="head-val zone" data-zone="sender">' +
      e.from +
      "</span></div>" +
      '<div class="head-row"><span class="head-lbl">To:</span><span class="head-val zone" data-zone="to">' +
      e.to +
      "</span></div>" +
      '<div class="head-row"><span class="head-lbl">Subject:</span><span class="head-val zone" data-zone="subject">' +
      e.subject +
      "</span></div>" +
      "</div>" +
      '<div class="email-body">' +
      '<p class="zone" data-zone="greeting">' +
      e.greeting +
      "</p>" +
      "<p>" +
      e.bodyTop +
      "</p>" +
      '<p class="zone" data-zone="urgency">' +
      e.urgency +
      "</p>" +
      "<p>" +
      e.clickHere +
      "</p>" +
      '<span class="zone zone-link" data-zone="link">🔗 ' +
      e.link +
      "</span>" +
      '<p class="zone" data-zone="info">' +
      e.info +
      "</p>" +
      '<p class="zone email-sign" data-zone="signature">' +
      e.signature.replace("\n", "<br>") +
      "</p>" +
      "</div>";

    emailCard.innerHTML = html;

    emailCard.querySelectorAll(".zone").forEach(function (zone) {
      zone.addEventListener("click", function (ev) {
        handleClick(ev, zone);
      });
    });
  }

  function start() {
    started = true;
    briefCard.hidden = true;
    play.hidden = false;
    emailCard.classList.add("email-open");
    updateHud();
    timerId = setInterval(tick, 1000);
  }

  function tick() {
    timeLeft--;
    updateHud();
    if (timeLeft <= 0) {
      timeLeft = 0;
      finish(false);
    }
  }

  function updateHud() {
    flagsFoundEl.textContent = found.length + "/" + flagCount;
    hudScore.textContent = score;
    timerText.textContent = timeLeft + "s";
    timerProgress.style.strokeDashoffset = RING_CIRC * (1 - timeLeft / mission.timeLimit);
    timerRing.classList.toggle("timer-mid", timeLeft <= 20 && timeLeft > 10);
    timerRing.classList.toggle("timer-low", timeLeft <= 10);
  }

  function handleClick(ev, zoneEl) {
    if (finished) return;
    var id = zoneEl.getAttribute("data-zone");
    if (found.indexOf(id) !== -1) return;
    var cfg = mission.zones[id];
    if (!cfg) return;

    if (cfg.flag) {
      found.push(id);
      score += 100;
      zoneEl.classList.add("flagged");
      popScore("+100", ev);
      if (window.CyberSound) window.CyberSound.play("correct");
      if (found.length === flagCount) {
        score += 250;
        popScore("+250 BONUS 🎯", ev);
        finish(true);
      }
    } else {
      score -= 25;
      zoneEl.classList.add("missed");
      popScore("-25", ev);
      if (window.CyberSound) window.CyberSound.play("warn");
    }
    updateHud();
  }

  function popScore(text, ev) {
    var span = document.createElement("span");
    span.className = "score-pop " + (text.indexOf("-") === 0 ? "bad" : "good");
    span.textContent = text;
    span.style.left = ev.clientX + "px";
    span.style.top = ev.clientY + "px";
    document.body.appendChild(span);
    setTimeout(function () {
      span.remove();
    }, 1000);
  }

  function finish(success) {
    if (finished) return;
    finished = true;
    clearInterval(timerId);
    updateHud();

    if (success) {
      setTimeout(function () {
        var xp = Math.round(score / 10);
        var leveledBefore = P.getState().level;
        P.addCareer({ flagsFound: flagCount, flagsTotal: flagCount });
        P.addRewards({ xp: xp, score: score });
        P.completeMission(mission.id, { xp: 0, score: 0 });
        if (window.CyberAwards) window.CyberAwards.unlock("red-hunter");
        if (window.CyberSound) window.CyberSound.play("complete");
        showResult(success, xp, P.getState().level > leveledBefore);
      }, 900);
    } else {
      P.addCareer({ flagsFound: found.length, flagsTotal: flagCount });
      if (window.CyberSound) window.CyberSound.play("warn");
      showResult(false, 0, false);
    }
  }

  function showResult(success, xp, leveledUp) {
    play.hidden = true;
    resultScreen.hidden = false;

    var emoji = document.getElementById("result-emoji");
    var title = document.getElementById("result-title");
    var sub = document.getElementById("result-sub");
    var flags = document.getElementById("rs-flags");
    var time = document.getElementById("rs-time");
    var retry = document.getElementById("retry-btn");

    if (success) {
      emoji.textContent = "🎉";
      title.textContent = "LEVEL COMPLETE!";
      sub.textContent =
        "You found all " + flagCount + " red flags in this email. This district is protected!" +
        (leveledUp ? " 🎊 You leveled up!" : "");
      if (window.CyberUI) window.CyberUI.confetti(50);
    } else {
      emoji.textContent = "⏰";
      title.textContent = "TIME'S UP!";
      sub.textContent = "You found " + found.length + " of " + flagCount + " red flags. Look closely and try again!";
      if (retry) retry.hidden = false;
      var back = document.getElementById("result-back");
      if (back) back.hidden = false;
    }

    flags.textContent = found.length + "/" + flagCount;
    time.textContent = timeLeft + "s";
    document.getElementById("lesson-text").textContent = mission.lesson;

    var unlock = document.getElementById("result-unlock");
    if (unlock) {
      unlock.hidden = !success;
      if (success) {
        var nextLoc = nextLocation();
        unlock.textContent = nextLoc
          ? "🔓 Next level unlocked: " + nextLoc.name + " " + nextLoc.emoji
          : "🔓 All levels complete!";
      }
    }

    countUp(document.getElementById("rs-score"), success ? score : Math.max(0, score), 700);
    countUp(document.getElementById("rs-xp"), xp, 900, "XP");
    resultScreen.classList.add("result-in");
  }

  function nextLocation() {
    var locs = P.getLocations();
    for (var i = 0; i < locs.length; i++) {
      if (locs[i].id === mission.id) {
        return locs[i + 1] || null;
      }
    }
    return null;
  }

  function countUp(el, target, duration, suffix) {
    var start = performance.now();
    function step(now) {
      var p = Math.min(1, (now - start) / duration);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = (target > 0 ? "+" : "") + Math.round(target * eased) + (suffix ? " " + suffix : "");
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  var retryBtn = document.getElementById("retry-btn");
  if (retryBtn) {
    retryBtn.addEventListener("click", function () {
      window.location.reload();
    });
  }

  var resultContinue = document.getElementById("result-continue");
  if (resultContinue) {
    resultContinue.addEventListener("click", function () {
      window.location.href = "game.html";
    });
  }

  if (startBtn) {
    startBtn.addEventListener("click", start);
  }

  buildEmail();
  updateHud();
})();