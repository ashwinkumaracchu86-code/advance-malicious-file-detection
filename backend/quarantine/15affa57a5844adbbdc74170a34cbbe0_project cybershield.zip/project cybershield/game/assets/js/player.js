(function () {
  "use strict";

  var STORAGE_KEY = "cyberGuardianPlayer";

  var LOCATIONS = [
    { id: "home", name: "Home", emoji: "🏠", desc: "Find the red flags hiding in a suspicious email.", x: 10, y: 76, hasMission: true, stage: "flags" },
    { id: "school", name: "School", emoji: "🏫", desc: "Spot the scam — decide if messages are safe, suspicious or a scam.", x: 28, y: 52, hasMission: true, stage: "scam" },
    { id: "bank", name: "Bank", emoji: "🏦", desc: "Protect your accounts with smart security actions.", x: 48, y: 28, hasMission: true, stage: "protect" },
    { id: "shop", name: "Online Shop", emoji: "🏪", desc: "Spot the scam in shopping messages — deliveries, deals and payment requests.", x: 72, y: 52, hasMission: true, stage: "scam" },
    { id: "office", name: "Office", emoji: "🏢", desc: "Spot advanced scams that pretend to be real people.", x: 90, y: 74, hasMission: true, stage: "scam" },
    { id: "internet", name: "Internet Zone", emoji: "🌐", desc: "Master safe browsing, privacy and open networks.", x: 62, y: 12, hasMission: true, stage: "final" }
  ];

  var RANKS = [
    { min: 1, name: "Recruit" },
    { min: 3, name: "Scout" },
    { min: 6, name: "Defender" },
    { min: 9, name: "Sentinel" },
    { min: 12, name: "Guardian" },
    { min: 15, name: "Cyber Legend" }
  ];

  var CYBER_RANKS = [
    { max: 39, emoji: "🥉", name: "Cyber Rookie" },
    { max: 59, emoji: "🥈", name: "Digital Defender" },
    { max: 79, emoji: "🥇", name: "Cyber Guardian" },
    { max: 100, emoji: "💎", name: "Cyber Master" }
  ];

  var MAX_LIVES = 5;

  function defaults() {
    return {
      name: "Cyber Guardian",
      level: 1,
      xp: 0,
      score: 0,
      lives: 3,
      streak: 0,
      bestStreak: 0,
      protection: { good: 0, bad: 0, score: 0 },
      completedMissions: [],
      unlockedLocations: ["home"],
      cityProtection: 0,
      achievements: [],
      career: { flagsFound: 0, flagsTotal: 0, correctDecisions: 0, totalDecisions: 0 },
      settings: { sound: true }
    };
  }

  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, n));
  }

  function validId(id) {
    for (var i = 0; i < LOCATIONS.length; i++) {
      if (LOCATIONS[i].id === id) return true;
    }
    return false;
  }

  function xpNeeded(level) {
    return level * 100;
  }

  function rankFor(level) {
    var rank = RANKS[0].name;
    for (var i = 0; i < RANKS.length; i++) {
      if (level >= RANKS[i].min) rank = RANKS[i].name;
    }
    return rank;
  }

  function cyberRankFor(score) {
    var rank = CYBER_RANKS[0];
    for (var i = 0; i < CYBER_RANKS.length; i++) {
      if (score <= CYBER_RANKS[i].max) {
        rank = CYBER_RANKS[i];
        break;
      }
    }
    return rank;
  }

  function indexOf(id) {
    for (var i = 0; i < LOCATIONS.length; i++) {
      if (LOCATIONS[i].id === id) return i;
    }
    return -1;
  }

  function load() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaults();
      var d = JSON.parse(raw);
      return {
        name: typeof d.name === "string" && d.name ? d.name : defaults().name,
        level: clamp(parseInt(d.level, 10) || 1, 1, 999),
        xp: clamp(parseInt(d.xp, 10) || 0, 0, 999999),
        score: clamp(parseInt(d.score, 10) || 0, 0, 999999999),
        lives: clamp(parseInt(d.lives, 10) || 3, 1, MAX_LIVES),
        streak: clamp(parseInt(d.streak, 10) || 0, 0, 999),
        bestStreak: clamp(parseInt(d.bestStreak, 10) || 0, 0, 999),
        protection: {
          good: clamp(parseInt(d.protection && d.protection.good, 10) || 0, 0, 999999),
          bad: clamp(parseInt(d.protection && d.protection.bad, 10) || 0, 0, 999999),
          score: clamp(parseInt(d.protection && d.protection.score, 10) || 0, 0, 999999999)
        },
        completedMissions: Array.isArray(d.completedMissions) ? d.completedMissions.filter(validId) : [],
        unlockedLocations: Array.isArray(d.unlockedLocations) ? d.unlockedLocations.filter(validId) : ["home"],
        cityProtection: clamp(parseInt(d.cityProtection, 10) || 0, 0, 100),
        achievements: Array.isArray(d.achievements) ? d.achievements.filter(function (a) {
          return typeof a === "string";
        }) : [],
        career: {
          flagsFound: clamp(parseInt(d.career && d.career.flagsFound, 10) || 0, 0, 999999),
          flagsTotal: clamp(parseInt(d.career && d.career.flagsTotal, 10) || 0, 0, 999999),
          correctDecisions: clamp(parseInt(d.career && d.career.correctDecisions, 10) || 0, 0, 999999),
          totalDecisions: clamp(parseInt(d.career && d.career.totalDecisions, 10) || 0, 0, 999999)
        },
        settings: {
          sound: !d.settings || d.settings.sound !== false
        }
      };
    } catch (e) {
      return defaults();
    }
  }

  function recompute() {
    var unlocked = [];
    for (var i = 0; i < LOCATIONS.length; i++) {
      if (i === 0 || state.completedMissions.indexOf(LOCATIONS[i - 1].id) !== -1) {
        unlocked.push(LOCATIONS[i].id);
      } else {
        break;
      }
    }
    state.unlockedLocations = unlocked;
    var computed = Math.round((state.completedMissions.length / LOCATIONS.length) * 100);
    state.cityProtection = Math.max(state.cityProtection, computed);
  }

  var state = load();
  recompute();

  function persist() {
    recompute();
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {}
    window.dispatchEvent(new CustomEvent("cyber:player-updated", { detail: state }));
  }

  function getState() {
    return state;
  }

  function getLocations() {
    return LOCATIONS;
  }

  function getLocation(id) {
    var i = indexOf(id);
    return i === -1 ? null : LOCATIONS[i];
  }

  function isUnlocked(id) {
    return state.unlockedLocations.indexOf(id) !== -1;
  }

  function addRewards(rewards) {
    var r = rewards || {};
    var xp = parseInt(r.xp, 10) || 0;
    var score = parseInt(r.score, 10) || 0;
    var leveledUp = false;

    if (xp || score) {
      state.xp += xp;
      state.score += score;
      while (state.xp >= xpNeeded(state.level)) {
        state.xp -= xpNeeded(state.level);
        state.level += 1;
        state.lives = Math.min(MAX_LIVES, state.lives + 1);
        leveledUp = true;
      }
    }

    persist();
    return { leveledUp: leveledUp };
  }

  function completeMission(id, rewards) {
    if (state.completedMissions.indexOf(id) !== -1) return false;
    var i = indexOf(id);
    if (i === -1) return false;
    if (i > 0 && state.completedMissions.indexOf(LOCATIONS[i - 1].id) === -1) return false;

    state.completedMissions.push(id);
    addRewards(rewards);
    return true;
  }

  function loseLife() {
    if (state.lives > 1) {
      state.lives -= 1;
      persist();
    }
  }

  function setStreak(n) {
    state.streak = clamp(parseInt(n, 10) || 0, 0, 999);
    if (state.streak > state.bestStreak) state.bestStreak = state.streak;
    persist();
  }

  function addProtection(good, bad, score) {
    state.protection.good += clamp(parseInt(good, 10) || 0, 0, 999999);
    state.protection.bad += clamp(parseInt(bad, 10) || 0, 0, 999999);
    state.protection.score += clamp(parseInt(score, 10) || 0, 0, 999999999);
    persist();
  }

  function addCareer(c) {
    var r = c || {};
    state.career.flagsFound += clamp(parseInt(r.flagsFound, 10) || 0, 0, 999999);
    state.career.flagsTotal += clamp(parseInt(r.flagsTotal, 10) || 0, 0, 999999);
    state.career.correctDecisions += clamp(parseInt(r.correct, 10) || 0, 0, 999999);
    state.career.totalDecisions += clamp(parseInt(r.total, 10) || 0, 0, 999999);
    persist();
  }

  function addAchievement(id) {
    if (state.achievements.indexOf(id) !== -1) return false;
    state.achievements.push(id);
    persist();
    return true;
  }

  function hasAchievement(id) {
    return state.achievements.indexOf(id) !== -1;
  }

  function setSound(on) {
    state.settings.sound = !!on;
    persist();
  }

  function protectCity() {
    state.cityProtection = 100;
    persist();
  }

  function securityScore() {
    var c = state.career;
    var s = 0;
    s += (state.completedMissions.length / 5) * 30;
    var totalProt = state.protection.good + state.protection.bad;
    if (totalProt > 0) s += (state.protection.good / totalProt) * 20;
    if (c.totalDecisions > 0) s += (c.correctDecisions / c.totalDecisions) * 20;
    s += Math.min(1, state.protection.score / 3000) * 15;
    s += Math.min(1, state.bestStreak / 5) * 15;
    return Math.round(s);
  }

  function resetAll() {
    state = defaults();
    persist();
    return state;
  }

  window.CyberPlayer = {
    getState: getState,
    getLocations: getLocations,
    getLocation: getLocation,
    isUnlocked: isUnlocked,
    completeMission: completeMission,
    addRewards: addRewards,
    loseLife: loseLife,
    setStreak: setStreak,
    addProtection: addProtection,
    addCareer: addCareer,
    addAchievement: addAchievement,
    hasAchievement: hasAchievement,
    setSound: setSound,
    protectCity: protectCity,
    securityScore: securityScore,
    cyberRankFor: cyberRankFor,
    resetAll: resetAll,
    xpNeeded: xpNeeded,
    rankFor: rankFor,
    MAX_LIVES: MAX_LIVES
  };
})();
