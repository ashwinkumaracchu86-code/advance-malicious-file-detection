(function () {
  "use strict";

  var P = window.CyberPlayer;
  if (!P) return;

  var query = new URLSearchParams(window.location.search);
  var missionId = query.get("m") || "bank";
  var stage = query.get("stage") || "protect";
  if (stage !== "protect") return;

  var GOOD_PTS = 150;
  var BAD_PENALTY = 100;
  var PERFECT_BONUS = 250;

  var CHALLENGES = [
    {
      emoji: "🔑",
      tag: "Account Security",
      context: "You think someone may know your password.",
      question: "What should you do?",
      tip: "Never share your password or OTP with someone else.",
      actions: [
        { text: "Change your password to a new strong one", good: true, explain: "A new strong password makes the old one useless to the person who knew it." },
        { text: "Enable Two-Factor Authentication (2FA)", good: true, explain: "2FA adds a second lock — even a stolen password is not enough to get in." },
        { text: "Keep using the same password", good: false, explain: "If someone already knows it, they can still log in as you." },
        { text: "Share the password with a friend for safety", good: false, explain: "Never share passwords with anyone — not even friends." }
      ]
    },
    {
      emoji: "📱",
      tag: "Suspicious App",
      context: "A flashlight app asks for permission to read your contacts, messages and camera.",
      question: "What should you do?",
      tip: "Check app permissions before installing. If an app asks for more than it needs, don't install it.",
      actions: [
        { text: "Check the permissions it is asking for", good: true, explain: "Reading permissions first helps you spot apps that ask for too much." },
        { text: "Deny the unnecessary permissions", good: true, explain: "Apps should only access what they truly need to work." },
        { text: "Uninstall the app if it seems unsafe", good: true, explain: "If an app asks for too much, removing it is the safest choice." },
        { text: "Give the app every permission", good: false, explain: "Granting everything hands over your data, camera and messages." }
      ]
    },
    {
      emoji: "📶",
      tag: "Public Wi-Fi",
      context: "You are at a cafe and connect to its free public Wi-Fi.",
      question: "Which are safe actions on public Wi-Fi?",
      tip: "On public Wi-Fi, avoid sensitive things like banking, and use secure https websites.",
      actions: [
        { text: "Avoid entering passwords or bank details on this network", good: true, explain: "Public networks can be seen by others — keep private data off them." },
        { text: "Only visit secure websites (https)", good: true, explain: "https encrypts the connection and protects your data." },
        { text: "Turn off automatic connection to unknown networks", good: true, explain: "Your device should not silently join random networks." },
        { text: "Disconnect from the Wi-Fi when you finish", good: true, explain: "Leaving the network shortens the time your device is exposed." },
        { text: "Log in to your bank and check your balance", good: false, explain: "Banking on public Wi-Fi lets strangers intercept your details." }
      ]
    },
    {
      emoji: "📁",
      tag: "Suspicious File",
      context: "You receive an unexpected file attachment from a person you don't know.",
      question: "What should you do?",
      tip: "Never open unexpected files from unknown people. Verify, scan, and when in doubt — delete.",
      actions: [
        { text: "Verify who the sender really is", good: true, explain: "Confirm the sender before opening anything unexpected." },
        { text: "Scan the file with security software", good: true, explain: "Antivirus can catch hidden threats before they run." },
        { text: "Delete or report it if it seems suspicious", good: true, explain: "Getting rid of suspicious files keeps your device safe." },
        { text: "Open it immediately to see what it is", good: false, explain: "Unexpected files can contain viruses that run the moment you open them." }
      ]
    }
  ];

  var stage = document.getElementById("protect-stage");
  if (!stage) return;

  var els = {
    count: document.getElementById("protect-count"),
    score: document.getElementById("protect-score"),
    emoji: document.getElementById("protect-emoji"),
    tag: document.getElementById("protect-tag"),
    context: document.getElementById("protect-context"),
    question: document.getElementById("protect-question"),
    list: document.getElementById("action-list"),
    confirm: document.getElementById("protect-confirm"),
    feedback: document.getElementById("protect-feedback"),
    tip: document.getElementById("protect-tip"),
    tipText: document.getElementById("protect-tip-text"),
    continueBtn: document.getElementById("protect-continue"),
    card: document.getElementById("protect-card"),
    final: document.getElementById("final-summary")
  };

  var idx = 0;
  var protectScore = 0;
  var protectXp = 0;
  var selected = [];
  var confirmed = false;
  var completed = false;

  var loc = P.getLocation(missionId) || P.getLocation("bank");
  var locNum = P.getLocations().indexOf(loc) + 1;
  var levelAtStart = P.getState().level;

  document.title = "Mission " + locNum + ": " + loc.name + " — Protect Yourself | Cyber Guardian";
  var titleEl = document.getElementById("mission-title");
  if (titleEl) titleEl.textContent = "Mission " + locNum + ": " + loc.name + " — Protect Yourself";
  var badgeEl = document.querySelector(".mission-badge");
  if (badgeEl) badgeEl.textContent = "🛡️ PROTECT YOURSELF";

  function hideOthers() {
    var brief = document.getElementById("brief-card");
    var play = document.getElementById("mission-play");
    var result = document.getElementById("result-screen");
    var scam = document.getElementById("scam-stage");
    var hud = document.getElementById("mission-hud");
    if (brief) brief.hidden = true;
    if (play) play.hidden = true;
    if (result) result.hidden = true;
    if (scam) scam.hidden = true;
    if (hud) hud.hidden = true;
  }

  function start() {
    idx = 0;
    protectScore = 0;
    protectXp = 0;
    hideOthers();
    stage.hidden = false;
    renderChallenge();
  }

  function renderChallenge() {
    confirmed = false;
    selected = [];
    var c = CHALLENGES[idx];
    els.emoji.textContent = c.emoji;
    els.tag.textContent = c.tag;
    els.context.textContent = c.context;
    els.question.textContent = c.question;
    els.feedback.hidden = true;
    els.feedback.className = "feedback protect-feedback";
    els.tip.hidden = true;
    els.continueBtn.hidden = true;
    els.confirm.hidden = false;
    els.count.textContent = (idx + 1) + "/" + CHALLENGES.length;
    els.score.textContent = protectScore;

    els.list.innerHTML = "";
    c.actions.forEach(function (a, i) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "action-btn";
      btn.setAttribute("data-action", i);
      btn.innerHTML = '<span class="a-mark">◻️</span><span class="a-body"><strong>' + a.text + "</strong></span>";
      btn.addEventListener("click", function () {
        toggle(btn, i);
      });
      els.list.appendChild(btn);
    });

    els.card.classList.remove("card-in");
    void els.card.offsetWidth;
    els.card.classList.add("card-in");
  }

  function toggle(btn, i) {
    if (confirmed) return;
    var at = selected.indexOf(i);
    if (at === -1) {
      selected.push(i);
    } else {
      selected.splice(at, 1);
    }
    btn.classList.toggle("selected", at === -1);
  }

  function confirmChoices() {
    if (confirmed) return;
    confirmed = true;
    var c = CHALLENGES[idx];
    var totalGood = 0;
    var goodPicked = 0;
    var badPicked = 0;
    var gain = 0;

    c.actions.forEach(function (a, i) {
      if (a.good) totalGood++;
      var picked = selected.indexOf(i) !== -1;
      if (picked && a.good) {
        goodPicked++;
        gain += GOOD_PTS;
      } else if (picked && !a.good) {
        badPicked++;
        gain -= BAD_PENALTY;
      }
    });

    var perfect = goodPicked === totalGood && badPicked === 0;
    if (perfect) gain += PERFECT_BONUS;

    protectScore += gain;
    var xp = Math.round(gain / 10);
    protectXp += xp;
    P.addRewards({ xp: xp, score: gain });
    P.addProtection(goodPicked, badPicked, gain);
    P.addCareer({ correct: goodPicked, total: c.actions.length });

    if (perfect) {
      if (window.CyberAwards) window.CyberAwards.unlock("digital-defender");
      if (window.CyberSound) window.CyberSound.play("complete");
    } else if (badPicked > 0) {
      if (window.CyberSound) window.CyberSound.play("warn");
    } else {
      if (window.CyberSound) window.CyberSound.play("correct");
    }

    c.actions.forEach(function (a, i) {
      var btn = els.list.querySelector('[data-action="' + i + '"]');
      if (!btn) return;
      var picked = selected.indexOf(i) !== -1;
      var mark;
      var cls;
      if (picked && a.good) {
        mark = "✅";
        cls = "good-pick";
      } else if (picked && !a.good) {
        mark = "❌";
        cls = "bad-pick";
      } else if (!picked && a.good) {
        mark = "👁️";
        cls = "good-missed";
      } else {
        mark = "➖";
        cls = "bad-clear";
      }
      btn.disabled = true;
      btn.classList.add(cls);
      btn.innerHTML =
        '<span class="a-mark">' +
        mark +
        '</span><span class="a-body"><strong>' +
        a.text +
        "</strong><small>" +
        a.explain +
        "</small></span>";
    });

    els.confirm.hidden = true;
    if (perfect) {
      els.feedback.className = "feedback protect-feedback good-msg";
      els.feedback.innerHTML =
        '<strong>🛡️ Excellent Protection! +' + gain + " points</strong><p>You picked every safe action. Your data stays protected!</p>";
    } else {
      els.feedback.className = "feedback protect-feedback mid-msg";
      els.feedback.innerHTML =
        '<strong>Protection score: +' + gain + " points</strong><p>Review the highlighted actions above to learn the safe choices.</p>";
    }
    els.feedback.hidden = false;
    els.tipText.textContent = c.tip;
    els.tip.hidden = false;
    els.continueBtn.hidden = false;
    els.score.textContent = protectScore;
  }

  function next() {
    idx++;
    if (idx < CHALLENGES.length) {
      renderChallenge();
    } else {
      showFinal();
    }
  }

  function showFinal() {
    els.card.hidden = true;
    els.final.hidden = false;

    if (window.CyberSound) window.CyberSound.play("complete");
    if (window.CyberUI) window.CyberUI.confetti(70);

    countUp(document.getElementById("final-score"), protectScore, 900);
    countUp(document.getElementById("final-xp"), protectXp, 1100, "XP");
    document.getElementById("final-flags").textContent = "—";
    document.getElementById("final-decisions").textContent = "—";
    document.getElementById("final-protect").textContent = protectScore;

    var tip = document.getElementById("final-tip");
    if (tip) {
      tip.textContent =
        "Good security habits are simple: strong unique passwords, 2FA everywhere, cautious clicks, careful permissions and no sharing of OTPs. Make them automatic!";
    }

    var sub = document.getElementById("final-sub");
    sub.textContent =
      "You secured your accounts, apps and devices. This district of Cyber City is protected!";

    if (!completed) {
      completed = true;
      P.completeMission(missionId, { xp: 0, score: 0 });
    }

    var unlock = document.getElementById("final-unlock");
    var unlockText = document.getElementById("final-unlock-text");
    unlock.hidden = false;
    var nextLoc = nextLocation(missionId);
    unlockText.textContent = nextLoc
      ? "Next level unlocked: " + nextLoc.name + " " + nextLoc.emoji
      : "All levels complete!";

    var lvlBanner = document.getElementById("level-up-banner");
    if (P.getState().level > levelAtStart) {
      lvlBanner.textContent = "🎊 LEVEL UP! You reached level " + P.getState().level + " and earned an extra life!";
      lvlBanner.hidden = false;
    }
  }

  function nextLocation(missionId) {
    var locs = P.getLocations();
    for (var i = 0; i < locs.length; i++) {
      if (locs[i].id === missionId) {
        return locs[i + 1] || null;
      }
    }
    return null;
  }

  function countUp(el, target, duration, suffix) {
    var start = performance.now();
    function step(now) {
      var p = Math.min(1, (now - start) / duration);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = "+" + Math.round(target * eased) + (suffix ? " " + suffix : "");
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  els.confirm.addEventListener("click", confirmChoices);
  els.continueBtn.addEventListener("click", next);

  var retry = document.getElementById("final-retry");
  if (retry) {
    retry.addEventListener("click", function () {
      window.location.reload();
    });
  }

  start();
})();