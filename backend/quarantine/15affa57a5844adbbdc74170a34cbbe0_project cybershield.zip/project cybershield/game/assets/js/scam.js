(function () {
  "use strict";

  var P = window.CyberPlayer;
  if (!P) return;

  var query = new URLSearchParams(window.location.search);
  var missionId = query.get("m") || "school";
  var stage = query.get("stage") || "scam";
  if (stage !== "scam") return;

  var SCENE_SETS = {
    school: [
      {
        emoji: "📧",
        tag: "Fake Prize Message",
        context:
          "You receive an email from winner@example-mail.com: \"You have won ₹50,000! Click www.example-prize.test and enter your bank details to claim your prize today.\"",
        answer: "scam",
        correct:
          "This is a scam because it uses an unexpected prize, creates urgency, and contains suspicious links.",
        wrong:
          "Look at the sender, message, and link again. Unknown sender + prize + urgent link are classic scam signs.",
        tip: "Never click links in unexpected messages. Check the sender and website address first."
      },
      {
        emoji: "🛒",
        tag: "Suspicious Website",
        context:
          "You want to buy headphones. A site called soundmart-zone.test shows a big discount, but it has no contact information and asks for your card details before showing the final price.",
        answer: "suspicious",
        correct:
          "Good call! The site looks unprofessional and hides important information — treat it as suspicious and shop somewhere trusted instead.",
        wrong:
          "Think about what is missing: no contact info and a strange web address are warning signs. Never enter card details on a site you don't trust.",
        tip: "Shop only on websites you trust. If something looks off, leave the site — your card details are precious."
      },
      {
        emoji: "👤",
        tag: "Fake Social Media Account",
        context:
          "A profile with your friend's name and photos — but a different username — sends you: \"Hi! My phone broke, can you quickly send me ₹2,000? I'll pay you back!\"",
        answer: "scam",
        correct:
          "This is a scam! Scammers copy real profiles and pretend to be your friends to ask for money.",
        wrong:
          "Even though the profile looks like your friend, a different username and an urgent money request are warning signs. Call your friend to check!",
        tip: "If a \"friend\" suddenly asks for money in a message, call or meet them in person first to confirm."
      },
      {
        emoji: "🔐",
        tag: "OTP Request",
        context:
          "You receive an SMS: \"Your bank login was attempted. Reply with the OTP sent to your phone to secure your account.\" You also see a new OTP message from your bank.",
        answer: "scam",
        correct:
          "This is a scam! A bank will never ask for your OTP or password. Sharing it lets scammers access your account.",
        wrong:
          "The message sounds urgent and official, but banks never ask for OTPs. Anyone who asks for your OTP is trying to steal your account.",
        tip: "Never share OTPs, passwords or PINs with anyone — not even people who say they work at your bank."
      },
      {
        emoji: "🏪",
        tag: "Fake Online Store",
        context:
          "You find megadeals-bazaar.test selling a ₹40,000 phone for ₹4,000. The site asks you to pay with gift card codes and shows no store address.",
        answer: "scam",
        correct:
          "This is a scam! Prices that are too good to be true and gift card payments are classic signs of a fake store.",
        wrong:
          "A huge discount, gift card payment and no store address are all scam warning signs. Real stores don't ask for payment this way.",
        tip: "If a deal looks too good to be true, it probably is. Real stores accept normal payments and show their address."
      }
    ],
    shop: [
      {
        emoji: "📦",
        tag: "Delivery Fee Text",
        context:
          "You get an SMS: \"Your parcel is held at customs. Pay the ₹150 delivery fee now to release it — click here: parcel-release.test/pay.\"",
        answer: "scam",
        correct:
          "This is a scam! Unknown sender + urgent fee + a strange link is the classic fake delivery trick.",
        wrong:
          "Look at the sender and the link again. Real couriers never hold parcels for a fee paid through random links.",
        tip: "Track your parcels on the official courier app — never pay fees through links in messages."
      },
      {
        emoji: "📞",
        tag: "Customer Service Call",
        context:
          "A caller says: \"This is customer service. Your last order was flagged by our security system. Share the OTP I just sent you so we can refund it.\"",
        answer: "scam",
        correct:
          "This is a scam! Real customer support never asks for your OTP. Sharing it lets them empty your account.",
        wrong:
          "The caller sounds official, but support teams never need your OTP. Anyone asking for it is trying to steal from you.",
        tip: "Never share OTPs with anyone — even people who claim to be from customer service."
      },
      {
        emoji: "✅",
        tag: "Official Order Confirmation",
        context:
          "After you buy headphones, the store's official app (verified account, blue tick) shows: \"Order confirmed — your parcel will arrive in 3 days. Track it here.\"",
        answer: "safe",
        correct:
          "Correct! A verified store account inside its official app sending a normal order update is safe.",
        wrong:
          "This one is safe — it's a verified official account inside the store's own app. Be careful with the same message sent from a random email.",
        tip: "Order updates are safe when they come from the official app — never from unknown links in chats."
      },
      {
        emoji: "🔥",
        tag: "Flash Sale Post",
        context:
          "A page with your favourite store's name (no blue tick) posts: \"90% OFF for 1 hour only! Everything must go — click sale-mega.test now!\"",
        answer: "suspicious",
        correct:
          "Good thinking! No blue tick, an unverified page and a strange link mean the sale could be fake — don't click.",
        wrong:
          "An unverified page with an extreme discount and a link you don't recognise are warning signs. Check the official store before clicking.",
        tip: "Extreme discounts on unverified pages are bait. Always open the store's official website yourself."
      },
      {
        emoji: "🎮",
        tag: "Gift Card Payment",
        context:
          "A seller in your gaming group offers a brand-new console for ₹2,000 and says: \"Pay with gift card codes — I'll activate your console the moment you send them. No cash on delivery.\"",
        answer: "scam",
        correct:
          "This is a scam! Gift cards are untraceable — once you send the codes, the money is gone and no console will come.",
        wrong:
          "Too-good prices + gift card payment + no delivery option are classic scam signs. Real sellers accept normal payment methods.",
        tip: "Never pay for anything with gift card codes. Scammers love them because the money can't be traced."
      }
    ],
    office: [
      {
        emoji: "📞",
        tag: "Lottery Call",
        context:
          "A caller says: \"Congratulations! You won ₹10 lakh in our lucky draw. Just pay a ₹5,000 processing fee first, then we'll transfer your prize.\"",
        answer: "scam",
        correct:
          "This is a scam! A real prize never asks you to pay money first. The 'fee' is what the scammer actually wants.",
        wrong:
          "Winning something you never entered + paying a 'fee' to collect it = classic scam pattern. Never send money to claim a prize.",
        tip: "If you have to pay to receive a prize, it's not a prize — it's a scam."
      },
      {
        emoji: "💬",
        tag: "Teacher Message",
        context:
          "Someone on WhatsApp, using your teacher's name and photo, messages you: \"Share your parents' phone number and address for the school form. Do it today.\"",
        answer: "suspicious",
        correct:
          "Good thinking! It might be your teacher — or someone pretending. Never share personal details without verifying who you are really talking to.",
        wrong:
          "Even with a real name and photo, you can't be sure. Confirm with your teacher in person or through the official school app before sharing anything.",
        tip: "When someone asks for personal information in a message, verify who they are through a channel you trust."
      },
      {
        emoji: "🎁",
        tag: "Verified Brand Coupon",
        context:
          "Your favourite gaming brand's verified account (blue tick) sends you a birthday coupon code for 20% off, only inside the official app.",
        answer: "safe",
        correct:
          "Correct! A verified official account sending a simple discount code inside its own app is a normal, safe marketing message.",
        wrong:
          "This one is safe — but only because it comes from a verified account inside the official app. Stay careful with unverified copies of the same offer.",
        tip: "Coupons are safe when they come from official, verified accounts — never from random links in chats."
      },
      {
        emoji: "💰",
        tag: "Double Your Money",
        context:
          "An influencer you don't follow posts: \"Send ₹5,000 to this wallet and I'll send ₹10,000 back — guaranteed double money in 10 minutes!\"",
        answer: "scam",
        correct:
          "This is a scam! 'Guaranteed double money' is impossible. The 'proof' screenshots are fake — you'll just lose your ₹5,000.",
        wrong:
          "No one doubles your money in minutes. Screenshots of 'successful payments' can be faked easily. Never send money to strangers.",
        tip: "Any promise of guaranteed quick profit is a scam. Real money doesn't grow that fast."
      },
      {
        emoji: "📝",
        tag: "Fake Job Offer",
        context:
          "You get an email: \"Work from home, earn ₹30,000 a week! Send your passport copy and bank details to set up your salary account.\"",
        answer: "scam",
        correct:
          "This is a scam! A real job interview never asks for your passport and bank details in the first email.",
        wrong:
          "Too-good salaries and immediate requests for personal documents are classic job scam signs. Real employers interview and use official forms.",
        tip: "Never share passport, card or bank details with someone who offers you a job you never applied for."
      }
    ]
  };

  var SCENARIOS = SCENE_SETS[missionId] || SCENE_SETS.school;

  var stage = document.getElementById("scam-stage");
  if (!stage) return;

  var els = {
    count: document.getElementById("scam-count"),
    streakChip: document.getElementById("streak-chip"),
    streakVal: document.getElementById("streak-val"),
    score: document.getElementById("scam-score"),
    emoji: document.getElementById("scenario-emoji"),
    tag: document.getElementById("scenario-tag"),
    context: document.getElementById("scenario-context"),
    feedback: document.getElementById("feedback"),
    tipCard: document.getElementById("tip-card"),
    tipText: document.getElementById("tip-text"),
    continueBtn: document.getElementById("scam-continue"),
    card: document.getElementById("scenario-card"),
    summary: document.getElementById("scam-summary"),
    choiceRow: document.querySelector(".choice-row")
  };

  var idx = 0;
  var stageScore = 0;
  var stageXp = 0;
  var correctCount = 0;
  var bestStreak = 0;
  var answered = false;
  var completed = false;

  var loc = P.getLocation(missionId) || P.getLocation("school");
  var locNum = P.getLocations().indexOf(loc) + 1;

  document.title = "Mission " + locNum + ": " + loc.name + " — Spot the Scam | Cyber Guardian";
  var titleEl = document.getElementById("mission-title");
  if (titleEl) titleEl.textContent = "Mission " + locNum + ": " + loc.name + " — Spot the Scam";
  var badgeEl = document.querySelector(".mission-badge");
  if (badgeEl) badgeEl.textContent = "🎯 SCAM OR SAFE?";

  function hideOthers() {
    var brief = document.getElementById("brief-card");
    var play = document.getElementById("mission-play");
    var result = document.getElementById("result-screen");
    var protect = document.getElementById("protect-stage");
    var hud = document.getElementById("mission-hud");
    if (brief) brief.hidden = true;
    if (play) play.hidden = true;
    if (result) result.hidden = true;
    if (protect) protect.hidden = true;
    if (hud) hud.hidden = true;
  }

  function start() {
    idx = 0;
    stageScore = 0;
    stageXp = 0;
    correctCount = 0;
    bestStreak = P.getState().streak;
    hideOthers();
    stage.hidden = false;
    renderScenario();
  }

  function renderScenario() {
    answered = false;
    var s = SCENARIOS[idx];
    els.emoji.textContent = s.emoji;
    els.tag.textContent = s.tag;
    els.context.textContent = s.context;
    els.feedback.hidden = true;
    els.feedback.className = "feedback";
    els.tipCard.hidden = true;
    els.continueBtn.hidden = true;

    els.choiceRow.querySelectorAll(".choice-btn").forEach(function (b) {
      b.className = "choice-btn " + b.getAttribute("data-choice");
      b.disabled = false;
    });

    updateHud();
    els.card.classList.remove("card-in");
    void els.card.offsetWidth;
    els.card.classList.add("card-in");
  }

  function choose(choiceBtn) {
    if (answered) return;
    answered = true;
    var s = SCENARIOS[idx];
    var choice = choiceBtn.getAttribute("data-choice");
    var correct = choice === s.answer;

    els.choiceRow.querySelectorAll(".choice-btn").forEach(function (b) {
      b.disabled = true;
    });

    if (correct) {
      var streak = P.getState().streak + 1;
      P.setStreak(streak);
      if (streak > bestStreak) bestStreak = streak;
      var bonus = streak >= 3 ? 100 : 0;
      var gain = 500 + bonus;
      stageScore += gain;
      var xp = Math.round(gain / 10);
      stageXp += xp;
      correctCount++;

      var result = P.addRewards({ xp: xp, score: gain });

      choiceBtn.classList.add("chosen-correct");
      els.feedback.className = "feedback correct";
      els.feedback.innerHTML =
        "<strong>🎉 Correct! +" + gain + "</strong><p>" + s.correct + "</p>";
      els.feedback.hidden = false;

      if (streak === 3) streakMilestone();
      if (result.leveledUp && window.CyberUI) {
        window.CyberUI.showToast("🎉 Level up! You are now level " + P.getState().level + "!");
      }
      if (window.CyberSound) window.CyberSound.play(result.leveledUp ? "levelup" : "correct");

      P.addCareer({ correct: 1, total: 1 });
    } else {
      P.setStreak(0);
      if (window.CyberSound) window.CyberSound.play("wrong");
      P.addCareer({ correct: 0, total: 1 });
      choiceBtn.classList.add("chosen-wrong");
      els.choiceRow.querySelectorAll(".choice-btn").forEach(function (b) {
        if (b.getAttribute("data-choice") === s.answer) b.classList.add("reveal-correct");
      });
      els.feedback.className = "feedback wrong";
      els.feedback.innerHTML = "<strong>❌ Not quite!</strong><p>" + s.wrong + "</p>";
      els.feedback.hidden = false;
    }

    els.tipText.textContent = s.tip;
    els.tipCard.hidden = false;
    els.continueBtn.hidden = false;
    updateHud();
  }

  function streakMilestone() {
    els.streakChip.classList.remove("milestone");
    void els.streakChip.offsetWidth;
    els.streakChip.classList.add("milestone");
    if (window.CyberUI) {
      window.CyberUI.showToast("🔥 3 Correct Decisions in a Row! Streak bonus is now active!");
    }
  }

  function next() {
    idx++;
    if (idx < SCENARIOS.length) {
      renderScenario();
    } else {
      showSummary();
    }
  }

  function updateHud() {
    els.count.textContent = (idx + 1) + "/" + SCENARIOS.length;
    els.streakVal.textContent = P.getState().streak;
    els.streakChip.classList.toggle("on", P.getState().streak >= 3);
    els.score.textContent = stageScore;
  }

  function showSummary() {
    els.card.hidden = true;
    els.summary.hidden = false;
    document.getElementById("sum-score").textContent = "+" + stageScore;
    document.getElementById("sum-xp").textContent = "+" + stageXp + " XP";
    document.getElementById("sum-correct").textContent = correctCount + "/" + SCENARIOS.length;
    document.getElementById("sum-streak").textContent = bestStreak;
    document.getElementById("scam-summary-sub").textContent =
      "You made " + correctCount + " correct decisions out of " + SCENARIOS.length + ". Every correct answer saved your score from a scammer!";

    if (!completed) {
      completed = true;
      P.completeMission(missionId, { xp: 0, score: 0 });
      if (window.CyberSound) window.CyberSound.play("complete");
      var nextLoc = nextLocation();
      var unlockEl = document.createElement("div");
      unlockEl.className = "final-unlock";
      unlockEl.innerHTML =
        '<span class="unlock-emoji">🔓</span><span>' +
        (nextLoc
          ? "Next level unlocked: " + nextLoc.name + " " + nextLoc.emoji
          : "All levels complete!") +
        "</span>";
      var actions = document.querySelector("#scam-summary .result-actions");
      if (actions && actions.parentNode) {
        actions.parentNode.insertBefore(unlockEl, actions);
      }
      if (window.CyberUI && correctCount >= 3) window.CyberUI.confetti(60);
    }
  }

  function nextLocation() {
    var locs = P.getLocations();
    for (var i = 0; i < locs.length; i++) {
      if (locs[i].id === missionId) {
        return locs[i + 1] || null;
      }
    }
    return null;
  }

  els.choiceRow.querySelectorAll(".choice-btn").forEach(function (b) {
    b.addEventListener("click", function () {
      choose(b);
    });
  });

  els.continueBtn.addEventListener("click", next);

  var summaryContinue = document.getElementById("scam-summary-continue");
  if (summaryContinue) {
    summaryContinue.addEventListener("click", function () {
      window.location.href = "game.html";
    });
  }

  start();
})();