(function () {
  "use strict";

  var ctx = null;
  var enabled = true;

  function ensureCtx() {
    if (ctx) return true;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      return true;
    } catch (e) {
      return false;
    }
  }

  function tone(freq, start, dur, type, vol, slideTo) {
    if (!ctx) return;
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = type || "sine";
    osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
    if (slideTo) {
      osc.frequency.exponentialRampToValueAtTime(slideTo, ctx.currentTime + start + dur);
    }
    gain.gain.setValueAtTime(0, ctx.currentTime + start);
    gain.gain.linearRampToValueAtTime(vol || 0.18, ctx.currentTime + start + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(ctx.currentTime + start);
    osc.stop(ctx.currentTime + start + dur + 0.05);
  }

  var SFX = {
    click: function () {
      tone(640, 0, 0.08, "square", 0.08, 520);
    },
    correct: function () {
      tone(660, 0, 0.12, "sine", 0.16);
      tone(880, 0.1, 0.16, "sine", 0.16);
    },
    wrong: function () {
      tone(240, 0, 0.18, "sawtooth", 0.14, 130);
    },
    warn: function () {
      tone(330, 0, 0.12, "sawtooth", 0.13);
      tone(262, 0.14, 0.12, "sawtooth", 0.13);
      tone(330, 0.28, 0.16, "sawtooth", 0.13);
    },
    complete: function () {
      tone(523, 0, 0.14, "triangle", 0.17);
      tone(659, 0.12, 0.14, "triangle", 0.17);
      tone(784, 0.24, 0.14, "triangle", 0.17);
      tone(1047, 0.36, 0.3, "triangle", 0.18);
    },
    achievement: function () {
      tone(784, 0, 0.12, "triangle", 0.17);
      tone(988, 0.1, 0.12, "triangle", 0.17);
      tone(1175, 0.2, 0.12, "triangle", 0.17);
      tone(1568, 0.3, 0.34, "triangle", 0.18);
    },
    levelup: function () {
      tone(392, 0, 0.13, "triangle", 0.16);
      tone(523, 0.12, 0.13, "triangle", 0.16);
      tone(659, 0.24, 0.13, "triangle", 0.16);
      tone(784, 0.36, 0.24, "triangle", 0.18);
      tone(1047, 0.52, 0.3, "triangle", 0.16);
    }
  };

  var sound = {
    init: function () {
      var P = window.CyberPlayer;
      if (P) enabled = P.getState().settings.sound;
      ensureCtx();
    },
    isEnabled: function () {
      return enabled;
    },
    setEnabled: function (on) {
      enabled = !!on;
      var P = window.CyberPlayer;
      if (P) P.setSound(enabled);
      if (enabled) ensureCtx();
    },
    play: function (name) {
      if (!enabled) return;
      if (!ensureCtx()) return;
      if (ctx.state === "suspended") {
        ctx.resume();
      }
      if (SFX[name]) SFX[name]();
    }
  };

  window.CyberSound = sound;
})();