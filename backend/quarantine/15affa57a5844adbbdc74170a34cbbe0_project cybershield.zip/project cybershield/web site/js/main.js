/* ============ CyberShield Landing - 3D Vibe Interactions ============ */
(function () {
  "use strict";

  /* ---------- Preloader ---------- */
  const preloader = document.getElementById("preloader");
  window.addEventListener("load", () => {
    setTimeout(() => preloader.classList.add("done"), 500);
  });
  setTimeout(() => preloader.classList.add("done"), 3500);

  /* ---------- Scroll progress bar ---------- */
  const scrollProgress = document.getElementById("scrollProgress");
  function updateScrollProgress() {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    scrollProgress.style.width = progress + "%";
  }

  /* ---------- Navbar scroll state ---------- */
  const navbar = document.getElementById("navbar");
  const backTop = document.getElementById("backTop");
  let ticking = false;

  function onScroll() {
    if (!ticking) {
      requestAnimationFrame(() => {
        const y = window.scrollY;
        navbar.classList.toggle("scrolled", y > 40);
        backTop.classList.toggle("visible", y > 600);
        updateScrollProgress();
        updateParallax();
        updateScrollDepth();
        ticking = false;
      });
      ticking = true;
    }
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  backTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* ---------- Mobile menu ---------- */
  const hamburger = document.getElementById("hamburger");
  const navLinks = document.getElementById("navLinks");

  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("open");
    navLinks.classList.toggle("open");
  });

  navLinks.querySelectorAll("a").forEach((a) => {
    a.addEventListener("click", () => {
      hamburger.classList.remove("open");
      navLinks.classList.remove("open");
    });
  });

  /* ---------- Smooth anchor scroll (offset for fixed nav) ---------- */
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (e) => {
      const id = anchor.getAttribute("href");
      if (id.length > 1) {
        const target = document.querySelector(id);
        if (target) {
          e.preventDefault();
          const offset = navbar.offsetHeight + 10;
          const top = target.getBoundingClientRect().top + window.scrollY - offset;
          window.scrollTo({ top, behavior: "smooth" });
        }
      }
    });
  });

  /* ---------- Cursor glow ---------- */
  const glow = document.getElementById("cursorGlow");
  let mouseX = -600, mouseY = -600;
  let glowX = -600, glowY = -600;

  window.addEventListener("mousemove", (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  function animateGlow() {
    glowX += (mouseX - glowX) * 0.06;
    glowY += (mouseY - glowY) * 0.06;
    glow.style.transform = `translate(${glowX - 300}px, ${glowY - 300}px)`;
    requestAnimationFrame(animateGlow);
  }
  animateGlow();

  /* ---------- Card mouse follow for radial glow ---------- */
  document.querySelectorAll(".feature-card, .tool-card, .vision-card").forEach((card) => {
    card.addEventListener("mousemove", (e) => {
      const rect = card.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      card.style.setProperty("--mouse-x", x + "%");
      card.style.setProperty("--mouse-y", y + "%");
    });
  });

  /* ---------- Particle network canvas ---------- */
  const canvas = document.getElementById("particleCanvas");
  const ctx = canvas.getContext("2d");
  let particles = [];
  let w, h, dpr;
  const mouse = { x: -9999, y: -9999 };
  const COLORS = ["59,130,246", "16,185,129", "6,182,212"];

  function resizeCanvas() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.parentElement.getBoundingClientRect();
    w = rect.width;
    h = rect.height;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    initParticles();
  }

  function initParticles() {
    const count = Math.min(100, Math.floor((w * h) / 13000));
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      r: Math.random() * 2.2 + 0.6,
      c: COLORS[Math.floor(Math.random() * COLORS.length)],
      tw: Math.random() * Math.PI * 2,
      twSpeed: 0.015 + Math.random() * 0.02,
      depth: Math.random()
    }));
  }

  function drawParticles() {
    ctx.clearRect(0, 0, w, h);

    const linkDist = 150;
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.tw += p.twSpeed;

      if (p.x < -20) p.x = w + 20;
      if (p.x > w + 20) p.x = -20;
      if (p.y < -20) p.y = h + 20;
      if (p.y > h + 20) p.y = -20;

      const alpha = 0.3 + 0.45 * Math.sin(p.tw);
      const size = p.r * (0.8 + p.depth * 0.4);
      ctx.beginPath();
      ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${p.c},${alpha})`;
      ctx.fill();

      for (let j = i + 1; j < particles.length; j++) {
        const q = particles[j];
        const dx = p.x - q.x;
        const dy = p.y - q.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < linkDist) {
          const lAlpha = (1 - dist / linkDist) * 0.16;
          const midC = p.c === q.c ? p.c : "160,120,250";
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(${midC},${lAlpha})`;
          ctx.lineWidth = 0.9;
          ctx.stroke();
        }
      }

      const md = Math.hypot(p.x - mouse.x, p.y - mouse.y);
      if (md < 170) {
        const lAlpha = (1 - md / 170) * 0.5;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(mouse.x, mouse.y);
        ctx.strokeStyle = `rgba(16,185,129,${lAlpha})`;
        ctx.lineWidth = 1.1;
        ctx.stroke();
      }
    }
    requestAnimationFrame(drawParticles);
  }

  resizeCanvas();
  drawParticles();

  window.addEventListener("resize", resizeCanvas);
  window.addEventListener("mousemove", (e) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });
  window.addEventListener("mouseout", () => {
    mouse.x = -9999;
    mouse.y = -9999;
  });

  /* ---------- Typewriter ---------- */
  const phrases = [
    "One shield. Every site.",
    "Scores, blocks, warns - automatically.",
    "Phishing detected before you click.",
    "Ads and trackers? Gone.",
    "Your Gmail inbox, guarded.",
    "Every permission, explained."
  ];
  const typeEl = document.getElementById("typewriter");
  const caretEl = document.getElementById("typeCaret");
  let phraseIdx = 0;
  let charIdx = 0;
  let deleting = false;

  function typeLoop() {
    const current = phrases[phraseIdx];
    if (!deleting) {
      charIdx++;
      typeEl.textContent = current.slice(0, charIdx);
      if (charIdx === current.length) {
        deleting = true;
        setTimeout(typeLoop, 1900);
        return;
      }
      setTimeout(typeLoop, 35 + Math.random() * 50);
    } else {
      charIdx--;
      typeEl.textContent = current.slice(0, charIdx);
      if (charIdx === 0) {
        deleting = false;
        phraseIdx = (phraseIdx + 1) % phrases.length;
        setTimeout(typeLoop, 400);
        return;
      }
      setTimeout(typeLoop, 18);
    }
  }
  setTimeout(typeLoop, 900);

  /* ---------- Enhanced Scroll reveal (multiple animation types) ---------- */
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.08, rootMargin: "0px 0px -50px 0px" }
  );

  const revealClasses = [
    ".reveal", ".reveal-left", ".reveal-right", ".reveal-scale",
    ".reveal-rotate", ".reveal-blur", ".reveal-flip", ".reveal-slide"
  ];
  revealClasses.forEach((cls) => {
    document.querySelectorAll(cls).forEach((el) => revealObserver.observe(el));
  });

  /* ---------- Accent line observer ---------- */
  const lineObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          lineObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );
  document.querySelectorAll(".accent-line").forEach((el) => lineObserver.observe(el));

  /* ---------- Animated HR observer ---------- */
  const hrObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          hrObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );
  document.querySelectorAll(".animated-hr").forEach((el) => hrObserver.observe(el));

  /* ---------- Animated counters ---------- */
  const counterObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          counterObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );

  function animateCounter(el) {
    const target = parseInt(el.dataset.count || el.textContent, 10);
    if (!target) return;
    const duration = 1800;
    const start = performance.now();

    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 4);
      el.textContent = Math.round(target * eased);
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  document.querySelectorAll("[data-count]").forEach((el) => counterObserver.observe(el));

  /* ---------- 3D tilt on cards (enhanced with depth) ---------- */
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (!reduceMotion) {
    document.querySelectorAll("[data-tilt]").forEach((card) => {
      card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        const rotateY = px * 12;
        const rotateX = py * -12;
        const translateZ = 20 + Math.abs(px * py) * 15;
        card.style.transform = `perspective(800px) rotateY(${rotateY}deg) rotateX(${rotateX}deg) translateZ(${translateZ}px) translateY(-12px)`;
        card.style.transition = "transform 0.1s ease-out";
      });
      card.addEventListener("mouseleave", () => {
        card.style.transform = "";
        card.style.transition = "transform 0.5s var(--ease)";
      });
    });

    /* Enhanced 3D tilt for download cards with scale effect */
    document.querySelectorAll(".dl-card").forEach((card) => {
      card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        const rotateY = px * 8;
        const rotateX = py * -8;
        const translateZ = 25 + Math.hypot(px, py) * 20;
        card.style.transform = `perspective(800px) rotateY(${rotateY}deg) rotateX(${rotateX}deg) translateZ(${translateZ}px) translateY(-14px)`;
        card.style.transition = "transform 0.1s ease-out";
      });
      card.addEventListener("mouseleave", () => {
        card.style.transform = "";
        card.style.transition = "transform 0.5s var(--ease)";
      });
    });
  }

  /* ---------- Parallax layers ---------- */
  const orbs = document.querySelectorAll(".orb");
  function updateParallax() {
    const scrollY = window.scrollY;
    if (scrollY > window.innerHeight * 1.5) return;
    orbs.forEach((orb, i) => {
      const speed = 0.18 + i * 0.1;
      const zDepth = 10 + i * 20;
      orb.style.transform = `translateY(${scrollY * speed}px) translateZ(${-zDepth}px)`;
    });
  }

  /* ---------- Scroll-driven 3D depth transforms ---------- */
  function updateScrollDepth() {
    const scrollY = window.scrollY;
    const viewH = window.innerHeight;

    /* Shield stage parallax tilt on scroll */
    const shield = document.querySelector(".shield-stage");
    if (shield) {
      const heroProgress = Math.min(scrollY / viewH, 1);
      const tiltX = heroProgress * 8;
      const tiltY = heroProgress * -5;
      const zDepth = 40 - heroProgress * 30;
      shield.style.transform = `perspective(1200px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) translateZ(${zDepth}px)`;
    }

    /* Grid overlay perspective shift */
    const grid = document.querySelector(".grid-overlay");
    if (grid) {
      const heroProgress = Math.min(scrollY / viewH, 1);
      const rotX = 35 - heroProgress * 25;
      grid.style.transform = `perspective(600px) rotateX(${rotX}deg) translateZ(${-200 + heroProgress * 100}px)`;
    }
  }

  /* ---------- Download button feedback ---------- */
  document.querySelectorAll(".btn-dl-card[download]").forEach((btn) => {
    btn.addEventListener("click", function () {
      var self = this;
      self.classList.add("dl-btn-done");
      var origHTML = self.innerHTML;
      self.innerHTML = "Downloading...";
      setTimeout(function () {
        self.innerHTML = origHTML;
        self.classList.remove("dl-btn-done");
      }, 2600);
    });
  });

  /* ---------- Magnetic button effect ---------- */
  if (!reduceMotion) {
    document.querySelectorAll(".magnetic-btn").forEach((btn) => {
      btn.addEventListener("mousemove", (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        btn.style.transform = `translate(${x * 0.18}px, ${y * 0.18}px) translateZ(8px)`;
        btn.style.transition = "transform 0.15s ease-out";
      });
      btn.addEventListener("mouseleave", () => {
        btn.style.transform = "";
        btn.style.transition = "transform 0.4s var(--ease)";
      });
    });
  }

  /* ---------- Install Guide modal ---------- */
  const howToBtn = document.getElementById("howToBtn");
  const heroHowToBtn = document.getElementById("heroHowToBtn");
  const footerHowToBtn = document.getElementById("footerHowToBtn");
  const howToModal = document.getElementById("howToModal");
  const modalClose = document.getElementById("modalClose");
  const modalDone = document.getElementById("modalDone");

  function openModal() {
    howToModal.classList.add("open");
    howToModal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
  function closeModal() {
    howToModal.classList.remove("open");
    howToModal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  if (howToBtn && howToModal) {
    howToBtn.addEventListener("click", openModal);
    if (heroHowToBtn) heroHowToBtn.addEventListener("click", openModal);
    if (footerHowToBtn) footerHowToBtn.addEventListener("click", openModal);
    modalClose.addEventListener("click", closeModal);
    modalDone.addEventListener("click", closeModal);
    howToModal.addEventListener("click", (e) => {
      if (e.target === howToModal) closeModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && howToModal.classList.contains("open")) closeModal();
    });
  }

  /* ---------- Staggered hero entrance ---------- */
  setTimeout(() => {
    document.querySelectorAll(".hero .reveal-left, .hero .reveal-right, .hero .reveal").forEach((el, i) => {
      setTimeout(() => el.classList.add("visible"), i * 150);
    });
  }, 350);

  /* ---------- Smooth section entrance (opacity fade) ---------- */
  const mainEl = document.querySelector("main");
  if (mainEl) {
    mainEl.style.opacity = "0";
    mainEl.style.transition = "opacity 0.6s ease 0.3s";
    setTimeout(() => { mainEl.style.opacity = "1"; }, 100);
  }

  /* ---------- Text shimmer on scroll into view ---------- */
  const shimmerObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("text-shimmer-active");
          shimmerObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );
  document.querySelectorAll(".text-shimmer").forEach((el) => shimmerObserver.observe(el));

  /* ---------- Smooth number count-up with suffix ---------- */
  const numObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = parseInt(el.dataset.count || "0", 10);
          if (!target) return;
          const suffix = el.dataset.suffix || "";
          const duration = 2000;
          const start = performance.now();
          function tick(now) {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 4);
            el.textContent = Math.round(target * eased) + suffix;
            if (progress < 1) requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);
          numObserver.unobserve(el);
        }
      });
    },
    { threshold: 0.5 }
  );
  document.querySelectorAll("[data-count]").forEach((el) => numObserver.observe(el));

  /* ---------- Scroll-triggered navbar glow line ---------- */
  const navGlowObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          navbar.style.borderBottomColor = "rgba(139, 92, 246, 0.15)";
        } else {
          navbar.style.borderBottomColor = "transparent";
        }
      });
    },
    { threshold: 0.1 }
  );
  document.querySelectorAll(".section").forEach((s) => navGlowObserver.observe(s));

  /* ---------- Download card hover glow pulse ---------- */
  document.querySelectorAll(".dl-card").forEach((card) => {
    card.addEventListener("mouseenter", () => {
      const glow = card.querySelector(".dl-card-glow");
      if (glow) glow.style.opacity = "1";
    });
    card.addEventListener("mouseleave", () => {
      const glow = card.querySelector(".dl-card-glow");
      if (glow) glow.style.opacity = "";
    });
  });

  /* ---------- Smooth section divider animation ---------- */
  const dividerObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = "1";
          entry.target.style.transform = "scaleX(1)";
        }
      });
    },
    { threshold: 0.3 }
  );
  document.querySelectorAll(".section-divider").forEach((el) => {
    el.style.opacity = "0";
    el.style.transform = "scaleX(0)";
    el.style.transition = "opacity 0.8s ease, transform 0.8s ease";
    dividerObserver.observe(el);
  });

  /* ---------- Float chip parallax on mouse ---------- */
  if (!reduceMotion) {
    let bodyTiltX = 0, bodyTiltY = 0;
    let targetTiltX = 0, targetTiltY = 0;

    document.addEventListener("mousemove", (e) => {
      targetTiltX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetTiltY = (e.clientY / window.innerHeight - 0.5) * 2;
    });

    function animateChipParallax() {
      bodyTiltX += (targetTiltX - bodyTiltX) * 0.04;
      bodyTiltY += (targetTiltY - bodyTiltY) * 0.04;

      document.querySelectorAll(".float-chip").forEach((chip, i) => {
        const factor = 1.2 + i * 0.3;
        chip.style.translate = `${bodyTiltX * factor * 2}px ${bodyTiltY * factor * 2}px`;
      });

      requestAnimationFrame(animateChipParallax);
    }
    animateChipParallax();
  }

  /* ---------- FAQ Accordion ---------- */
  document.querySelectorAll(".faq-q").forEach((btn) => {
    btn.addEventListener("click", () => {
      const item = btn.closest(".faq-item");
      const isOpen = item.classList.contains("open");

      // Close all other FAQ items
      document.querySelectorAll(".faq-item.open").forEach((openItem) => {
        if (openItem !== item) {
          openItem.classList.remove("open");
          openItem.querySelector(".faq-q").setAttribute("aria-expanded", "false");
        }
      });

      // Toggle current item
      item.classList.toggle("open", !isOpen);
      btn.setAttribute("aria-expanded", !isOpen);
    });
  });

  /* ---------- Showcase gauge animation on scroll ---------- */
  const gaugeObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const fill = entry.target.querySelector(".gauge-fill");
          if (fill) {
            fill.style.strokeDashoffset = "31";
          }
          gaugeObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.3 }
  );
  document.querySelectorAll(".popup-gauge").forEach((el) => gaugeObserver.observe(el));
})();
