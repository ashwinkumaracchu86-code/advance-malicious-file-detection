@echo off
title CyberShield Website Server
cd /d "%~dp0"

echo ==========================================
echo   CyberShield Website - Local Server
echo   Starting at http://localhost:3000
echo   Close this window to stop the server.
echo ==========================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed. Install it from https://nodejs.org
    pause
    exit /b 1
)

rem Stop any old server still using port 3000
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /r /c:":3000 .*LISTENING"') do (
    taskkill /f /pid %%p >nul 2>nul
)

start "" http://localhost:3000
node server.js
pause
